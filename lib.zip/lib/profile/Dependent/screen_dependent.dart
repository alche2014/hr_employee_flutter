// import 'package:flutter/material.dart';
// import 'package:hr_app/mainApp/mainProfile/Dependent/form.dart';

// class Dependent extends StatelessWidget {
//   final data;
//   const Dependent({this.data, Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // appBar: appBar(context, 'Dependent', true, 'notification', true),
//       body: SingleChildScrollView(
//         child: Container(
//           height: MediaQuery.of(context).size.height * 0.89,
//           padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
//           child: DependentForm(dependent: data),
//         ),
//       ),
//     );
//   }
// }
