// import 'package:flutter/material.dart';
// import 'package:hr_app/background/background.dart';
// import 'package:hr_app/mainApp/forms/form_1.dart';

// class Personalinfo extends StatelessWidget {
//    Personalinfo({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         children:  [
//           BackgroundCircle(),
//           FormOne(),
//         ]
//       ),
//     );
//   }
// }
