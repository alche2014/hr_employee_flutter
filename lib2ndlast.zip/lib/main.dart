import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/UserprofileScreen.dart/first_time_form.dart';
import 'package:hr_app/UserprofileScreen.dart/my_profile_edit.dart';
import 'package:hr_app/mainApp/Login/auth_provider.dart';
import 'package:hr_app/Constants/theme.dart';
import 'Constants/constants.dart';
import 'MainApp/bottom_nav_bar.dart';
import 'mainApp/Login/auth.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'mainApp/Login/google_login.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

// Toggle this to cause an async error to be thrown during initialization
// and to test that runZonedGuarded() catches the error
const _kShouldTestAsyncErrorOnInit = false;

// Toggle this for testing Crashlytics in your app locally.
const _kTestingCrashlytics = true;

ValueNotifier<bool> isdarkmode = ValueNotifier(false);

void main() async {
  tz.initializeTimeZones();

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await runZonedGuarded(() async {
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;

    Future.delayed(const Duration(seconds: 0), () {
      runApp(AuthProvider(
        auth: AuthService(),
        child: ValueListenableBuilder(
            valueListenable: isdarkmode,
            builder: (context, value, _) {
              return MaterialApp(
                debugShowCheckedModeBanner: false,
                theme: darkmode == false
                    ? lightThemeData(context)
                    : darkThemeData(context),
                home: Splash(),
                title: 'Smart HR',

                //routes of different screens
                routes: {
                  "/login": (BuildContext context) => GoogleLogin(),
                  "/app": (BuildContext context) => NavBar(0),
                  "/firstTimeForm": (BuildContext context) =>
                      const FirstTimeForm(),
                  // "/signininvite": (BuildContext context) => DynamicLinkScreen(),
                  "/invalidUser": (BuildContext context) =>
                      const MyProfileEdit(),
                  "/guestProfile": (BuildContext context) =>
                      const MyProfileEdit()
                },
              );
            }),
      ));
    });
    // runApp(const MyApp());
  }, (error, stackTrace) {
    FirebaseCrashlytics.instance.recordError(error, stackTrace);
  });
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

// Define an async function to initialize FlutterFire

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Hr"),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(),
            ],
          ),
        ),
      ),
    );
  }
}

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  int _myValue = 3000;
  int _progress = 1500;

  @override
  void initState() {
    super.initState();

    _navigateToHome();
  }

  _navigateToHome() async {
    await Future.delayed(Duration(milliseconds: _myValue), () {});
    //  Widget _defaultHome = GoogleLogin();

    // final FirebaseAuth _auth = FirebaseAuth.instance;

    //  auth service returns boolean
    bool _result = await AuthService().isLogin();
    // final User? user = await _auth.currentUser;

    if (_result) {
      //  checking user exists or not
      final user = FirebaseAuth.instance.currentUser!;
      bool _com = await AuthService().userExist(user);
      if (_com) {
        // returns bool checking the domain exist or not
        bool domainExist = await AuthService().domainExist(user);
        if (domainExist) {
          //domain exists
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => NavBar(0)));
        } else {
          bool _firstTime = await AuthService().firstTimeLogin(user);
          if (_firstTime) {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => const FirstTimeForm()));
          } else {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => const MyProfileEdit()));
          }
        }
      } else {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => NavBar(0)));
      }
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => GoogleLogin()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFFC53B4B),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Spacer(flex: 3),
            Image.asset(
              'assets/mainIcon.png',
              height: 140,
            ),
            const Spacer(flex: 4),
            TweenAnimationBuilder(
              tween: Tween(begin: 0.0, end: 1.0),
              duration: Duration(milliseconds: _progress),
              builder: (context, double? value, _) => Container(
                height: 15,
                width: 250,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white,
                    width: 4,
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: LinearProgressIndicator(
                    value: value,
                    backgroundColor: Colors.transparent,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              ' 2021. All rights reserved',
              style: const TextStyle(fontSize: 13, color: Colors.white),
            ),
            Spacer(flex: 3),
          ],
        ),
      ),
    );
  }
}
