import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/mainApp/mainProfile/Announcemets/Components/AppBar.dart';
import 'package:hr_app/mainApp/mainProfile/Announcemets/constants.dart';
import 'package:hr_app/mainApp/skills/utility/chip_maker.dart';
import 'package:hr_app/mainApp/skills/utility/chip_maker1.dart';
import 'package:hr_app/mainApp/skills/utility/chips.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

class MainSkills extends StatefulWidget {
  final data;
  const MainSkills({Key? key, this.data}) : super(key: key);

  @override
  _MainSkillsState createState() => _MainSkillsState();
}

class _MainSkillsState extends State<MainSkills> {
  late String userId;
  @override
  void initState() {
    super.initState();
    userId = widget.data["uid"];
  }

  final TextEditingController _textcontroller = TextEditingController();
  final node = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: appBar(context, 'Skills', true, '', true),
        body: SingleChildScrollView(
          child: Container(
            height: MediaQuery.of(context).size.height * 0.89,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //--------------------textfield-----------------------------
                    TypeAheadFormField(
                      textFieldConfiguration: TextFieldConfiguration(
                        decoration: TextFieldDecoration('MainSkills'),
                        controller: _textcontroller,
                        focusNode: node,
                      ),
                      suggestionsCallback: (Pattern) =>
                          Chipmaker1.choosed1.where(
                        (element) => element
                            .toLowerCase()
                            .contains(Pattern.toLowerCase()),
                      ),
                      getImmediateSuggestions: true,
                      hideSuggestionsOnKeyboardHide: false,
                      onSuggestionSelected: (value) {
                        setState(() {
                          //_dropdownValue = value;
                          if (Chipmaker.choosed.contains(value)) {
                            //return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Already Selected'),
                              ),
                            );
                          } else {
                            Chipmaker.choosed.add(value.toString());
                          }
                        });
                      },
                      itemBuilder: (_, String element) {
                        return ListTile(
                          title: Text(element),
                        );
                      },
                      noItemsFoundBuilder: (context) {
                        return Column(
                          children: [
                            const ListTile(
                              title: Text('No Sugestion Found'),
                            ),
                            ListTile(
                              leading: const Icon(Icons.add),
                              title: const Text('Add to List'),
                              onTap: () {
                                setState(() {
                                  Chipmaker.choosed.add(_textcontroller.text);
                                  Chipmaker1.choosed1.add(_textcontroller.text);
                                  _textcontroller.clear();
                                  node.unfocus();
                                });
                              },
                            )
                          ],
                        );
                      },
                    ),

                    // Container(
                    //   // height: 70,
                    //   padding: EdgeInsets.symmetric(horizontal: 10),
                    //   decoration: BoxDecoration(
                    //     borderRadius: BorderRadius.circular(5),
                    //     border: Border.all(
                    //       color: Colors.grey[300],
                    //       width: 1,
                    //     ),
                    //   ),
                    //   child: DropdownButtonFormField(
                    //     decoration: InputDecoration(
                    //         contentPadding: EdgeInsets.all(0),
                    //         border: const OutlineInputBorder(
                    //           borderSide: BorderSide.none,
                    //           borderRadius: BorderRadius.all(
                    //             Radius.circular(10),
                    //           ),
                    //         ),
                    //         labelText: "MainSkills",
                    //         labelStyle:
                    //             TextStyle(fontSize: 12, color: Colors.grey),
                    //         filled: true,
                    //         fillColor: Colors.white),
                    //     value: _dropdownValue,
                    //     items: Chipmaker1.choosed1
                    //         .map<DropdownMenuItem<String>>((String value) {
                    //       return DropdownMenuItem<String>(
                    //         value: value,
                    //         child: Text(
                    //           value,
                    //           style:
                    //               TextStyle(fontSize: 12, color: Colors.grey),
                    //         ),
                    //       );
                    //     }).toList(),
                    //     onChanged: (value) {
                    //       setState(() {
                    //         // _dropdownValue = value;
                    //         if (Chipmaker.choosed.contains(value)) {
                    //           ScaffoldMessenger.of(context).showSnackBar(
                    //             const SnackBar(
                    //               content: Text('Already Selected'),
                    //             ),
                    //           );
                    //         } else {
                    //           Chipmaker.choosed.add(value);
                    //         }
                    //       });
                    //     },
                    //   ),
                    // ),

                    //     TextFormField(
                    //       controller: _textcontroller,
                    //       decoration: TextFieldDecoration('Add MainSkills'),
                    //       onFieldSubmitted: (value) {
                    //         setState(() {
                    //           if (_textcontroller.text.isNotEmpty)
                    //             Chipmaker.choosed.add(_textcontroller.text);
                    //         });
                    //         _textcontroller.clear();
                    //       },
                    //     ),
                    const SizedBox(height: 10),
                    if (Chipmaker.choosed.isNotEmpty) Chipmaker(),
                  ],
                ),
                //------------------------Buttons------------------------
                FractionallySizedBox(
                  widthFactor: 1,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: kPrimaryColor,
                      padding: const EdgeInsets.symmetric(
                        vertical: 15,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      if (Chipmaker.choosed.isNotEmpty) {
                        print("skillsssss adding${Chipmaker1.choosed1} ");
                        print("Added By User${Chipmaker.choosed} ");
                        validateAndSave(Chipmaker.choosed);

                        Navigator.pop(context);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Add some MainSkills'),
                          ),
                        );
                      }
                    },
                    child: const Text(
                      'Save',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                )
              ],
            ),
          ),
        ));
  }

  validateAndSave(skills) async {
    showLoadingDialog(context);

    FirebaseFirestore.instance.runTransaction((Transaction transaction) async {
      DocumentReference reference =
          FirebaseFirestore.instance.collection("employees").doc(userId);

      await reference.update({"skills": Chipmaker.choosed});
    }).whenComplete(() {
      Navigator.pop(context);

      Fluttertoast.showToast(msg: "Skills is updated successfully");
    }).catchError((e) {
      // ignore: avoid_print
      print('======Error====$e==== ');
    });
    Future.delayed(const Duration(milliseconds: 1150), () {
      // Navigator.of(context).pop();
    });
    // }
  }

  void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }
}
