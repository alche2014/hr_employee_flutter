import 'dart:async';
import 'dart:io';

// import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_masked_text/flutter_masked_text.dart';
import 'package:flutter/services.dart';
import 'package:flutter_offline/flutter_offline.dart';
import 'package:flutter_picker/flutter_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';
// import 'package:google_map_polyline/google_map_polyline.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/mainApp/work_info/utility/build_my_input_decoration.dart';
import 'package:hr_app/mainUtility/share_preference.dart';
import 'package:hr_app/services/helper.dart';
import 'package:image_picker/image_picker.dart';
// import 'package:google_map_location_picker/google_map_location_picker.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../colors.dart';
// import 'package:multi_image_picker/multi_image_picker.dart';

// employee add his/her personal information in this screen
class ContactInfo extends StatefulWidget {
  final data;
  ContactInfo({Key? key, this.data}) : super(key: key);
  @override
  _ContactInfoState createState() => _ContactInfoState();
}

class _ContactInfoState extends State<ContactInfo> {
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  // bool isNetwork = true;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  GlobalKey<FormState> locationFormKey = GlobalKey<FormState>();
  late double locationLatitude;
  late double locationLongitude;
  List locationData = [];
  // GoogleMapPolyline googleMapPolyline =
  //     new GoogleMapPolyline(apiKey: "AIzaSyAvJyF8A3rklI6U2Y02ElzGf3_-k_ss0lk");
  // Completer<GoogleMapController> _controller = Completer();

  static const LatLng _center = LatLng(31.4697, 74.2728);
  var lat;
  var lng;
  var lat1;
  var lng1;
  var _pickedLocation;
    var dateOfBirth;


  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  // Map<String, String>  _paths;

  LatLng _lastMapPosition = _center;
  MapType _currentMapType = MapType.normal;
  late bool showMap;
  var locationAddress;
  late String locationVal;
  bool mapshow = false;

  late String address;
  late String phone;
  late String email;
  late String cnic;
  late String age;
  //  Asset  ? image;
  late String bankName;
  late String bankNumber;
  late String cnicAddress;
  late String emergencyPhone;
  late String bloodGroup;
    bool checkedValue = false;


  // late File _image;
  late bool assetImage;
  late bool netImage;
  late String userId;

  List finals = [];
  List perfect = [];
  var cnicNum;

  final FocusNode _addressFocus = FocusNode();
  final FocusNode _phoneFocus = FocusNode();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _cnicFocus = FocusNode();
  final FocusNode _bloodGroupFocus = FocusNode();
  final FocusNode _bankNameFocus = FocusNode();
  final FocusNode _bankNumberFocus = FocusNode();
  final FocusNode _emergencyPhoneFocus = FocusNode();
  final FocusNode _cnicAddressFocus = FocusNode();

  TextEditingController addressController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController bankNameController = TextEditingController();
  TextEditingController bankNumberController = TextEditingController();
  TextEditingController bloodGroupController = TextEditingController();
  TextEditingController emergencyPhoneController = TextEditingController();
  TextEditingController cnicAddressController = TextEditingController();
  var cnicController = MaskedTextController(mask: '00000-0000000-0');

    final maskFormatter = MaskTextInputFormatter(mask: '+92 ### ### ####');


  var dobFormat;
  int agex = 0;
  late DateTime dob;
  String birthDate = "";
  var camera;

  _selectDate(BuildContext context) {
    Picker(
        hideHeader: true,
        adapter: DateTimePickerAdapter(yearEnd: DateTime.now().year),
        title: const Text(
          "Date of Birth",
          style: TextStyle(
            color: Color(0xFFBF2B38),
          ),
        ),
        selectedTextStyle: const TextStyle(
          color: Color(0xFFBF2B38),
        ),
        onConfirm: (Picker picker, List value) {
          setState(() {
            dob = (picker.adapter as DateTimePickerAdapter).value!;
            dobFormat = DateFormat('dd-MMM-yyyy').format(dob);
            calculateAge(dob);
          });
        }).showDialog(context);
  }

  calculateAge(DateTime dob) {
    DateTime currentDate = DateTime.now();
    var year = DateFormat('yyyy').format(dob);
    var month = DateFormat('MM').format(dob);
    var day = DateFormat('dd').format(dob);
    var syear = int.parse(year);
    var smonth = int.parse(month);
    var sday = int.parse(day);
    agex = currentDate.year - syear;

    int month1 = currentDate.month;
    int month2 = smonth;
    if (month2 > month1) {
      agex--;
    } else if (month1 == month2) {
      int day1 = currentDate.day;
      int day2 = sday;
      if (day2 > day1) {
        agex--;
      }
    }
    return agex;
  }

  late String _extension;
  late FileType _pickType;
  bool _multiPick = true;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  String? path;
  String? fileName;
  String profilePicUrl = '';

  File? _image;

  File? images;
  String? imagePath;
    final ImagePicker _imagePicker = ImagePicker();

  // List<StorageUploadTask> _tasks = <StorageUploadTask>[];
  int selectedMaritalTile = 1;

  setSelectedMaritalTile(int val) {
    setState(() {
      selectedMaritalTile = val;
    });
  }
    static Reference storage = FirebaseStorage.instance.ref();



 static Future<String> uploadUserImageToFireStorage(
       image, String userID) async {
    Reference upload = storage.child("images/$userID.png");
    UploadTask uploadTask = upload.putFile(image);
    var downloadUrl =
        await (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    return downloadUrl.toString();
  }

  Future<void> retrieveLostData() async {
    final LostData? response = await _imagePicker.getLostData();
    if (response == null) {
      return;
    }
    if (response.file != null) {
      setState(() {
        _image = File(response.file!.path);
      });
    }
  }

  
  _onCameraClick() {
    final action = CupertinoActionSheet(
      message:const Text(
        "Add profile picture",
        style: TextStyle(fontSize: 15.0),
      ),
      actions: <Widget>[
        CupertinoActionSheetAction(
          child: const Text("Choose from gallery"),
          isDefaultAction: false,
          onPressed: () async {
            Navigator.pop(context);
            PickedFile? image =
                await _imagePicker.getImage(source: ImageSource.gallery);
            if (image != null)
              setState(() {
                _image = File(image.path);
              });
          },
        ),
        CupertinoActionSheetAction(
          child: const Text("Take a picture"),
          isDestructiveAction: false,
          onPressed: () async {
            Navigator.pop(context);
            PickedFile? image =
                await _imagePicker.getImage(source: ImageSource.camera);
            if (image != null)
              setState(() {
                _image = File(image.path);
              });
          },
        )
      ],
      cancelButton: CupertinoActionSheetAction(
        child:const  Text("Cancel"),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    );
    showCupertinoModalPopup(context: context, builder: (context) => action);
  }
  Future pickImage() async {
    try {
      final image =
          await ImagePicker.platform.pickImage(source: ImageSource.gallery);
            // if (image != null) {
        // await updateProgress('Uploading image, Please wait...');
       profilePicUrl =
            await uploadUserImageToFireStorage(fileName,userId);
     // }
      if (image == null) return;

     

      setState(() {
// 
        
        imagePath = image.path;
        print("ImgPath:::::::::::::${imagePath}");
        // this.image = imageTemp;
        // saveImage(this.image);
      });
      
      // saveImage('SaveImage', image.path);
    } on PlatformException catch (e) {
      print('Access Rejected: $e');
    }
  }

  // void openFileExplorer() async {
  //   try {
  //     if (_multiPick) {
  //       _paths = await FilePicker.getMultiFilePath(
  //           type: _pickType,);
  //     }
  //     uploadToFirebase();
  //   } on PlatformException catch (e) {
  //     print("Unsupported operation" + e.toString());
  //   }
  //   if (!mounted) return;
  // }

  // uploadToFirebase() {
  //   if (_multiPick) {
  //     _paths!.forEach((fileName, filePath) => {upload(fileName, filePath)});
  //   }
  // } 

  // upload(fileName, filePath) {
  //   _extension = fileName.toString().split('.').last;
  //   StorageReference storageRef =
  //       FirebaseStorage.instance.ref().child("Documents/$fileName");
  //   final StorageUploadTask uploadTask = storageRef.putFile(
  //     File(filePath),
  //     StorageMetadata(
  //       contentType: '$_pickType/$_extension',
  //     ),
  //   );
  //   setState(() {
  //     _tasks.add(uploadTask);
  //   });
  // }

  ScrollController? con;

  @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          // isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          // isNetwork = true;
        });
      }
    });
    // widget.data["photoURL"] != null ? netImage = true : netImage = false;
    // widget.data["photoURL"] != null ? assetImage = false : assetImage = true;
    userId = widget.data["uid"];

    phoneController = TextEditingController(
      text: widget.data["phone"],
    );
    emailController = TextEditingController(
      text: widget.data["otherEmail"],
    );
    selectedMaritalTile = widget.data["maritalStatus"] == null
        ? 0
        : widget.data["maritalStatus"] == "Single"
            ? 1
            : 2;
    // agex = (widget.data["age"] == null ? null : int.parse(widget.data["age"]));
    bankNumberController = TextEditingController(
      text: widget.data["bankNumber"],
    );
    bankNameController = TextEditingController(
      text: widget.data["bankName"],
    );
    bloodGroupController = TextEditingController(
      text: widget.data["bloodGroup"],
    );

    emergencyPhoneController = TextEditingController(
      text: widget.data["emergencyPhone"],
    );
    addressController = TextEditingController(
      text: widget.data["address"],
    );
    cnicController = MaskedTextController(
        text: widget.data["cnic"], mask: '00000-0000000-0');
    cnicAddressController = TextEditingController(
      text: widget.data["cnicAddress"],
    );
    dobFormat = widget.data["dob"];
    imagePath = widget.data['imagePath'];

    fileName=widget.data['fileName'];
    checkedValue=widget.data['covidCheck']==null? false:checkedValue;
    // cameras();

    con = ScrollController();
    con!.addListener(() {
      if (con!.offset >= con!.position.maxScrollExtent &&
          !con!.position.outOfRange) {
        setState(() {});
      } else if (con!.offset <= con!.position.minScrollExtent &&
          !con!.position.outOfRange) {
        setState(() {});
      } else {
        setState(() {});
      }
    });
  }

  // cameras() async {
  //   // Obtain a list of the available cameras on the device.
  //   // final cameras = await availableCameras();

  //   // Get a specific camera from the list of available cameras.
  //   camera = cameras.first;
  // }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> childrenx = <Widget>[];

    double h2 = 0.0 + (childrenx.length * 80);
    double h = 45.0 + h2;

    return Form(
        key: _formKey,
        child: Scaffold(
            extendBodyBehindAppBar: true,
            key: _scaffoldKey,
            // appBar:
            //  AppBar(
            //   backgroundColor: Color(0xFFBF2B38),
            //   title: Text(
            //     "Personal Info",
            //     style: TextStyle(
            //         color: Colors.white,
            //         fontFamily: "Avenir",
            //         fontSize: 20,
            //         fontWeight: FontWeight.w500),
            //   ),
            //   leading: InkWell(
            //     onTap: () {
            //       Navigator.pop(context);
            //     },
            //     child: Icon(
            //       Icons.close,
            //       color: Colors.white,
            //     ),
            //   ),
            //   automaticallyImplyLeading: false,
            //   iconTheme: IconThemeData(
            //     color: Colors.black,
            //   ),
            //   actions: <Widget>[
            //     OfflineBuilder(
            //       connectivityBuilder: (
            //         BuildContext context,
            //         ConnectivityResult connectivity2,
            //         Widget child,
            //       ) {
            //         if (connectivity2 == ConnectivityResult.none) {
            //           return InkWell(
            //             onTap: () {
            //               Flushbar(
            //                 messageText: Text(
            //                   "No Internet Connection",
            //                   style: TextStyle(
            //                       fontSize: 15,
            //                       color: Colors.white,
            //                       fontWeight: FontWeight.w500),
            //                 ),
            //                 duration: Duration(seconds: 3),
            //                 isDismissible: true,
            //                 icon: Image.asset(
            //                   "assets/images/cancel.png",
            //                   scale: 1.4,
            //                   // height: 25,
            //                   // width: 25,
            //                 ),
            //                 backgroundColor: Color(0xFFBF2B38),
            //                 margin: EdgeInsets.all(8),
            //                 borderRadius: 8,
            //               )..show(context);
            //             },
            //             child: Container(
            //               width: 90,
            //               padding: EdgeInsets.only(right: 20, left: 20),
            //               alignment: Alignment.centerRight,
            //               child: Container(
            //                 child: Text(
            //                   "Save",
            //                   style: TextStyle(
            //                       color: Colors.white,
            //                       fontWeight: FontWeight.w400,
            //                       fontSize: 15),
            //                 ),
            //               ),
            //             ),
            //           );
            //         } else {
            //           return child;
            //         }
            //       },
            //       builder: (BuildContext context) {
            //         return InkWell(
            //           onTap: () {
            //             validateAndSave();
            //           },
            //           child: Container(
            //             width: 90,
            //             padding: EdgeInsets.only(right: 20, left: 20),
            //             alignment: Alignment.centerRight,
            //             child: Container(
            //               child: Text(
            //                 "Save",
            //                 style: TextStyle(
            //                     color: Colors.white,
            //                     fontWeight: FontWeight.w400,
            //                     fontSize: 15),
            //               ),
            //             ),
            //           ),
            //         );
            //       },
            //     ),
            //   ],
            // ),

            body: Stack(children: [
              const BackgroundCircle(),
              NestedScrollView(
                  headerSliverBuilder: (context, innerBoxIsScrolled) => [
                        buildMyNewAppBar(context, 'Personal Info', true),
                      ],
                  body: Stack(
                    children: [
                      SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[

                             Center(
                               child: Padding(
          padding:
              const EdgeInsets.only(left: 8.0, top: 32, right: 8, bottom: 8),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: <Widget>[
              CircleAvatar(
                radius: 65,
                backgroundColor: Colors.grey.shade400,
                child: ClipOval(
                  child: SizedBox(
                    width: 170,
                    height: 170,
                    child:
                    imagePath==null?(
                     _image == null
                        ? Image.asset(
                            'assets/user_image.png',
                            fit: BoxFit.cover,
                          )
                        : Image.file(
                            _image!,
                            fit: BoxFit.cover,
                          )): Image.network(imagePath! ,
                          fit:BoxFit.cover)
                       
                  ),
                ),
              ),
              Positioned(
                left: 80,
                right: 0,
                child: FloatingActionButton(
                    backgroundColor: const Color(COLOR_PRIMARY),
                    child: const Icon(Icons.camera_alt),
                    mini: true,
                    onPressed: _onCameraClick),
              )
            ],
          ),
        ),
                             ),
                            // Container(
                            //   alignment: Alignment.center,
                            //   child: InkWell(
                            //     onTap: () {
                            //       showModalBottomSheet(
                            //           context: context,
                            //           builder: (BuildContext bc) {
                            //             return Wrap(
                            //               children: <Widget>[
                            //                 ListTile(
                            //                   leading: const Icon(Icons.image),
                            //                   title: const Text('Gallery'),
                            //                   onTap: () {
                            //                     Navigator.pop(context);
                            //                     pickImage();
                            //                   },
                            //                 ),
                            //               ],
                            //             );
                            //           });
                            //     },
                            //     child: Stack(
                            //       //using stack to lap edit icon over Picture
                            //       children: [
                            //         imagePath != null
                            //             ? CircleAvatar(
                            //                 radius: 50,
                            //                 child: ClipRRect(
                            //                   clipBehavior: Clip.antiAlias,
                            //                   borderRadius:
                            //                       BorderRadius.circular(100),
                            //                   child: Image(
                            //                     image:
                            //                         FileImage(File(imagePath!)),
                            //                     height: 114,
                            //                     width: 115,
                            //                     fit: BoxFit.cover,
                            //                   ),
                            //                 ),
                            //               )
                            //             : CircleAvatar(
                            //                 radius: 50,
                            //                 child: ClipRRect(
                            //                   clipBehavior: Clip.antiAlias,
                            //                   borderRadius:
                            //                       BorderRadius.circular(100),
                            //                   child: images != null
                            //                       ? Image.file(images!)
                            //                       : Image.asset(
                            //                           "assets/user_image.png",
                            //                           height: 114,
                            //                           width: 115,
                            //                           fit: BoxFit.cover,
                            //                         ),
                            //                 ),
                            //               ),
                            //         const Positioned(
                            //             bottom: 10,
                            //             right: 0,
                            //             child: Image(
                            //               image: AssetImage(
                            //                   'assets/custom/Vector.png'),
                            //               width: 30,
                            //               fit: BoxFit.cover,
                            //             )),
                            //       ],
                            //     ),
                            //   ),
                            // ),
                            // Container(
                            //   margin: EdgeInsets.only(top: 10),
                            //   width: MediaQuery.of(context).size.width,
                            //   child: Text(
                            //     "Profile Photo",
                            //     textAlign: TextAlign.center,
                            //     style: TextStyle(
                            //         color: Colors.black,
                            //         fontFamily: "Avenir",
                            //         fontSize: 16,
                            //         fontWeight: FontWeight.w500),
                            //   ),
                            // ),
                            // Container(
                            //     alignment: Alignment.center,
                            //     margin: EdgeInsets.only(top: 10, bottom: 10),
                            //     child: netImage == false && image == null
                            //         ? _uploadImageContainer
                            //         : image != null
                            //             ? _imageContainer
                            //             : networkImageContainer(widget.data["photoURL"])),
                            // Container(
                            //   alignment: Alignment.center,
                            //   margin: EdgeInsets.only(top: 10),
                            //   child: new GestureDetector(
                            //     onTap: () {
                            //       getImage();
                            //     },
                            //     child: (_image != null)
                            //         ? new Container(
                            //             height: 100.0,
                            //             width: 100.0,
                            //             decoration: new BoxDecoration(
                            //               image: new DecorationImage(
                            //                 image: new FileImage(_image),
                            //                 fit: BoxFit.cover,
                            //               ),
                            //               border: Border.all(
                            //                 color: Colors.white,
                            //                 width: 3.0,
                            //               ),
                            //               borderRadius: new BorderRadius.all(
                            //                   const Radius.circular(100.0)),
                            //             ),
                            //           )
                            //         : new GestureDetector(
                            //             child: Container(
                            //               height: 100.0,
                            //               width: 100.0,
                            //               child: Icon(
                            //                 Icons.camera_alt,
                            //                 size: 55,
                            //                 color: Color(0xFFBF2B38),
                            //               ),
                            //               decoration: new BoxDecoration(
                            //                 color: Colors.white,
                            //                 // image: new DecorationImage(
                            //                 //   image: new AssetImage(
                            //                 //       "assets/images/profileImg.png"),
                            //                 //   fit: BoxFit.cover,
                            //                 // ),
                            //                 border: Border.all(
                            //                   color: Colors.grey[200],
                            //                   width: 3.0,
                            //                 ),
                            //                 borderRadius: new BorderRadius.all(
                            //                     const Radius.circular(100.0)),
                            //               ),
                            //               // child: ClipRRect(
                            //               //   borderRadius: BorderRadius.circular(88),
                            //               //   child: FadeInImage(
                            //               //     fit: BoxFit.fill,
                            //               //     placeholder: AssetImage(
                            //               //       "assets/images/profileImg.png",
                            //               //       //height: 30,
                            //               //     ),
                            //               //     image: AssetImage(
                            //               //       " assets/images/profileImg.png",
                            //               //       //height: 30,
                            //               //     ),
                            //               //     // snapshot.data.data["photoURL"].toString() !=
                            //               //     //         null
                            //               //     //     ? NetworkImage(snapshot
                            //               //     //         .data.data["photoURL"]
                            //               //     //         .toString())
                            //               //     //     : AssetImage(
                            //               //     //         " assets/images/avatar.png",
                            //               //     //         //height: 30,
                            //               //     //       ),
                            //               //   ),
                            //               // ),
                            //             ),
                            //             onTap: () {
                            //               getImage();
                            //             },
                            //           ),
                            //   ),
                            // ),

                            // Container(
                            //   // height: 40,
                            //   margin: const EdgeInsets.only(
                            //       left: 15, right: 15, bottom: 10, top: 15),
                            //   width: MediaQuery.of(context).size.width - 10,
                            //   child: TextFormField(
                            //     controller: phoneController,
                            //     decoration:
                            //         buildMyInputDecoration(context, 'Phone'),
                            //     // autovalidateMode: AutovalidateMode.onUserInteraction,
                            //     textInputAction: TextInputAction.next,
                            //     focusNode: _phoneFocus,
                            //     keyboardType: TextInputType.phone,
                            //     onSaved: (String? value) => phone = value!,
                            //     onFieldSubmitted: (term) {
                            //       _phoneFocus.unfocus();
                            //       FocusScope.of(context)
                            //           .requestFocus(_emailFocus);
                            //     },
                            //     validator: validatePhone,
                            //     maxLength: 11,
                            //   ),
                            // ),


                              TextFormField(
                controller:  phoneController,
                textInputAction: TextInputAction.next,
                decoration: buildMyInputDecoration(context, 'Phone'),
                keyboardType: TextInputType.number,
                inputFormatters: [maskFormatter],
                   onSaved: (String? value) => phone = value!,
                                onFieldSubmitted: (term) {
                                  _phoneFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_emailFocus);
                                },
                validator: (value) {
                  final regExp = RegExp('[0-9]');
                  if (value!.isEmpty) {
                    return null;
                  } else if (!regExp.hasMatch(value)) {
                    return 'Enter only number';
                  } else {
                    return null;
                  }
                },
              ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 10),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: emailController,
                                decoration:
                                    buildMyInputDecoration(context, 'Email'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.done,
                                focusNode: _emailFocus,
                                onSaved: (String? value) => email = value!,
                                onFieldSubmitted: (term) {
                                  _emailFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_cnicFocus);
                                },
                                validator: validateEmail,
                                keyboardType: TextInputType.emailAddress,
                              ),
                            ),
                            // Container(
                            //   margin: EdgeInsets.only(left: 27, right: 15),
                            //   child: Row(
                            //     children: <Widget>[
                            //       Expanded(
                            //         flex: 8,
                            //         child: Text(
                            //           "CNIC*",
                            //           style: TextStyle(
                            //               color: Colors.grey[500],
                            //               fontSize: 11,
                            //               fontFamily: "Roboto",
                            //               fontWeight: FontWeight.normal),
                            //         ),
                            //       ),
                            //       Expanded(
                            //         flex: 2,
                            //         child: InkWell(
                            //           onTap: () {
                            //             Navigator.push(
                            //                 context,
                            //                 MaterialPageRoute(
                            //                     builder: (context) =>
                            //                         OpenCamera(camera: camera)));
                            //           },
                            //           child: Icon(
                            //             Icons.camera_alt,
                            //             size: 25,
                            //           ),
                            //         ),
                            //       )
                            //     ],
                            //   ),
                            // ),
                            // Container(
                            //   // height: 40,
                            //   margin: EdgeInsets.only(left: 15, right: 15, bottom: 20),
                            //   width: MediaQuery.of(context).size.width - 10,
                            //   child: TextFormField(
                            //     controller: cnicController,
                            //     textInputAction: TextInputAction.next,
                            //     keyboardType: TextInputType.phone,
                            //     focusNode: _cnicFocus,
                            //     onSaved: (String value) => cnic = value,
                            //     onFieldSubmitted: (term) {
                            //       _cnicFocus.unfocus();
                            //       FocusScope.of(context).requestFocus(_bankNameFocus);
                            //     },
                            //     validator: validateCnic,
                            //     decoration: new InputDecoration(
                            //       prefixIcon: Icon(
                            //         Icons.folder_shared,
                            //         color: Color(0xFFBF2B38),
                            //       ),
                            //       fillColor: Colors.black,
                            //       hintText: 'CNIC',
                            //       hintStyle: TextStyle(
                            //           color: Color(0xFFA2A2A2),
                            //           fontSize: 14,
                            //           fontFamily: "Roboto",
                            //           fontWeight: FontWeight.normal),
                            //     ),
                            //   ),
                            // ),
                            // Container(
                            //   margin: EdgeInsets.only(
                            //     left: 27,
                            //     right: 15,
                            //   ),
                            //   child: Text(
                            //     "Attach CNIC*",
                            //     style: TextStyle(
                            //         color: Colors.grey[500],
                            //         fontSize: 11,
                            //         fontFamily: "Roboto",
                            //         fontWeight: FontWeight.normal),
                            //   ),
                            // ),
                            // Container(
                            //   margin: EdgeInsets.only(top: 9.0, left: 15, right: 15),
                            //   height: h,
                            //   child: Column(
                            //     children: <Widget>[
                            //       Container(
                            //         width: MediaQuery.of(context).size.width - 30,
                            //         height: 40,
                            //         child: InkWell(
                            //           highlightColor: Colors.transparent,
                            //           splashColor: Colors.transparent,
                            //           onTap: () {
                            //             openFileExplorer();
                            //           },
                            //           child: Row(
                            //             children: <Widget>[
                            //               Expanded(
                            //                 flex: 1,
                            //                 child: Icon(
                            //                   Icons.attach_file,
                            //                   color: Color(0xFFBF2B38),
                            //                 ),
                            //               ),
                            //               Expanded(
                            //                 flex: 9,
                            //                 child: Text(
                            //                   "  Attach CNIC",
                            //                   style: TextStyle(
                            //                       color: Color(0xFFA2A2A2),
                            //                       fontSize: 14,
                            //                       fontFamily: "Roboto",
                            //                       fontWeight: FontWeight.normal),
                            //                 ),
                            //               ),
                            //             ],
                            //           ),
                            //         ),
                            //       ),
                            //       Container(
                            //         height: 1,
                            //         color: Colors.grey,
                            //         width: MediaQuery.of(context).size.width,
                            //         margin: EdgeInsets.only(left: 5, right: 5, top: 4),
                            //       ),
                            //       Flexible(
                            //         fit: FlexFit.loose,
                            //         child: Container(
                            //           margin: EdgeInsets.only(top: 20),
                            //           height: h2,
                            //           decoration: BoxDecoration(
                            //               // color: Colors.grey[200],
                            //               border:
                            //                   Border.all(color: Colors.grey[500], width: 1),
                            //               borderRadius: BorderRadius.circular(5.0)),
                            //           child: ListView(
                            //             controller: con,
                            //             children: childrenx,
                            //           ),
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                            // Container(
                            //   height: 100,
                            //   margin: EdgeInsets.only(left: 12, right: 12, bottom: 20),
                            //   child: Card(
                            //     child: Container(
                            //       padding: EdgeInsets.only(
                            //           left: 12, right: 12, bottom: 20, top: 20),
                            //       child: Column(
                            //         crossAxisAlignment: CrossAxisAlignment.start,
                            //         mainAxisAlignment: MainAxisAlignment.start,
                            //         children: <Widget>[
                            //           InkWell(
                            //             onTap: () {
                            //               openFileExplorer();
                            //             },
                            //             child: Row(
                            //               children: <Widget>[
                            //                 Expanded(
                            //                   flex: 1,
                            //                   child: Icon(
                            //                     Icons.attach_file,
                            //                     color: Color(0xFFBF2B38),
                            //                   ),
                            //                 ),
                            //                 Expanded(
                            //                   flex: 9,
                            //                   child: Text(
                            //                     "Attachments",
                            //                     style: TextStyle(
                            //                         color: Colors.grey[500],
                            //                         fontSize: 13,
                            //                         fontFamily: "Roboto",
                            //                         fontWeight: FontWeight.normal),
                            //                   ),
                            //                 ),
                            //               ],
                            //             ),
                            //           ),
                            //           // Flexible(
                            //           //   child: ListView(
                            //           //     children: children,
                            //           // ),
                            //           // ),
                            //         ],
                            //       ),
                            //     ),
                            //   ),
                            // ),

                            // new Container(
                            //   padding: EdgeInsets.all(20.0),
                            //   child: Column(
                            //     crossAxisAlignment: CrossAxisAlignment.start,
                            //     mainAxisAlignment: MainAxisAlignment.start,
                            //     children: <Widget>[
                            //       OutlineButton(
                            //         onPressed: () => openFileExplorer(),
                            //         child: new Text("Pick Documents"),
                            //       ),
                            //       SizedBox(
                            //         height: 20.0,
                            //       ),
                            //       Flexible(
                            //         child: ListView(
                            //           children: children,
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: bankNameController,
                                decoration: buildMyInputDecoration(
                                    context, 'Bank Name'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.next,
                                focusNode: _bankNameFocus,
                                onSaved: (String? value) => bankName = value!,
                                onFieldSubmitted: (term) {
                                  _bankNameFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_bankNumberFocus);
                                },
                                validator: validatebankName,
                              ),
                            ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: bankNumberController,
                                decoration: buildMyInputDecoration(
                                    context, 'Bank Number'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.next,
                                focusNode: _bankNumberFocus,
                                onSaved: (String? value) => bankNumber = value!,
                                onFieldSubmitted: (term) {
                                  _bankNumberFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_bloodGroupFocus);
                                },
                                validator: validatebankNumber,
                              ),
                            ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: bloodGroupController,
                                decoration: buildMyInputDecoration(
                                    context, 'Blood Group'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.next,
                                focusNode: _bloodGroupFocus,
                                onSaved: (String? value) => bloodGroup = value!,
                                onFieldSubmitted: (term) {
                                  _bloodGroupFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_addressFocus);
                                },
                                validator: validateBloodGroup,
                              ),
                            ),

                            Container(
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: addressController,
                                decoration: buildMyInputDecoration(
                                    context, 'Present Address'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.done,
                                focusNode: _addressFocus,
                                onSaved: (val) {
                                  locationVal = val!;
                                },
                                onFieldSubmitted: (term) {
                                  _addressFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_cnicAddressFocus);
                                },
                                validator: (val) {
                                  if (val!.isEmpty) {
                                    return "Please Enter Location";
                                  }
                                  if (val == null) {
                                    return "Please Enter Location";
                                  }
                                  if (val == "") {
                                    return "Please Enter Location";
                                  }
                                  if (val.length < 2) {
                                    return "Location Text must be greater than 2";
                                  }
                                },
                              ),
                            ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: cnicAddressController,
                                decoration: buildMyInputDecoration(
                                    context, 'Address as per CNIC'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.next,
                                focusNode: _cnicAddressFocus,
                                onSaved: (String? value) =>
                                    cnicAddress = value!,
                                onFieldSubmitted: (term) {
                                  _cnicAddressFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_emergencyPhoneFocus);
                                },
                                validator: validateCNICAddress,
                              ),
                            ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 10),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: emergencyPhoneController,
                                decoration: buildMyInputDecoration(
                                    context, 'Emergency Contact'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.done,
                                focusNode: _emergencyPhoneFocus,
                                                inputFormatters: [maskFormatter],

                                onSaved: (String? value) =>
                                    emergencyPhone = value!,
                                onFieldSubmitted: (term) {
                                  _emergencyPhoneFocus.unfocus();
                                },
                                // validator: validatePhone,
                                keyboardType: TextInputType.phone,
                              ),
                            ),

                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 10),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: cnicController,
                                textInputAction: TextInputAction.done,
                                decoration: buildMyInputDecoration(
                                    context, 'CNIC Number'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                // focusNode: _emergencyPhoneFocus,
                                onSaved: (String? value) => cnicNum = value!,
                                // onFieldSubmitted: (term) {
                                //   _emergencyPhoneFocus.unfocus();
                                // },
                                validator: validateCnic,
                                keyboardType: TextInputType.phone,
                              ),
                            ),
                            // Container(
                            //   margin:
                            //       const EdgeInsets.only(left: 15, right: 15),
                            //   // decoration: buildMyInputDecoration(context, 'Address as per CNIC'),
                            //   child: Text(
                            //     "Date of Birth*",
                            //     style: TextStyle(
                            //         color: Colors.grey[500],
                            //         fontSize: 11,
                            //         fontFamily: "Roboto",
                            //         fontWeight: FontWeight.normal),
                            //   ),
                            // ),
                            InkWell(
                              onTap: () {
                                _selectDate(context);
                                setState(() {});
                              },
                              child: Container(
                                
                                width: MediaQuery.of(context).size.width,
                                height: 50,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(3),
                                    // borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                                    border: Border.all(
                                        color: Colors.grey.withOpacity(0.2),
                                        width: 1)),
                                margin: const EdgeInsets.only(
                                    left: 15, right: 15, top: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(
                                      flex: 14,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 15, right: 15),
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          dobFormat ?? "Date of Birth",
                                          // dobFormat.toString(),
                                          style: TextStyle(
                                              color: dobFormat == null
                                                  ? const Color(0xFFA2A2A2)
                                                  : Colors.black87,
                                              fontSize: 14,
                                              fontFamily: "Roboto",
                                              fontWeight: FontWeight.w400),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        alignment: Alignment.centerLeft,
                                        child: const Icon(
                                        Icons.today,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            // Container(
                            //     height: 1,
                            //     color: Colors.grey,
                            //     width: MediaQuery.of(context).size.width,
                            //     margin: const EdgeInsets.only(
                            //         left: 15, right: 15, bottom: 20, top: 15)),
                            //Container(
                            //   margin:
                            //       const EdgeInsets.only(left: 27, right: 15),
                            //   child: Text(
                            //     "Age*",
                            //     style: TextStyle(
                            //         color: Colors.grey[500],
                            //         fontSize: 11,
                            //         fontFamily: "Roboto",
                            //         fontWeight: FontWeight.normal),
                            //   ),
                            // ),
                            Container(
                              height: 50,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(3),
                                  // borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                                  border: Border.all(
                                      color: Colors.grey.withOpacity(0.2),
                                      width: 1)),
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, top: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    flex: 14,
                                    child: Container(
                                      margin: const EdgeInsets.only(
                                          left: 15, right: 15),
                                      child: Text(
                                        agex.toString(),
                                        style: TextStyle(
                                            color: dobFormat == null
                                                ? const Color(0xFFA2A2A2)
                                                : Colors.black,
                                            fontSize: 14,
                                            fontFamily: "Roboto",
                                            fontWeight: FontWeight.normal),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                      alignment: Alignment.centerLeft,
                                      child: const Icon(
                                      Icons.today,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),


              //               Container(
              //                  margin: const EdgeInsets.only(
              //                left: 15, right: 15, bottom: 10, top: 15),
              //   height: 60,
              //   padding: const EdgeInsets.all(8),
              //   decoration: BoxDecoration(
              //       borderRadius: BorderRadius.circular(6),
              //       border: Border.all(
              //           color: Colors.grey.withOpacity(0.4), width: 1)),
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //     children: [
              //       Padding(
              //         padding: const EdgeInsets.only(left: 10),
              //         child: Text(
              //           dateOfBirth == null
              //               ? 'Date of Birth'
              //               : '${dateOfBirth!.day}/${dateOfBirth!.month}/${dateOfBirth!.year}'
              //                   .toString(),
              //           style: TextStyle(color: Colors.grey[800]),
              //         ),
              //       ),
              //       IconButton(
              //           icon: const Icon(Icons.today, color: Colors.grey),
              //           onPressed: () {
              //             showDatePicker(
              //                     context: context,
              //                     initialDate: DateTime(2010),
              //                     firstDate: DateTime(1900),
              //                     lastDate: DateTime(2021))
              //                 .then((value) {
              //               setState(() {
              //                 dateOfBirth = value;
              //               });
              //             });
              //           }),
              //     ],
              //   ),
              // ),
                            // Container(
                            //   height: 1,
                            //   color: Colors.grey,
                            //   width: MediaQuery.of(context).size.width,
                            //   margin: const EdgeInsets.only(
                            //       left: 15, right: 15, bottom: 20, top: 15),
                            // ),

                            Container(
                              margin:
                                  const EdgeInsets.only(left: 15, right: 15,top: 10),
                              child: const Text(
                                "Marital Status",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 14,
                                    fontFamily: "Roboto",
                                    fontWeight: FontWeight.normal),
                              ),
                            ),
                            Container(
                              margin:
                                  const EdgeInsets.only(left: 15, right: 10),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    flex: 1,
                                    child: Radio(
                                      value: 1,
                                      groupValue: selectedMaritalTile,
                                      onChanged: (int? val) {
                                        setSelectedMaritalTile(val!);
                                        print(
                                            "------------$selectedMaritalTile");
                                      },
                                      activeColor: Colors.red,
                                    ),
                                  ),
                                  Expanded(
                                      flex: 4,
                                      child: Text(
                                        "Single",
                                        style: TextStyle(
                                            color: selectedMaritalTile == 1
                                                ? const Color(0xFFBF2B38)
                                                : Colors.grey[700],
                                            fontSize: 15,
                                            fontFamily: "Roboto",
                                            fontWeight: FontWeight.normal),
                                      )),
                                  Expanded(
                                    flex: 1,
                                    child: Radio(
                                      value: 2,
                                      groupValue: selectedMaritalTile,
                                      onChanged: (int? val) {
                                        setSelectedMaritalTile(val!);
                                        print(
                                            "------------$selectedMaritalTile");
                                      },
                                      activeColor: Colors.red,
                                    ),
                                  ),
                                  Expanded(
                                      flex: 4,
                                      child: Text(
                                        "Married",
                                        style: TextStyle(
                                            color: selectedMaritalTile == 2
                                                ? const Color(0xFFBF2B38)
                                                : Colors.grey[700],
                                            fontSize: 15,
                                            fontFamily: "Roboto",
                                            fontWeight: FontWeight.normal),
                                      )),
                                ],
                              ),
                            ),
                            

                            Row(children: [
                Checkbox(
                  value: checkedValue,
                  activeColor: const Color(0xff6036D8),
                  onChanged: (newValue) {
                    setState(() {
                      checkedValue = newValue!;
                    });
                  },
                ),
               const  Text('Vaccinated against COVID'),
              ]),
              // const SizedBox(height: 15),
              //--------------buttons-------------------//
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                     margin:const EdgeInsets.only(left: 15,bottom: 10),
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: checkedValue == false
                                ? Colors.grey
                                : kPrimaryRed),
                        onPressed: checkedValue == false
                            ? null
                            : () async {
                              FilePickerResult? result = await FilePicker.platform.pickFiles(
                                  type: FileType.custom,
                                  allowedExtensions: ['pdf','jpg'],
                                )
                                .then((value){
                                  if(value == null){
                                  print('-------------------value is null so it nothing---------------------------')
                                  }else if(value != null){
                                    setState(() {
                                    path = value.toString();
                                    print('---------------------value is not-null it something--------------------')
                                  })
                                  }
                                });
                                  File file =  File(path!);
                                  fileName = file.path.split('/').last;
                                //  var namefile = file.absolute;
                                 print(fileName);
                                //  var x=fileName.split(',').first;
                                  
                              },
                        child: const Text('BROWSE')),
                  ),
                  const SizedBox(width: 25),
                  if (checkedValue != false)
                    SizedBox(
                      height: 30,
                      child: InkWell(
                          child: const Text("JPG Attachment",
                              style: TextStyle(
                                  decoration: TextDecoration.underline,
                                  color: Colors.blue)),
                          onTap: () async{
                                FilePickerResult? result = await FilePicker.platform.pickFiles(
                                type: FileType.custom,
                                allowedExtensions: ['jpg'],
                              )
                              .then((value){
                                if(value == null){
                                print('-----------------value is null so it nothing---------------------------')
                                }
                                else if(value != null){
                                  setState(() {
                                  path = value.toString();
                                  print('---------------------value is not-null it something--------------------')
                                })
                                }
                              });
                              File file =  File(path!);
                              fileName = file.path.split('/').last;
                               print(fileName!.split(',').first);
                          }),
                    ),
                  if (checkedValue == true) const SizedBox(),
                ],
              ),
              if (path != null) 
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                             margin:const EdgeInsets.only(left: 20,bottom: 10),
                      child: SizedBox(
                        
                        width: MediaQuery.of(context).size.width * 0.4,
                        child: Text(fileName!,
                        maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          softWrap: false,
                        style:const TextStyle()),
                      ),
                    ),
                    IconButton(onPressed: (){
                      setState(() {
                        path = null;
                        FilePicker.platform.clearTemporaryFiles().then((result) {
                          }); 
                      });
                    }, icon: const Icon(Icons.close)),
                  ],
                ),
              if(path == null)
             const  SizedBox(),

                            // Container(
                            //   margin: EdgeInsets.only(top: 9.0, left: 15, right: 15),
                            //   width: MediaQuery.of(context).size.width - 30,
                            //   height: 50,
                            //   child: OutlineButton(
                            //     borderSide: BorderSide(
                            //       // color: Colors.grey[500],
                            //       style: BorderStyle.solid,
                            //     ),
                            //     highlightElevation: 1,
                            //     highlightColor: Colors.transparent,
                            //     splashColor: Colors.transparent,
                            //     onPressed: () async {
                            //       try {
                            //         LocationResult result =
                            //             await showLocationPicker(
                            //           context,
                            //           "AIzaSyAvJyF8A3rklI6U2Y02ElzGf3_-k_ss0lk",
                            //         ).then((onValue) {
                            //           if (onValue != null) {
                            //             setState(() {
                            //               lat1 = onValue.latLng.latitude;
                            //               lng1 = onValue.latLng.longitude;
                            //               _polylines.clear();
                            //               _lastMapPosition = LatLng(lat1, lng1);
                            //               locationAddress = onValue.address;
                            //               locationLatitude = onValue.latLng.latitude;
                            //               locationLongitude = onValue.latLng.longitude;
                            //               addressController.text = onValue.address;
                            //               locationVal = onValue.address;
                            //             });

                            //             _onAddMarkerButtonPressed();

                            //             print(onValue.latLng);
                            //           } return onValue;
                            //         });
                            //         print("result = $result");
                            //       } catch (e) {
                            //         print("eeeeeeeeeeeee   $e");
                            //       }
                            //     },
                            //     child: Text('Pick Location'),
                            //   ),
                            // ),
                            // Container(
                            //   height: 300,
                            //   padding: EdgeInsets.all(10.0),
                            //   child: GoogleMap(
                            //     onMapCreated: _onMapCreated,
                            //     polylines: _polylines,
                            //     onTap: (LatLng latlng) {
                            //       print(latlng);
                            //     },
                            //     myLocationEnabled: true,
                            //     initialCameraPosition: CameraPosition(
                            //       target: _center,
                            //       zoom: 10.0,
                            //     ),
                            //     zoomGesturesEnabled: true,
                            //     mapType: _currentMapType,
                            //     markers: _markers,
                            //     onCameraMove: _onCameraMove,
                            //   ),
                            // ),

                            Row(
                              children: [
                                Expanded(
                                  child: SizedBox(
                                    height: 60,
                                    child: Container(
                                      margin:const EdgeInsets.only(
                                          left: 15, right: 15, bottom: 15),
                                      child: ElevatedButton(
                                        child: const Text('SAVE'), //next button
                                        style: ElevatedButton.styleFrom(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 10),
                                          primary: darkRed,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                        ),
                                        onPressed: () {
                                          validateAndSave();
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            )
                            //  Row(
                            //    children: [
                            //      Expanded(
                            //       child: SizedBox(
                            //         height: 60,
                            //         child: ElevatedButton(
                            //           child: const Text('SAVE'), //next button
                            //           style: ElevatedButton.styleFrom(
                            //             padding: EdgeInsets.symmetric(vertical: 10),
                            //             primary: Color(0xffC53B4B),
                            //             shape: RoundedRectangleBorder(
                            //                 borderRadius: BorderRadius.circular(10)),
                            //           ),
                            //           onPressed: () {
                            //             setState(() {});
                            //             // Navigator.pushReplacement(
                            //             //     context,
                            //             //     MaterialPageRoute(
                            //             //         builder: (context) => SecondProfile()));
                            //             //
                            //             // // Navigator.of(context).pushAndRemoveUntil(
                            //             // //     MaterialPageRoute(
                            //             // //         builder: (context) => SecondProfile()),
                            //             // //     (Route<dynamic> route) => false);
                            //             //
                            //             // var getEmail = controllerEmail.text;
                            //             // var getUserName = controllerUserName.text;
                            //             // var getFatherName = controllerFatherName.text;
                            //             // var getPhone = controllerPhone.text;
                            //             // var getCnic = controllerCNIC.text;
                            //             // var getAddress = controllerAddress.text;
                            //             // var getCity = dropCityValue;
                            //             // var getGender = dropGenderValue;
                            //             // var getStatus = dropStatusValue;
                            //             // var getDate = dateOfBirth;
                            //             //
                            //             // UserSaveData.instance.setStringValue("email", getEmail);
                            //             // UserSaveData.instance
                            //             //     .setStringValue("username", getUserName);
                            //             // UserSaveData.instance
                            //             //     .setStringValue("fathername", getFatherName);
                            //             // UserSaveData.instance.setStringValue("phone", getPhone);
                            //             // UserSaveData.instance.setStringValue("cnic", getCnic);
                            //             // UserSaveData.instance.setStringValue("city", getCity);
                            //             // UserSaveData.instance
                            //             //     .setStringValue("gender", getGender);
                            //             // UserSaveData.instance
                            //             //     .setStringValue("status", getStatus);
                            //             // UserSaveData.instance
                            //             //     .setStringValue("date", getDate.toString());
                            //             // UserSaveData.instance
                            //             //     .setStringValue("address", getAddress);
                            //           },
                            //         ),
                            //       ),
                            // ),
                            //    ],
                            //  ),
                          ],
                        ),
                      ),
                    ],
                  ))
            ])));
  }

  void _onAddMarkerButtonPressed() async {
    CameraPosition _kLake = CameraPosition(
        bearing: 192.8334901395799,
        target: _lastMapPosition,
        tilt: 59.440717697143555,
        zoom: 15.151926040649414);
    // final GoogleMapController controller = await _controller.future;
    // controller.animateCamera(CameraUpdate.newCameraPosition(_kLake));
    setState(() {
      _markers.clear();

      // _markers.add(const Marker(
      //   // This marker id can be anything that uniquely identifies each marker.
      //   // markerId: MarkerId(_lastMapPosition.toString()),
      //   //_lastMapPosition is any coordinate which should be your default
      //   //position when map opens up
      //   // position: _lastMapPosition,
      //   infoWindow: InfoWindow(
      //     title: 'Really cool place',
      //     snippet: '5 Star Rating',
      //   ),
      //   // icon: BitmapDescriptor.defaultMarker, markerId: null,
      // ));
      _polylines.add(Polyline(
        polylineId: PolylineId(_lastMapPosition.toString()),
        visible: true,
        points: [LatLng(lat, lng), LatLng(lat1, lng1)],
        color: Colors.red,
      ));
    });
  }

  void _onCameraMove(CameraPosition position) {
    _lastMapPosition = position.target;
  }

  void _onMapCreated(GoogleMapController controller) {
    // _controller.complete(controller);
  }

  String? validateAddress(String value) {
    if (value.length == 0)
      return "Address cann't be empty";
    else
      return null;
  }

  String? validateEmail(String? value) {
    Pattern? pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern.toString());
    if (!regex.hasMatch(value!))
      return 'Enter Valid Email';
    else
      return null;
  }

  validateAndSave() async {
    final form = _formKey.currentState;
    if (form!.validate()) {
      // if (dobFormat == "Date of Birth" || dobFormat == null) {
      //   Flushbar(
      //     messageText: Text(
      //       "Kindly select Birth date",
      //       style: TextStyle(
      //           fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
      //     ),
      //     duration: Duration(seconds: 3),
      //     isDismissible: true,
      //     icon: Image.asset(
      //       "assets/images/cancel.png",
      //       // scale: 1.0,
      //       height: 30,
      //       width: 30,
      //     ),
      //     backgroundColor: Color(0xFFBF2B38),
      //     margin: EdgeInsets.all(8),
      //     borderRadius: 8,
      //   )..show(context);
      // } else if (selectedMaritalTile == 0) {
      //   Flushbar(
      //     messageText: Text(
      //       "Kindly select Marital Status",
      //       style: TextStyle(
      //           fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
      //     ),
      //     duration: Duration(seconds: 3),
      //     isDismissible: true,
      //     icon: Image.asset(
      //       "assets/images/cancel.png",
      //       // scale: 1.0,
      //       height: 30,
      //       width: 30,
      //     ),
      //     backgroundColor: Color(0xFFBF2B38),
      //     margin: EdgeInsets.all(8),
      //     borderRadius: 8,
      //   )..show(context);
      // } else {
      showLoadingDialog(context);
      // File?  file;
      // File ? inputFile;
      // String?  filePath;
      // String?  url;
      // if (image != null) {
      //   filePath = await image!.name;
      //   file = File(filePath);
      //   //compressing the image
      //   ByteData byteData =
      //       await image!.getThumbByteData(700, 700, quality: 100);
      //   final buffer = byteData.buffer;
      //   Future<File> convertedFile =
      //       File(filePath).writeAsBytes(buffer.asUint8List());

      //   await convertedFile.then((onValue) {
      //     inputFile = onValue;
      //   });
      //   StorageUploadTask uploadTask;
      //   final StorageReference storageReference = FirebaseStorage()
      //       .ref()
      //       .child("EmployeeImage")
      //       .child(file.hashCode.toString() + ".jpg");
      //   uploadTask = storageReference.putFile(inputFile);
      //   //getting url for input picture
      //   url = await (await uploadTask.onComplete).ref.getDownloadURL();
      // } else {
      //   url = widget.data["photoURL"];
      // }

      FirebaseFirestore.instance
          .runTransaction((Transaction transaction) async {
        DocumentReference reference =
            FirebaseFirestore.instance.collection("employees").doc(userId);
              profilePicUrl =
            await uploadUserImageToFireStorage(_image,userId);
        await reference.update({
          // "photoURL": url == null ? null : url,
          // ignore: unnecessary_null_in_if_null_operators
          "phone": phoneController.text,
          "otherEmail": emailController.text,
          "bankName":
              bankNameController.text == "" ? null : bankNameController.text,
          "bankNumber": bankNumberController.text == ""
              ? null
              : bankNumberController.text,
          "bloodGroup": bloodGroupController.text == ""
              ? null
              : bloodGroupController.text,
          "cnic": cnicController.text,
          "maritalStatus": selectedMaritalTile == 1
              ? "Single"
              : selectedMaritalTile == 2
                  ? "Married"
                  : null,
          "age": agex.toString(),
          "cnicAddress": cnicAddressController.text == ""
              ? null
              : cnicAddressController.text,
          "emergencyPhone": emergencyPhoneController.text == ""
              ? null
              : emergencyPhoneController.text,
          "dob": dobFormat,
          "address":
              addressController.text == "" ? null : addressController.text,
          "imagePath": profilePicUrl,
          "fileName":fileName,
          "covidCheck":checkedValue,
        });
      }).whenComplete(() {
        Navigator.pop(context);

        Fluttertoast.showToast(msg: "Personal info is updated successfully");
      }).catchError((e) {
        print('======Error====$e==== ');
      });
      Future.delayed(const Duration(milliseconds: 1150), () {
        Navigator.of(context).pop();
      });
      // }
    } else {
      print('form is invalid');
    }
  }

  void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }

  String? validateFirstName(String value) {
    if (value.isEmpty) {
      return "First Name cann't be empty";
    } else {
      return null;
    }
  }

  String? validateLastName(String value) {
    if (value.isEmpty) {
      return "Last Name cann't be empty";
    } else {
      return null;
    }
  }

  String? validateCnic(String? value) {
    // This validator gets called by the formState(formKey) validate() function
    print("Vale :: ${value!.length}");
    if (value.isEmpty) {
      return "Cnic cann't be empty";
    } else if (value.length <= 13) {
      return "Cnic is not valid";
    }
    return null;
  }

  String? validategender(String value) {
    if (value.isEmpty) {
      return "Gender cann't be empty";
    } else {
      return null;
    }
  }

  String? validateage(String value) {
    if (value.isEmpty) {
      return "Age cann't be empty";
    } else {
      return null;
    }
  }

  String? validateCNICAddress(String? value) {
    if (value!.isEmpty) {
      return "Address as per CNIC cann't be empty";
    } else {
      return null;
    }
  }

  String? validatebankName(String? value) {
    if (value!.isEmpty) {
      return "Bank Name cann't be empty";
    } else {
      return null;
    }
  }

  String? validatePhone(String? value) {
    final RegExp phoneExp = RegExp(r'^\d\d\d\d\d\d\d\d\d\d\d$');

    if (value!.isEmpty) {
      return "Phone number can't be empty";
    } else if (value[0] != "0") {
      return "Phone number is not valid";
    } else if (value[1] != "3") {
      return "Phone number is not valid";
    } else if (value[2] == "5") {
      return "Phone number is not valid";
    } else if (value[2] == "6") {
      return "Phone number is not valid";
    } else if (value[2] == "7") {
      return "Phone number is not valid";
    } else if (value[2] == "8") {
      return "Phone number is not valid";
    } else if (value[2] == "9") {
      return "Phone number is not valid";
    } else if (!phoneExp.hasMatch(value)) {
      return "Phone number is not correct";
    }
    return null;
  }

  String? validateEmerPhone(String? value) {
    final RegExp phoneExp = RegExp(r'^\d\d\d\d\d\d\d\d\d\d\d$');

    if (value!.isEmpty) {
      return "Phone number can't be empty";
    } else if (value[0] != "0") {
      return "Phone number is not valid";
    } else if (value[1] != "3") {
      return "Phone number is not valid";
    } else if (value[2] == "5") {
      return "Phone number is not valid";
    } else if (value[2] == "6") {
      return "Phone number is not valid";
    } else if (value[2] == "7") {
      return "Phone number is not valid";
    } else if (value[2] == "8") {
      return "Phone number is not valid";
    } else if (value[2] == "9") {
      return "Phone number is not valid";
    } else if (!phoneExp.hasMatch(value)) {
      return "Phone number is not correct";
    }
    return null;
  }

  String? validatebankNumber(String? value) {
    if (value!.isEmpty) {
      return "Bank Number cann't be empty";
    } else {
      return null;
    }
  }

  String? validateBloodGroup(String? value) {
    if (value!.isEmpty) {
      return "Blood Group cann't be empty";
    } else {
      return null;
    }
  }

  String? validateEmploymentStatus(String value) {
    if (value.isEmpty) {
      return "Employment Status cann't be empty";
    } else {
      return null;
    }
  }

  //  Widget buildButtonColumn(IconData  icon,    onPress) {
  //   var column = new Container(
  //       height: 93.0,
  //       width: 93.0,
  //       child: Icon(
  //         Icons.camera_alt,
  //         size: 55,
  //         color: Color(0xFFBF2B38),
  //       ));

  //   var inkWell = new InkWell(
  //     child: column,
  //     onTap: onPress,
  //   );

  //   return inkWell;
  // }

  // _uploadImage() {
  //   print("image uploaded");
  //   // loadAssets();
  //}

  // Future<void> loadAssets() async {
  //   List?  resultList;
  //   // Asset result;
  //   // Asset tempImages;
  //   String?  error;

  //   try {
  //     resultList = await MultiImagePicker.pickImages(
  //       enableCamera: true,
  //       maxImages: 1,
  //     );
  //   } on PlatformException catch (e) {
  //     error = e.message;
  //   }
  //   // int i = 0;
  //   if (!mounted) return;
  //   if (resultList!.length > 0) {
  //     print(resultList[0]);
  //     // image = resultList[0];

  //     // int count = 0;

  //     // setState(() {
  //     //   image = resultList![0];
  //     // });
  //   }
  // }

}

// class z

// class AssetState extends State<AssetView> {
//   int ? _index = 0;
//   Asset ?  _asset;
//   AssetState(this._index, this._asset);
//   File ?  file;
//   String ? filePath;
//   @override
//   void initState() {
//     super.initState();
//     _loadImage();
//   }

//   void _loadImage() async {
//     filePath = await this._asset!.name;
//     file = File(filePath!);

//     if (this.mounted) {
//       setState(() {});
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (this._asset!.name != "removed") {
//       if (null != file) {
//         return RotatedBox(
//           quarterTurns: 4,
//           child: Image.file(
//             file!,
//             fit: BoxFit.fill,
//             height: 192.0,
//             width: 199.0,
//             gaplessPlayback: true,
//           ),
//         );
//       }
//     }

//     return Container();
//     // return Text(
//     //   '${this._index}',
//     //   style: Theme.of(context).textTheme.headline,
//     // );
//   }
// }

// class AssetView1 extends StatefulWidget {
//   final int _index;
//   final Asset _asset;

//   AssetView1(
//     this._index,
//     this._asset, {
//     Key?  key,
//   }) : super(key: key);

//   @override
//   State<StatefulWidget> createState() =>
//       AssetView1State(this._index, this._asset);
// }

// class AssetView1State extends State<AssetView1> {
//   int ? _index = 0;
//   Asset?  _asset;
//   AssetView1State(this._index, this._asset);
//   File ? file;
//   String?  filePath;
//   @override
//   void initState() {
//     super.initState();
//     _loadImage();
//   }

//   void _loadImage() async {
//     filePath = await this._asset!.name;
//     file = File(filePath!);

//     if (this.mounted) {
//       setState(() {});
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     if (this._asset!.name != "removed") {
//       if (null != file) {
//         if (this._asset!.isPortrait) {
//           return RotatedBox(
//             quarterTurns: 0,
//             // angle: math.pi / 4,
//             child: Image.file(
//               file!,
//               // alignment: Alignment.center,
//               fit: BoxFit.cover,
//               height: 192.0,
//               width: 199.0,
//               gaplessPlayback: true,
//             ),
//           );
//         } else {
//           return Image.file(
//             file!,
//             // alignment: Alignment.center,
//             fit: BoxFit.cover,
//             height: 192.0,
//             width: 199.0,
//             gaplessPlayback: true,
//           );
//         }
//       }
//     }

//     return Container();
//     // return Text(
//     //   '${this._index}',
//     //   style: Theme.of(context).textTheme.headline,
//     // );
//   }
// }
