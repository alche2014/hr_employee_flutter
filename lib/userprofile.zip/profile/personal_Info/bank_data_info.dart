import 'dart:async';
import 'dart:io';

// import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_offline/flutter_offline.dart';
import 'package:flutter_picker/flutter_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/mainApp/work_info/utility/build_my_input_decoration.dart';
import 'package:intl/intl.dart';

import '../../colors.dart';
// import 'package:multi_image_picker/multi_image_picker.dart';

// employee add his/her personal information in this screen
class BankdataInfo extends StatefulWidget {
  final data;
  BankdataInfo({Key? key, this.data}) : super(key: key);
  @override
  _BankdataInfoState createState() => _BankdataInfoState();
}

class _BankdataInfoState extends State<BankdataInfo> {
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  // bool isNetwork = true;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  GlobalKey<FormState> locationFormKey = GlobalKey<FormState>();
  late double locationLatitude;
  late double locationLongitude;
  List locationData = [];
  // GoogleMapPolyline googleMapPolyline =
  //     new GoogleMapPolyline(apiKey: "AIzaSyAvJyF8A3rklI6U2Y02ElzGf3_-k_ss0lk");
  // Completer<GoogleMapController> _controller = Completer();

  static const LatLng _center = LatLng(31.4697, 74.2728);
  var lat;
  var lng;
  var lat1;
  var lng1;
  var _pickedLocation;

  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  // Map<String, String>  _paths;

  LatLng _lastMapPosition = _center;
  MapType _currentMapType = MapType.normal;
  late bool showMap;
  var locationAddress;
  late String locationVal;
  bool mapshow = false;

  late String address;
  late String phone;
  late String email;
  late String cnic;
  late String age;
  //  Asset  ? image;
  late String bankName;
  late String bankNumber;
  late String cnicAddress;
  late String emergencyPhone;
  late String bloodGroup;

  // late File _image;
  late bool assetImage;
  late bool netImage;
  late String userId;

  List finals = [];
  List perfect = [];
  var cnicNum;

  final FocusNode _bankNameFocus = FocusNode();
  final FocusNode _bankNumberFocus = FocusNode();

  TextEditingController bankNameController = TextEditingController();
  TextEditingController bankNumberController = TextEditingController();

  var dobFormat;
  int agex = 0;
  late DateTime dob;
  String birthDate = "";
  var camera;

  _selectDate(BuildContext context) {
    Picker(
        hideHeader: true,
        adapter: DateTimePickerAdapter(yearEnd: DateTime.now().year),
        title: const Text(
          "Date of Birth",
          style: TextStyle(
            color: Color(0xFFBF2B38),
          ),
        ),
        selectedTextStyle: const TextStyle(
          color: Color(0xFFBF2B38),
        ),
        onConfirm: (Picker picker, List value) {
          setState(() {
            dob = (picker.adapter as DateTimePickerAdapter).value!;
            dobFormat = DateFormat('dd-MMM-yyyy').format(dob);
            calculateAge(dob);
          });
        }).showDialog(context);
  }

  calculateAge(DateTime dob) {
    DateTime currentDate = DateTime.now();
    var year = DateFormat('yyyy').format(dob);
    var month = DateFormat('MM').format(dob);
    var day = DateFormat('dd').format(dob);
    var syear = int.parse(year);
    var smonth = int.parse(month);
    var sday = int.parse(day);
    agex = currentDate.year - syear;

    int month1 = currentDate.month;
    int month2 = smonth;
    if (month2 > month1) {
      agex--;
    } else if (month1 == month2) {
      int day1 = currentDate.day;
      int day2 = sday;
      if (day2 > day1) {
        agex--;
      }
    }
    return agex;
  }

  late String _extension;
  late FileType _pickType;
  bool _multiPick = true;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  // List<StorageUploadTask> _tasks = <StorageUploadTask>[];
  int selectedMaritalTile = 1;

  setSelectedMaritalTile(int val) {
    setState(() {
      selectedMaritalTile = val;
    });
  }

  // void openFileExplorer() async {
  //   try {
  //     if (_multiPick) {
  //       _paths = await FilePicker.getMultiFilePath(
  //           type: _pickType,);
  //     }
  //     uploadToFirebase();
  //   } on PlatformException catch (e) {
  //     print("Unsupported operation" + e.toString());
  //   }
  //   if (!mounted) return;
  // }

  // uploadToFirebase() {
  //   if (_multiPick) {
  //     _paths!.forEach((fileName, filePath) => {upload(fileName, filePath)});
  //   }
  // }

  // upload(fileName, filePath) {
  //   _extension = fileName.toString().split('.').last;
  //   StorageReference storageRef =
  //       FirebaseStorage.instance.ref().child("Documents/$fileName");
  //   final StorageUploadTask uploadTask = storageRef.putFile(
  //     File(filePath),
  //     StorageMetadata(
  //       contentType: '$_pickType/$_extension',
  //     ),
  //   );
  //   setState(() {
  //     _tasks.add(uploadTask);
  //   });
  // }

  ScrollController? con;

  @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          // isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          // isNetwork = true;
        });
      }
    });
    // widget.data["photoURL"] != null ? netImage = true : netImage = false;
    // widget.data["photoURL"] != null ? assetImage = false : assetImage = true;
    userId = widget.data["uid"];

    bankNumberController = TextEditingController(
      text: widget.data["bankNo"],
    );
    bankNameController = TextEditingController(
      text: widget.data["bnkName"],
    );

    con = ScrollController();
    con!.addListener(() {
      if (con!.offset >= con!.position.maxScrollExtent &&
          !con!.position.outOfRange) {
        setState(() {});
      } else if (con!.offset <= con!.position.minScrollExtent &&
          !con!.position.outOfRange) {
        setState(() {});
      } else {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> childrenx = <Widget>[];

    double h2 = 0.0 + (childrenx.length * 80);
    double h = 45.0 + h2;

    return Form(
        key: _formKey,
        child: Scaffold(
            extendBodyBehindAppBar: true,
            key: _scaffoldKey,
            body: Stack(children: [
              const BackgroundCircle(),
              NestedScrollView(
                  headerSliverBuilder: (context, innerBoxIsScrolled) => [
                        buildMyNewAppBar(context, 'Bank Info', true),
                      ],
                  body: Stack(
                    children: [
                      SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: bankNameController,
                                decoration: buildMyInputDecoration(
                                    context, 'Bank Name'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.next,
                                focusNode: _bankNameFocus,
                                onSaved: (String? value) => bankName = value!,
                                onFieldSubmitted: (term) {
                                  _bankNameFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_bankNumberFocus);
                                },
                                validator: validatebankName,
                              ),
                            ),
                            Container(
                              // height: 40,
                              margin: const EdgeInsets.only(
                                  left: 15, right: 15, bottom: 20),
                              width: MediaQuery.of(context).size.width - 10,
                              child: TextFormField(
                                controller: bankNumberController,
                                decoration: buildMyInputDecoration(
                                    context, 'Bank Number'),
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                textInputAction: TextInputAction.next,
                                focusNode: _bankNumberFocus,
                                onSaved: (String? value) => bankName = value!,
                                onFieldSubmitted: (term) {
                                  _bankNumberFocus.unfocus();
                                  FocusScope.of(context)
                                      .requestFocus(_bankNumberFocus);
                                },
                                validator: validatebankNumber,
                              ),
                            ),
                            Container(
                                height: 1,
                                color: Colors.grey,
                                width: MediaQuery.of(context).size.width,
                                margin: const EdgeInsets.only(
                                    left: 15, right: 15, bottom: 20, top: 15)),
                            Row(
                              children: [
                                Expanded(
                                  child: SizedBox(
                                    height: 60,
                                    child: Container(
                                      margin: EdgeInsets.only(
                                          left: 15, right: 15, bottom: 15),
                                      child: ElevatedButton(
                                        child: const Text('SAVE'), //next button
                                        style: ElevatedButton.styleFrom(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 10),
                                          primary: darkRed,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                        ),
                                        onPressed: () {
                                          validateAndSave();
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ))
            ])));
  }

  String? validateAddress(String value) {
    if (value.isEmpty) {
      return "Address cann't be empty";
    } else {
      return null;
    }
  }

  String? validateEmail(String? value) {
    Pattern? pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = RegExp(pattern.toString());
    if (!regex.hasMatch(value!)) {
      return 'Enter Valid Email';
    } else {
      return null;
    }
  }

  validateAndSave() async {
    final form = _formKey.currentState;
    if (form!.validate()) {
      showLoadingDialog(context);

      FirebaseFirestore.instance
          .runTransaction((Transaction transaction) async {
        DocumentReference reference =
            FirebaseFirestore.instance.collection("employees").doc(userId);
        await reference.update({
          "bnkName":
              bankNameController.text == "" ? null : bankNameController.text,
          "bankNo": bankNumberController.text == ""
              ? null
              : bankNumberController.text,
        });
      }).whenComplete(() {
        // Navigator.pop(context);

        Fluttertoast.showToast(msg: "Account info is updated successfully");
      }).catchError((e) {
        print('======Error====$e==== ');
      });
      Future.delayed(const Duration(milliseconds: 1150), () {
        Navigator.of(context).pop();
      });
      // }
    } else {
      // ignore: avoid_print
      print('form is invalid');
    }
  }

  void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }

  String? validateFirstName(String value) {
    if (value.isEmpty) {
      return "First Name cann't be empty";
    } else {
      return null;
    }
  }

  String? validateLastName(String value) {
    if (value.isEmpty) {
      return "Last Name cann't be empty";
    } else {
      return null;
    }
  }

  String? validateCnic(String? value) {
    // This validator gets called by the formState(formKey) validate() function
    print("Vale :: ${value!.length}");
    if (value.isEmpty) {
      return "Cnic cann't be empty";
    } else if (value.length <= 13) {
      return "Cnic is not valid";
    }
    return null;
  }

  String? validategender(String value) {
    if (value.isEmpty) {
      return "Gender cann't be empty";
    } else {
      return null;
    }
  }

  String? validateage(String value) {
    if (value.isEmpty) {
      return "Age can't be empty";
    } else {
      return null;
    }
  }

  String? validateCNICAddress(String? value) {
    if (value!.isEmpty) {
      return "Address as per CNIC cann't be empty";
    } else {
      return null;
    }
  }

  String? validatebankName(String? value) {
    if (value!.isEmpty) {
      return "Bank Name cann't be empty";
    } else {
      return null;
    }
  }

  String? validatePhone(String? value) {
    final RegExp phoneExp = RegExp(r'^\d\d\d\d\d\d\d\d\d\d\d$');

    if (value!.isEmpty) {
      return "Phone number can't be empty";
    } else if (value[0] != "0") {
      return "Phone number is not valid";
    } else if (value[1] != "3") {
      return "Phone number is not valid";
    } else if (value[2] == "5") {
      return "Phone number is not valid";
    } else if (value[2] == "6") {
      return "Phone number is not valid";
    } else if (value[2] == "7") {
      return "Phone number is not valid";
    } else if (value[2] == "8") {
      return "Phone number is not valid";
    } else if (value[2] == "9") {
      return "Phone number is not valid";
    } else if (!phoneExp.hasMatch(value)) {
      return "Phone number is not correct";
    }
    return null;
  }

  String? validateEmerPhone(String? value) {
    final RegExp phoneExp = RegExp(r'^\d\d\d\d\d\d\d\d\d\d\d$');

    if (value!.length == 0) {
      return "Phone number can't be empty";
    } else if (value[0] != "0") {
      return "Phone number is not valid";
    } else if (value[1] != "3") {
      return "Phone number is not valid";
    } else if (value[2] == "5") {
      return "Phone number is not valid";
    } else if (value[2] == "6") {
      return "Phone number is not valid";
    } else if (value[2] == "7") {
      return "Phone number is not valid";
    } else if (value[2] == "8") {
      return "Phone number is not valid";
    } else if (value[2] == "9") {
      return "Phone number is not valid";
    } else if (!phoneExp.hasMatch(value)) {
      return "Phone number is not correct";
    }
    return null;
  }

  String? validatebankNumber(String? value) {
    if (value!.length == 0)
      return "Bank Number cann't be empty";
    else
      return null;
  }

  String? validateBloodGroup(String? value) {
    if (value!.isEmpty) {
      return "Blood Group cann't be empty";
    } else {
      return null;
    }
  }

  String? validateEmploymentStatus(String value) {
    if (value.isEmpty) {
      return "Employment Status cann't be empty";
    } else {
      return null;
    }
  }
}
