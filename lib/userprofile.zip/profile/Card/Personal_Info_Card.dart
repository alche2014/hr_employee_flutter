import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr_app/mainApp/Personal_Info/contact_info.dart';
import 'package:hr_app/mainUtility/share_preference.dart';
import '../../../colors.dart';

class PersonalInfoCard extends StatefulWidget {
  final data;
  const PersonalInfoCard({
    Key? key,
    this.data,
  }) : super(key: key);

  @override
  _PersonalInfoCardState createState() => _PersonalInfoCardState();
}

class _PersonalInfoCardState extends State<PersonalInfoCard> {
  var gender;
  var dropGenderValue;
  var dropCityValue;
  var dropBloodGroup;
  // String? path;
  // String? fileName;

  // File? image;
  // String? imagePath;

  // Future pickImage() async {
  //   try {
  //     final image =
  //         await ImagePicker.platform.pickImage(source: ImageSource.gallery);
  //     if (image == null) return;

  //     setState(() {
  //       imagePath = image.path;
  //       print("ImgPath:::::::::::::${imagePath}");
  //       // this.image = imageTemp;
  //       // saveImage(this.image);
  //     });
  //     saveImage('SaveImage', image.path);
  //   } on PlatformException catch (e) {
  //     print('Access Rejected: $e');
  //   }
  // }

  // @override
  // void initState() {
  //   super.initState();
  //   loadImage('SaveImage').then((value) {
  //     setState(() {
  //       imagePath = value;
  //     });
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.withOpacity(0.4), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Personal Info',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, color: darkRed)),
                IconButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ContactInfo(data: widget.data)));
                    },
                    icon: const Icon(Icons.edit_outlined, color: Colors.grey)),
              ]),
              personalInfo(widget.data),
              const SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }

  Widget personalInfo(snapshot) {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.only(bottom: 15, left: 8, right: 8),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // InkWell(
          //   onTap: () {
          //     showModalBottomSheet(
          //         context: context,
          //         builder: (BuildContext bc) {
          //           return Wrap(
          //             children: <Widget>[
          //               ListTile(
          //                 leading: const Icon(Icons.image),
          //                 title: Text('Gallery'),
          //                 onTap: () {
          //                   Navigator.pop(context);
          //                   pickImage();
          //                 },
          //               ),
          //             ],
          //           );
          //         });
          //   },
          //   child: Stack(
          //     //using stack to lap edit icon over Picture
          //     children: [
          //       // imagePath != null
          //       //     ? CircleAvatar(
          //       //         radius: 50,
          //       //         child: ClipRRect(
          //       //           clipBehavior: Clip.antiAlias,
          //       //           borderRadius: BorderRadius.circular(100),
          //       //           child: Image(
          //       //             image: FileImage(File(imagePath!)),
          //       //             height: 114,
          //       //             width: 115,
          //       //             fit: BoxFit.cover,
          //       //           ),
          //       //         ),
          //       //       )
          //       //     : CircleAvatar(
          //       //         radius: 50,
          //       //         child: ClipRRect(
          //       //           clipBehavior: Clip.antiAlias,
          //       //           borderRadius: BorderRadius.circular(100),
          //       //           child: image != null
          //       //               ? Image.file(image!)
          //       //               : Image.asset(
          //       //                   "assets/user_image.png",
          //       //                   height: 114,
          //       //                   width: 115,
          //       //                   fit: BoxFit.cover,
          //       //                 ),
          //       //         ),
          //       //       ),
          //       Positioned(
          //           bottom: 10,
          //           right: 0,
          //           child: Image(
          //             image: const AssetImage('assets/custom/Vector.png'),
          //             width: 30,
          //             fit: BoxFit.cover,
          //           )),
          //     ],
          //   ),
          // ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 3,
                  child: Text(
                    "Phone: ",
                    style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: const EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["phone"] ?? "Phone",
                      style: TextStyle(
                          color: snapshot["phone"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 3,
                  child: Text(
                    "Other Email: ",
                    style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: const EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["otherEmail"] ?? "Email",
                      style: TextStyle(
                          color: snapshot["otherEmail"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          // Container(
          //   margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 1,
          //         child: Icon(
          //           Icons.folder_shared,
          //           color: Color(0xFFBF2B38),
          //           size: 18,
          //         ),
          //       ),
          //       Expanded(
          //         flex: 3,
          //         child: Container(
          //           child: Text(
          //             "CNIC: ",
          //             style: TextStyle(
          //                 color: Colors.grey[700],
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 14),
          //           ),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["cnic"] == null ? "CNIC" : snapshot["cnic"],
          //             style: TextStyle(
          //                 color: snapshot["cnic"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          // Container(
          //   margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 4,
          //         child: Text(
          //           "Bank Name: ",
          //           style: TextStyle(
          //               color: Colors.grey[700],
          //               fontWeight: FontWeight.w400,
          //               fontSize: 14),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Text(
          //           snapshot["bankName"] ?? "Bank Name",
          //           style: TextStyle(
          //               color: snapshot["bankName"] == null
          //                   ? Colors.grey[500]
          //                   : Colors.black,
          //               fontWeight: FontWeight.w400,
          //               fontSize: 15),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          // Container(
          //   margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 4,
          //         child: Text(
          //           "Bank Number: ",
          //           style: TextStyle(
          //               color: Colors.grey[700],
          //               fontWeight: FontWeight.w400,
          //               fontSize: 14),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           // margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["bankNumber"] ?? "Bank Number",
          //             style: TextStyle(
          //                 color: snapshot["bankNumber"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 4,
                  child: Text(
                    "Blood Group: ",
                    style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Text(
                    snapshot["bloodGroup"] ?? "Blood Group",
                    style: TextStyle(
                        color: snapshot["bloodGroup"] == null
                            ? Colors.grey[500]
                            : Colors.black,
                        fontWeight: FontWeight.w400,
                        fontSize: 15),
                  ),
                )
              ],
            ),
          ),
          // Container(
          //   margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 1,
          //         child: Icon(
          //           Icons.nature_people,
          //           color: Color(0xFFBF2B38),
          //           size: 18,
          //         ),
          //       ),
          //       Expanded(
          //         flex: 3,
          //         child: Container(
          //           child: Text(
          //             "Age: ",
          //             style: TextStyle(
          //                 color: Colors.grey[700],
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 14),
          //           ),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["age"] == null ? "Age" : snapshot["age"],
          //             style: TextStyle(
          //                 color: snapshot["age"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          // Container(
          //   margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 1,
          //         child: Icon(
          //           Icons.date_range,
          //           color: Color(0xFFBF2B38),
          //           size: 18,
          //         ),
          //       ),
          //       Expanded(
          //         flex: 3,
          //         child: Container(
          //           child: Text(
          //             "DOB: ",
          //             style: TextStyle(
          //                 color: Colors.grey[700],
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 14),
          //           ),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["dob"] == null ? "Dob" : snapshot["dob"],
          //             style: TextStyle(
          //                 color: snapshot["dob"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 4,
                  child: Container(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      "Marital Status: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: const EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["maritalStatus"] ?? "Marital Status",
                      style: TextStyle(
                          color: snapshot["maritalStatus"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 4,
                  child: Text(
                    "Permanent Address: ",
                    style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Text(
                    snapshot["address"] ?? "Address",
                    style: TextStyle(
                        color: snapshot["address"] == null
                            ? Colors.grey[500]
                            : Colors.black,
                        fontWeight: FontWeight.w400,
                        fontSize: 15),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 4,
                  child: Text(
                    "Address Per CNIC: ",
                    style: TextStyle(
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Text(
                    snapshot["cnicAddress"] ?? "Address Per CNIC",
                    style: TextStyle(
                        color: snapshot["cnicAddress"] == null
                            ? Colors.grey[500]
                            : Colors.black,
                        fontWeight: FontWeight.w400,
                        fontSize: 15),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 4,
                  child: Container(
                    padding: const EdgeInsets.only(right: 5),
                    child: Text(
                      "Emergency Contact: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Text(
                    snapshot["emergencyPhone"] ?? "Emergency Contact",
                    style: TextStyle(
                        color: snapshot["emergencyPhone"] == null
                            ? Colors.grey[500]
                            : Colors.black,
                        fontWeight: FontWeight.w400,
                        fontSize: 15),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
    // });
  }
}

class MyTextField extends StatelessWidget {
  const MyTextField({
    Key? key,
    required this.hint,
  }) : super(key: key);
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: TextField(
        enabled: false,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          filled: true,
          fillColor: Theme.of(context).scaffoldBackgroundColor,
          hintText: hint,
          hintStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }
}
