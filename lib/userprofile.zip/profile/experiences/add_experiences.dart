// ignore_for_file: prefer_typing_uninitialized_variables, unnecessary_string_escapes, prefer_const_declarations, prefer_const_constructors
import 'dart:async';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/mainApp/experiences/main_experiences.dart';
import 'package:hr_app/mainApp/work_info/utility/build_my_input_decoration.dart';
import 'package:intl/intl.dart';
import 'package:month_picker_dialog/month_picker_dialog.dart';

import '../../../colors.dart';

class AddExperience extends StatelessWidget {
  final data, uid, editable;
  const AddExperience({Key? key, this.data, this.uid, this.editable})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      // appBar: buildMyAppBar(context, 'Add Experience', true),
      body: Stack(
        children: [
          BackgroundCircle(),
          NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              buildMyNewAppBar(context, 'Add Experience', true),
            ],
            body: SingleChildScrollView(
              child: Column(
                children: [
                  AddExperienceBody(userData: data, editExp: editable),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AddExperienceBody extends StatefulWidget {
  final userData, editExp;
  const AddExperienceBody({Key? key, this.userData, this.editExp})
      : super(key: key);

  @override
  _AddExperienceBodyState createState() => _AddExperienceBodyState();
}

class _AddExperienceBodyState extends State<AddExperienceBody> {
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  bool isNetwork = true;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late String compName;
  late String title;
  late String description;
  late String headline;
  late String location;
  late ScrollController con;

  @override
  void initState() {
    super.initState();
    userId = widget.userData["uid"];
    con = ScrollController();
    con.addListener(() {
      if (con.offset >= con.position.maxScrollExtent &&
          !con.position.outOfRange) {
        setState(() {});
      } else if (con.offset <= con.position.minScrollExtent &&
          !con.position.outOfRange) {
        setState(() {});
      } else {
        setState(() {});
      }
    });

    //check internet connection
    connectivity = Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      // print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });
    if (widget.editExp == true) {
      companyNameController = TextEditingController(
        text: widget.userData["companyName"],
      );
      titlesController = TextEditingController(
        text: widget.userData["title"],
      );
      descriptionController = TextEditingController(
        text: widget.userData["jobDescription"],
      );
      dateFormat = widget.userData['expstartDate'];
      todateFormat = widget.userData['expLastDate'];
      headlineController =
          TextEditingController(text: widget.userData["expHeadline"]);
      empStatus = widget.userData['empStatus'];

      locationController = TextEditingController(
        text: widget.userData["expLocation"],
      );
      checkedValue =
          widget.userData['currentyWorkingCheck'] == null ? false : true;

      industryValue = widget.userData['industry'];
    }
  }

  final FocusNode _titleFocus = FocusNode();
  final FocusNode _companyNameFocus = FocusNode();
  final FocusNode _locationFocus = FocusNode();
  final FocusNode _headlineFocus = FocusNode();
  final FocusNode _descriptionFocus = FocusNode();

  TextEditingController titlesController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController headlineController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  late Map<String, String> _paths;

  DateTime? selectedDate;
  var dateFormat;
  DateTime? toselectedDate;
  var todateFormat;

  late String _extension;
  late FileType _pickType;
  final bool _multiPick = true;
  late String userId;

  // GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final List<UploadTask> _tasks = <UploadTask>[];

  uploadToFirebase() {
    if (_multiPick) {
      _paths.forEach((fileName, filePath) => {upload(fileName, filePath)});
    }
  }

  static Reference storage = FirebaseStorage.instance.ref();

  upload(fileName, filePath) async {
    _extension = fileName.toString().split('.').last;
    Reference upload = storage.child("Documents/$fileName");
    UploadTask uploadTask = upload.putFile(filePath);
    var downloadUrl =
        (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    setState(() {
      _tasks.add(uploadTask);
    });
    return downloadUrl.toString();
    // StorageReference storageRef =
    //     FirebaseStorage.instance.ref().child("Documents/$fileName");
    // final StorageUploadTask uploadTask = storageRef.putFile(
    //   File(filePath),
    //   StorageMetadata(
    //     contentType: '$_pickType/$_extension',
    //   ),
    // );
  }

  var dropGenderValue;
  var industryValue;
  bool checkedValue = false;
  var empStatus;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: titlesController,
                decoration: buildMyInputDecoration(context, 'Title'),
                focusNode: _titleFocus,
                onFieldSubmitted: (term) {
                  _titleFocus.unfocus();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
                // validator:validateCompanyName,
                onSaved: (String? value) => title = value!,
              ),
              const SizedBox(height: 15),
              //------------------------------------------------------------//
              Container(
                height: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: Colors.grey.shade300.withOpacity(0.8),
                    width: 2,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: DropdownButtonFormField(
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(
                            Radius.circular(6.0),
                          ),
                        ),
                        hintText: "Employment Status",
                        fillColor: Theme.of(context).scaffoldBackgroundColor),
                    value: empStatus,
                    items: <String>['Full time', 'Half time']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        empStatus = value;
                        print("Employeee Status::::::::::::$empStatus");
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 15),
              //-------------------------------------------------//
              TextFormField(
                controller: companyNameController,
                decoration: buildMyInputDecoration(context, 'Company Name'),
                focusNode: _companyNameFocus,
                onFieldSubmitted: (term) {
                  _companyNameFocus.unfocus();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
                // validator:validateCompanyName,
                onSaved: (String? value) => compName = value!,
              ),
              const SizedBox(height: 15),
              //-------------------------------------------------//
              TextFormField(
                controller: locationController,
                decoration: buildMyInputDecoration(context, 'Location'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                onSaved: (String? value) => location = value!,
                focusNode: _locationFocus,
                onFieldSubmitted: (term) {
                  _locationFocus.unfocus();
                },
                // validator:validateLocation
              ),
              const SizedBox(height: 8),
              //-------------------------------------------------//
              Row(children: [
                Checkbox(
                  value: checkedValue,
                  activeColor: const Color(0xff61C1D1),
                  onChanged: (newValue) {
                    setState(() {
                      checkedValue = newValue!;
                    });
                  },
                ),
                Text('I am currently working in this role'),
              ]),
              //--------------------------------------------------//
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(children: [
                  Expanded(
                      child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                        border: Border.all(
                            color: Colors.grey.shade300.withOpacity(0.8),
                            width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(dateFormat ?? "Start Date",
                              style: TextStyle(color: Colors.black)),
                        ),
                        IconButton(
                            icon: const Icon(Icons.today, color: Colors.grey),
                            onPressed: () {
                              showMonthPicker(
                                      context: context,
                                      firstDate: (DateTime.now())
                                          .subtract(Duration(days: 500000)),
                                      lastDate: toselectedDate,
                                      initialDate: DateTime.now())
                                  .then((date) => setState(() {
                                        selectedDate = date;
                                        dateFormat = DateFormat("MMMM yyyy")
                                            .format(selectedDate!);
                                      }));

                              // showDatePicker(
                              //     context: context,
                              //     initialDate: DateTime(2005),
                              //     firstDate: DateTime(2000),
                              //     lastDate: DateTime.now());
                            })
                      ],
                    ),
                  )),
                  SizedBox(width: 10),
                  Expanded(
                      child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                        border: Border.all(
                            color: Colors.grey.shade300.withOpacity(0.8),
                            width: 2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Text(todateFormat ?? " End Date",
                              style: TextStyle(color: Colors.black)),
                        ),
                        IconButton(
                            icon: Icon(Icons.today, color: Colors.grey),
                            onPressed: () {
                              // checkedValue == true
                              // ? SnackBar(
                              //     content: Text(
                              //         "You are currently working on it"))
                              //  :
                              showMonthPicker(
                                      context: context,
                                      firstDate: selectedDate,
                                      lastDate: (DateTime.now())
                                          .add(Duration(days: 500000)),
                                      initialDate: DateTime.now())
                                  .then((date) => setState(() {
                                        toselectedDate = date!;
                                        todateFormat = DateFormat("MMMM yyyy")
                                            .format(toselectedDate!);
                                      }));
                              // showDatePicker(
                              //     context: context,
                              //     initialDate: DateTime(2005),
                              //     firstDate: DateTime(2000),
                              //     lastDate: DateTime.now());
                            }),
                      ],
                    ),
                  )),
                ]),
              ),
              const SizedBox(height: 5),
              //--------------------------------------------------//
              // TextFormField(
              //   controller: headlineController,
              //   decoration: buildMyInputDecoration(context, 'Headline'),
              //   autovalidateMode: AutovalidateMode.onUserInteraction,
              //   onSaved: (String? value) => headline = value!,
              //   focusNode: _headlineFocus,
              //   onFieldSubmitted: (term) {
              //     _headlineFocus.unfocus();
              //   },
              //   // validator:validateHeadline,
              // ),

              TextFormField(
                controller: headlineController,
                focusNode: _headlineFocus,
                onFieldSubmitted: (term) {
                  _headlineFocus.unfocus();
                },

                decoration: buildMyInputDecoration(context, 'Headline'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                // validator:validateDescription,
                onSaved: (String? value) => headline = value!,
              ),
              const SizedBox(height: 15),
              //-------------------------------------------------//
              SizedBox(
                height: 60,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: Colors.grey.shade300.withOpacity(0.8),
                      width: 2,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: DropdownButtonFormField(
                      decoration: InputDecoration(
                          border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.all(
                              Radius.circular(6.0),
                            ),
                          ),
                          hintText: "Industry",
                          fillColor: Theme.of(context).scaffoldBackgroundColor),
                      value: industryValue,
                      items: <String>['E-commerce', 'Business', 'Software ']
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          industryValue = value;
                          print("Industry::::::::::::$industryValue");
                        });
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 15),
              //-------------------------------------------------//
              TextFormField(
                controller: descriptionController,
                focusNode: _descriptionFocus,
                onFieldSubmitted: (term) {
                  _descriptionFocus.unfocus();
                },
                maxLines: 5,
                decoration: buildMyInputDecoration(context, 'Description'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                // validator:validateDescription,
                onSaved: (String? value) => description = value!,
              ),
              const SizedBox(height: 30),
              //=====================Save==========================//
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 60,
                      child: ElevatedButton(
                        child: const Text('SAVE'), //next button
                        // style: ElevatedButton.styleFrom(
                        //   padding: const EdgeInsets.symmetric(vertical: 10),
                        //     : darkRed,
                        //   shape: RoundedRectangleBorder(
                        //       borderRadius: BorderRadius.circular(10)),
                        // ),
                        onPressed: () {
                          widget.editExp == true
                              ? validateAndUpdate()
                              : validateAndSave();
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ],
          )),
    );
  }

  validateAndSave() {
    final form = _formKey.currentState;
    if (form!.validate()) {
      if (dateFormat == "Start Date" || dateFormat == null) {
        Flushbar(
          messageText: Text(
            "Kindly select date",
            style: TextStyle(
                fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          duration: Duration(seconds: 3),
          isDismissible: true,
          icon: Image.asset(
            "assets/images/cancel.png",
            // scale: 1.0,
            height: 30,
            width: 30,
          ),
          backgroundColor: Color(0xFFBF2B38),
          margin: EdgeInsets.all(8),
          borderRadius: 8,
        ).show(context);
      } else if (checkedValue == false) {
        if (todateFormat == " End Date" || todateFormat == null) {
          Flushbar(
            messageText: Text(
              "Kindly select date",
              style: TextStyle(
                  fontSize: 15,
                  color: Colors.white,
                  fontWeight: FontWeight.w500),
            ),
            duration: Duration(seconds: 3),
            isDismissible: true,
            icon: Image.asset(
              "assets/images/cancel.png",
              // scale: 1.0,
              height: 30,
              width: 30,
            ),
            backgroundColor: Color(0xFFBF2B38),
            margin: EdgeInsets.all(8),
            borderRadius: 8,
          ).show(context);
        } else {}
      } else {
        showLoadingDialog(context);
        DocumentReference chatroomRef =
            FirebaseFirestore.instance.collection("employees").doc(userId);
        Map<String, dynamic> serializedMessage = {
          "title": titlesController.text[0].toUpperCase() +
              titlesController.text.substring(1).toString(),
          "companyName": companyNameController.text[0].toUpperCase() +
              companyNameController.text.substring(1).toString(),
          "expstartDate": dateFormat,
          "expLastDate": todateFormat,
          "jobDescription": descriptionController.text[0].toUpperCase() +
              descriptionController.text.substring(1).toString(),
          "empStatus": empStatus,
          "expHeadline": headlineController.text[0].toUpperCase() +
              headlineController.text.substring(1).toString(),
          "industry": industryValue,
          "expLocation": locationController.text[0].toUpperCase() +
              locationController.text.substring(1).toString(),
          "currentyWorkingCheck": checkedValue,
        };
        chatroomRef.update({
          "workExperience": FieldValue.arrayUnion([serializedMessage])
        });
        Future.delayed(Duration(milliseconds: 1050), () {
          Navigator.of(context).pop();
          Fluttertoast.showToast(msg: "Experience is added successfully");
        });
        // Future.delayed(Duration(milliseconds: 1150), () {
        //   Navigator.pushReplacement(context,
        // MaterialPageRoute(builder: (context) => MainExperiences()));
        Navigator.of(context).pop();
        //  });
      }

      print('form is valid');
    } else {
      print('form is invalid');
    }
  }

  void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }

  validateAndUpdate() {
    // final form = _formKey.currentState;
    // if (form!.validate()) {
    //   if (dateFormat == "Date" || dateFormat == null) {
    //     Flushbar(
    //       messageText: Text(
    //         "Kindly select date",
    //         style: TextStyle(
    //             fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
    //       ),
    //       duration: Duration(seconds: 3),
    //       isDismissible: true,
    //       icon: Image.asset(
    //         "assets/images/cancel.png",
    //         // scale: 1.0,
    //         height: 30,
    //         width: 30,
    //       ),
    //       backgroundColor: Color(0xFFBF2B38),
    //       margin: EdgeInsets.all(8),
    //       borderRadius: 8,
    //     ).show(context);
    //   } else if (checkedValue == false) {
    //     if (todateFormat == " End Date" || todateFormat == null) {
    //       Flushbar(
    //         messageText: Text(
    //           "Kindly select date",
    //           style: TextStyle(
    //               fontSize: 15,
    //               color: Colors.white,
    //               fontWeight: FontWeight.w500),
    //         ),
    //         duration: Duration(seconds: 3),
    //         isDismissible: true,
    //         icon: Image.asset(
    //           "assets/images/cancel.png",
    //           // scale: 1.0,
    //           height: 30,
    //           width: 30,
    //         ),
    //         backgroundColor: Color(0xFFBF2B38),
    //         margin: EdgeInsets.all(8),
    //         borderRadius: 8,
    //       ).show(context);
    //     } else {}
    //   } else {
    //     showLoadingDialog(context);
    //     DocumentReference qualifications =
    //         FirebaseFirestore.instance.collection("employees").doc(userId);
    //     // qualifications.update({
    //     //   "workExperience": FieldValue.arrayRemove([widget.userData])
    //     // });
    //     Map<String, dynamic> serializedMessage = {
    //       "title": titlesController.text[0].toUpperCase() +
    //           titlesController.text.substring(1).toString(),
    //       "companyName": companyNameController.text[0].toUpperCase() +
    //           companyNameController.text.substring(1).toString(),
    //       "expstartDate": dateFormat,
    //       "expLastDate": todateFormat,
    //       "jobDescription": descriptionController.text[0].toUpperCase() +
    //           descriptionController.text.substring(1).toString(),
    //       "empStatus": empStatus,
    //       "expHeadline": headlineController.text[0].toUpperCase() +
    //           headlineController.text.substring(1).toString(),
    //       "industry": industryValue,
    //       "expLocation": locationController.text[0].toUpperCase() +
    //           locationController.text.substring(1).toString(),
    //       "currentyWorkingCheck": checkedValue,
    //     };

    //     qualifications.update({
    //       "workExperience": FieldValue.arrayUnion([serializedMessage])
    //     });
    //     Future.delayed(Duration(milliseconds: 1050), () {
    //       Navigator.of(context).pop();
    //       Fluttertoast.showToast(msg: "Experience is updated successfully");
    //     });
    //     Future.delayed(Duration(milliseconds: 1150), () {
    //       Navigator.of(context).pop();
    //     });
    //   }
    //   print('form is valid');
    // } else {
    //   print('form is invalid');
    // }

    final form = _formKey.currentState;
    if (form!.validate()) {
      if (dateFormat == "Start Date" || dateFormat == null) {
        Flushbar(
          messageText: Text(
            "Kindly select date",
            style: TextStyle(
                fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          duration: Duration(seconds: 3),
          isDismissible: true,
          icon: Image.asset(
            "assets/images/cancel.png",
            // scale: 1.0,
            height: 30,
            width: 30,
          ),
          backgroundColor: Color(0xFFBF2B38),
          margin: EdgeInsets.all(8),
          borderRadius: 8,
        ).show(context);
      } else if (checkedValue == false) {
        if (todateFormat == " End Date" || todateFormat == null) {
          Flushbar(
            messageText: Text(
              "Kindly select date",
              style: TextStyle(
                  fontSize: 15,
                  color: Colors.white,
                  fontWeight: FontWeight.w500),
            ),
            duration: Duration(seconds: 3),
            isDismissible: true,
            icon: Image.asset(
              "assets/images/cancel.png",
              // scale: 1.0,
              height: 30,
              width: 30,
            ),
            backgroundColor: Color(0xFFBF2B38),
            margin: EdgeInsets.all(8),
            borderRadius: 8,
          ).show(context);
        } else {}
      } else {
        showLoadingDialog(context);
        DocumentReference qualifications = FirebaseFirestore.instance
            .collection("employees")
            .doc("bNrfdxRwRpg5ENl7Ue5TahVVlZu2");
        qualifications.update({
          "workExperience": FieldValue.arrayRemove([widget.userData])
        });
        print("UserId::::::::::::$userId");
        Map<String, dynamic> serializedMessage = {
          "title": titlesController.text[0].toUpperCase() +
              titlesController.text.substring(1).toString(),
          "companyName": companyNameController.text[0].toUpperCase() +
              companyNameController.text.substring(1).toString(),
          "expstartDate": dateFormat,
          "expLastDate": todateFormat,
          "jobDescription": descriptionController.text[0].toUpperCase() +
              descriptionController.text.substring(1).toString(),
          "empStatus": empStatus,
          "expHeadline": headlineController.text[0].toUpperCase() +
              headlineController.text.substring(1).toString(),
          "industry": industryValue,
          "expLocation": locationController.text[0].toUpperCase() +
              locationController.text.substring(1).toString(),
          "currentyWorkingCheck": checkedValue,
        };
        qualifications.update({
          "workExperience": FieldValue.arrayUnion([serializedMessage])
        });
        Future.delayed(Duration(milliseconds: 1050), () {
          Navigator.of(context).pop();
          Fluttertoast.showToast(msg: "Experience is added successfully");
        });
        // Future.delayed(Duration(milliseconds: 1150), () {
        //   Navigator.pushReplacement(context,
        // MaterialPageRoute(builder: (context) => MainExperiences()));
        Navigator.of(context).pop();
        //  });
      }

      print('form is valid');
    } else {
      print('form is invalid');
    }
  }

  validateCompanyName(String? value) {
    final pattern = ('[a-zA-Z]+([\s][a-zA-Z]+)*');
    final regExp = RegExp(pattern);
    if (value!.isEmpty) {
      return null;
    } else if (!regExp.hasMatch(value)) {
      return 'Enter only Alphabets';
    } else {
      return null;
    }
  }

  validateLocation(String? value) {
    final pattern = ('[a-zA-Z]+([\s][a-zA-Z]+)*');
    final regExp = RegExp(pattern);
    if (value!.isEmpty) {
      return null;
    } else if (!regExp.hasMatch(value)) {
      return 'Enter only Alphabets';
    } else {
      return null;
    }
  }

  validateHeadline(String? value) {
    final pattern = ('[a-zA-Z]+([\s][a-zA-Z]+)*');
    final regExp = RegExp(pattern);
    if (value!.isEmpty) {
      return null;
    } else if (!regExp.hasMatch(value)) {
      return 'Enter only Alphabets';
    } else {
      return null;
    }
  }

  validateDescription(String? value) {
    final pattern = ('[a-zA-Z]+([\s][a-zA-Z]+)*');
    final regExp = RegExp(pattern);
    if (value!.isEmpty) {
      return null;
    } else if (!regExp.hasMatch(value)) {
      return 'Enter only Alphabets';
    } else {
      return null;
    }
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(StringProperty('headline', headline));
  }
}
