import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/mainApp/mainProfile/Announcemets/constants.dart';

class DependentForm extends StatefulWidget {
  final dependent;
  const DependentForm({this.dependent, Key? key}) : super(key: key);

  @override
  _DependentFormState createState() => _DependentFormState();
}

class _DependentFormState extends State<DependentForm> {
  TextEditingController _controller1 = TextEditingController();
  TextEditingController _controller2 = TextEditingController();
  TextEditingController _controller3 = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late String userId;
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  bool isNetwork = true;
  late ScrollController con;

  var _dropdownValue;
  String selectRelation = "Relation";

  @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });
    userId = widget.dependent["uid"];
    con = ScrollController();
    con.addListener(() {
      if (con.offset >= con.position.maxScrollExtent &&
          !con.position.outOfRange) {
        setState(() {});
      } else if (con.offset <= con.position.minScrollExtent &&
          !con.position.outOfRange) {
        setState(() {});
      } else {
        setState(() {});
      }
    });

    _controller1 = TextEditingController(
      text: widget.dependent["depName"],
    );
    _controller2 = TextEditingController(
      text: widget.dependent["depCompName"],
    );
    _controller3 = TextEditingController(
      text: widget.dependent["Depdescription"],
    );

    _dropdownValue = widget.dependent["relation"];
    super.initState();
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              TextFormField(
                textInputAction: TextInputAction.next,
                controller: _controller1,
                style: TextFieldTextStyle(),
                decoration: TextFieldDecoration('Name'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  const pattern = ('[a-zA-Z]+([s][a-zA-Z]+)*');
                  final regExp = RegExp(pattern);
                  if (value!.isEmpty) {
                    return null;
                  } else if (!regExp.hasMatch(value)) {
                    return 'Enter a Valid Name';
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 10),
              //-----------------------DropDown-------------------

              //    DropdownButtonFormField(
              //   decoration: InputDecoration(
              //       border: const OutlineInputBorder(
              //         borderSide: BorderSide.none,
              //         borderRadius: BorderRadius.all(
              //           Radius.circular(10),
              //         ),
              //       ),
              //       labelText: "Role",
              //       labelStyle: TextStyle(fontSize: 12,color: Colors.grey),
              //       filled: true,
              //       fillColor: Colors.white),
              //   value: _dropdownValue,
              //   items: <String>['Destination', 'Software']
              //       .map<DropdownMenuItem<String>>((String value) {
              //     return DropdownMenuItem<String>(
              //       value: value,
              //       child: Text(value, style: TextStyle(fontSize: 12,color: Colors.grey),),
              //     );
              //   }).toList(),
              //   onChanged: (value) {
              //     setState(() {
              //       _dropdownValue = value;
              //     });
              //   },
              // ),

              Container(
                // padding: EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: Colors.grey.shade300, width: 1)),
                child: DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(
                          Radius.circular(5),
                        ),
                      ),
                      labelText: "Role",
                      labelStyle: TextStyle(fontSize: 14, color: Colors.grey),
                      filled: true,
                      fillColor: Colors.white),
                  value: _dropdownValue,
                  items: <String>[
                    'Brother',
                    'Sister',
                    'Father',
                    'Mother',
                    'Spouse',
                    'Daughter',
                    'Son',
                  ].map<DropdownMenuItem<String>>(
                    (String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    },
                  ).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      _dropdownValue = newValue;
                      selectRelation = newValue!;
                    });
                  },
                ),
              ),
              SizedBox(height: 10),
//---------------------textfield-----------------------------
              TextFormField(
                textInputAction: TextInputAction.next,
                controller: _controller2,
                style: TextFieldTextStyle(),
                decoration: TextFieldDecoration('Company Name'),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _controller3,
                style: TextFieldTextStyle(),
                maxLines: 4,
                decoration: TextFieldDecoration('Description'),
              ),
            ],
          ),
          //--------------------Save button---------------------
          FractionallySizedBox(
            widthFactor: 1,
            child: ElevatedButton(
              onPressed: () {
                // if (_controller1.text.isNotEmpty ||
                //     _controller2.text.isNotEmpty ||
                //     _controller3.text.isNotEmpty ||
                //     _dropdownValue != null) {
                // Navigator.of(context).pop();
                validateAndSave();
                // print("object:::::::::::::::::${_controller1.text}");
                //   }
                //  else {
                //   ScaffoldMessenger.of(context).showSnackBar(
                //     const SnackBar(
                //       content: Text('Complete the Form.'),
                //     ),
                //   );
                // }
              },
              style: ElevatedButton.styleFrom(
                primary: kPrimaryColor,
                padding: const EdgeInsets.symmetric(
                  vertical: 20,
                ),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5)),
              ),
              child: const Text(
                'Save',
              ),
            ),
          ),
        ],
      ),
    );
  }

//when user clicks on save button
  validateAndSave() {
    final form = _formKey.currentState;
    // if (form!.validate  ()) {
    if (selectRelation == "Relation") {
      Flushbar(
        messageText: const Text(
          "Kindly Select Relation",
          style: TextStyle(
              fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
        ),
        duration: const Duration(seconds: 3),
        isDismissible: true,
        icon: Image.asset(
          "assets/images/cancel.png",
          // scale: 1.0,
          height: 30,
          width: 30,
        ),
        backgroundColor: const Color(0xFFBF2B38),
        margin: const EdgeInsets.all(8),
        borderRadius: 8,
      ).show(context);
    } else {
      showLoadingDialog(context);
      DocumentReference chatroomRef =
          FirebaseFirestore.instance.collection("employees").doc(userId);
      chatroomRef.update({
        "depName": _controller1.text[0].toUpperCase() +
            _controller1.text.substring(1).toString(),
        "depCompName": _controller2.text[0].toUpperCase() +
            _controller2.text.substring(1).toString(),
        "Depdescription": _controller3.text[0].toUpperCase() +
            _controller3.text.substring(1).toString(),
        "relation": selectRelation,
      });

      // chatroomRef.update({
      //   "dependents": FieldValue.arrayUnion([serializedMessage])
      // });
      Future.delayed(const Duration(milliseconds: 1050), () {
        Navigator.of(context).pop();
        Fluttertoast.showToast(msg: "Dependent is added successfully");
      });
      Future.delayed(const Duration(milliseconds: 1150), () {
        Navigator.of(context).pop();
      });

      print('form is valid');
    }
    //  else {
    //   print('form is invalid');
    // }
  }

  void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }

  String? validateName(String value) {
    if (value.isEmpty) {
      return "Name cann't be empty";
    } else {
      return null;
    }
  }
}
