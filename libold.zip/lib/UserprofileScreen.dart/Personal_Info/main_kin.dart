import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hr_app/UserprofileScreen.dart/appbar.dart';
import 'package:hr_app/UserprofileScreen.dart/addKin.dart';
import 'package:hr_app/Constants/background.dart';
import 'package:hr_app/Constants/constants.dart';

class MainKin extends StatelessWidget {
  // ignore: prefer_typing_uninitialized_variables
  final kinInfo;
  const MainKin({this.kinInfo, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var experience = kinInfo['kinInfo'];
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: buildMyAppBar(context, 'Next of KIN', false),
        body: Stack(
          children: [
            const BackgroundCircle(),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: SingleChildScrollView(
                  child: Container(
                      margin: Platform.isIOS
                          ? const EdgeInsets.only(bottom: 50, top: 100)
                          : const EdgeInsets.only(bottom: 15, top: 70),
                      child: CardOne(kinInfo: experience, mainExp: kinInfo))),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AddKinInfo(
                          data: kinInfo,
                          uid: kinInfo['uid'],
                          editable: false)));
            },
            child: const Icon(
              Icons.add,
              color: Colors.white,
            ),
            backgroundColor: kPrimaryColor));
  }
}

class CardOne extends StatefulWidget {
  final kinInfo;
  final mainExp;
  const CardOne({this.kinInfo, this.mainExp, Key? key}) : super(key: key);

  @override
  _CardOneState createState() => _CardOneState();
}

class _CardOneState extends State<CardOne> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      child: Container(
        child: widget.kinInfo == null
            ? notfound()
            : widget.kinInfo != null && widget.kinInfo.length == 0
                ? notfound()
                : ListView.builder(
                    padding: EdgeInsets.zero,
                    // separatorBuilder: (context, index) => Divider(
                    // color: Colors.grey, )
                    itemCount:
                        widget.kinInfo != null ? widget.kinInfo.length : 0,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context, int index) {
                      return InkWell(
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => AddKinInfo(
                                      data: widget.kinInfo[index],
                                      uid: widget.mainExp["uid"],
                                      editable: true)));
                        },
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.only(
                              left: 10, top: 10, bottom: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(3),
                              border: Border.all(
                                  color: Colors.grey.withOpacity(0.3),
                                  width: 1)),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: [
                                  const Expanded(
                                    flex: 4,
                                    child: Text(
                                      "Name: ",
                                      style: TextStyle(
                                          color: Color(0XFF535353),
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 7,
                                    child: Container(
                                      margin: const EdgeInsets.only(left: 10),
                                      child: Text(
                                        widget.kinInfo == null
                                            ? "Name"
                                            : widget.kinInfo[index]['name'],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                  margin:
                                      const EdgeInsets.only(top: 5, bottom: 3),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        const Expanded(
                                          flex: 4,
                                          child: Text(
                                            "Relation: ",
                                            style: TextStyle(
                                                color: Color(0XFF535353),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14),
                                          ),
                                        ),
                                        Expanded(
                                            flex: 7,
                                            child: Container(
                                              margin: const EdgeInsets.only(
                                                  left: 10),
                                              child: Text(widget.kinInfo[index]
                                                          ['relation'] ==
                                                      null
                                                  ? "Relation"
                                                  : widget.kinInfo[index]
                                                      ['relation']),
                                            ))
                                      ])),
                              Container(
                                  margin:
                                      const EdgeInsets.only(top: 3, bottom: 3),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        const Expanded(
                                          flex: 4,
                                          child: Text(
                                            "Age: ",
                                            style: TextStyle(
                                                color: Color(0XFF535353),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 7,
                                          child: Container(
                                            margin:
                                                const EdgeInsets.only(left: 10),
                                            child: Text(widget.kinInfo[index]
                                                        ['age'] ==
                                                    null
                                                ? "Age"
                                                : widget.kinInfo[index]['age'] +
                                                    " Years"),
                                          ),
                                        )
                                      ])),
                              Container(
                                  margin:
                                      const EdgeInsets.only(top: 3, bottom: 3),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        const Expanded(
                                          flex: 4,
                                          child: Text(
                                            "CNIC: ",
                                            style: TextStyle(
                                                color: Color(0XFF535353),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 7,
                                          child: Container(
                                            margin:
                                                const EdgeInsets.only(left: 10),
                                            child: Text(widget.kinInfo[index]
                                                        ['cnic'] ==
                                                    null
                                                ? "CNIC"
                                                : widget.kinInfo[index]
                                                    ['cnic']),
                                          ),
                                        )
                                      ])),
                              Container(
                                  margin:
                                      const EdgeInsets.only(top: 3, bottom: 3),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        const Expanded(
                                          flex: 4,
                                          child: Text(
                                            "Percentage: ",
                                            style: TextStyle(
                                                color: Color(0XFF535353),
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 7,
                                          child: Container(
                                            margin:
                                                const EdgeInsets.only(left: 10),
                                            child: Text(widget.kinInfo[index]
                                                        ['percentage'] ==
                                                    null
                                                ? "Percentage"
                                                : widget.kinInfo[index]
                                                        ['percentage'] +
                                                    "%"),
                                          ),
                                        )
                                      ])),
                            ],
                          ),
                        ),
                      );
                    }),
      ),
    );
  }

  Widget notfound() {
    return Center(
      child: Container(
        height: MediaQuery.of(context).size.height / 1.4,
        margin: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Icon(
              Icons.person_outlined,
              color: Color(0xFFBF2B38),
              size: 100,
            ),
            const Text(
              "It's empty here.",
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w600),
            ),
            Text(
              "You haven't added any Information yet.",
              style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 12,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w400),
            ),
            Text(
              "Click Add New Button to get started.",
              style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 12,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w400),
            )
          ],
        ),
      ),
    );
  }
}
