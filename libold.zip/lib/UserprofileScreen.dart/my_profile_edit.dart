// ignore_for_file: prefer_const_constructors, avoid_unnecessary_containers, deprecated_member_use
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/Constants/loadingDailog.dart';
import 'package:hr_app/UserprofileScreen.dart/Card/AboutCard.dart';
import 'package:hr_app/UserprofileScreen.dart/Card/DependentCard.dart';
import 'package:hr_app/UserprofileScreen.dart/Card/KinCard.dart';
import 'package:hr_app/UserprofileScreen.dart/Card/LicenceCard.dart';
import 'package:hr_app/UserprofileScreen.dart/Card/work_info_card.dart';
import 'package:hr_app/UserprofileScreen.dart/screen_dependent.dart';
import 'package:hr_app/UserprofileScreen.dart/TrainingsCard.dart';
import 'package:hr_app/Constants/colors.dart';
import 'package:hr_app/main.dart';
import 'package:hr_app/mainApp/Login/auth.dart';
import 'package:hr_app/Constants/constants.dart';
import 'Card/AccountInfoCard.dart';
import 'Card/EducationCard.dart';
import 'Card/ExperienceCard.dart';
import 'Card/Personal_Info_Card.dart';
import 'Card/skillsCard.dart';

class MyProfileEdit extends StatefulWidget {
  const MyProfileEdit({Key? key}) : super(key: key);

  @override
  _MyProfileEditState createState() => _MyProfileEditState();
}

class _MyProfileEditState extends State<MyProfileEdit> {
  Connectivity? connectivity;

  StreamSubscription<ConnectivityResult>? subscription;

  bool isNetwork = true;

  var firebaseUser;

  String? userId;

  Stream? stream;

  String? urlList;

  String? value;
  int guest = 0;

  loadData() async {
    stream = null;

    firebaseUser = await FirebaseAuth.instance.currentUser!;
    userId = firebaseUser!.uid;

    await FirebaseFirestore.instance
        .collection("employees")
        .where('uid', isEqualTo: firebaseUser.uid)
        .get()
        .then((value) {
      guest = value.docs.length;
    });
    setState(() {});
    stream = await load();
  }

  Future<Stream> load() async {
    DocumentReference collectionReference = guest == 0
        ? FirebaseFirestore.instance.collection('guest').doc(firebaseUser!.uid)
        : FirebaseFirestore.instance
            .collection('employees')
            .doc(firebaseUser!.uid);
    Stream<DocumentSnapshot> query = collectionReference.snapshots();
    return query;
  }

  @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = Connectivity();

    subscription =
        connectivity!.onConnectivityChanged.listen((ConnectivityResult result) {
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });

    loadData();
  }

  void showLoadingDialog(BuildContext context, String value) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) =>
            LoadingDialog(value: value)));
  }

  @override
  void dispose() {
    subscription!.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        centerTitle: false,
        automaticallyImplyLeading: false,
        title: Text("Profile",
            style: TextStyle(color: Colors.white, fontSize: 17)),
      ),
      body: Container(
        child: stream == null
            ? Center(child: CircularProgressIndicator())
            : StreamBuilder<DocumentSnapshot>(
                stream: guest == 0
                    ? FirebaseFirestore.instance
                        .collection("guests")
                        .doc("$userId")
                        .snapshots()
                    : FirebaseFirestore.instance
                        .collection("employees")
                        .doc("$userId")
                        .snapshots(),
                builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: CircularProgressIndicator());
                  } else if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }

                  return SingleChildScrollView(
                    child: Column(
                      children: [
                        UpperPortion(data: snapshot.data!.data()),
                        AboutCard(data: snapshot.data!.data()),
                        guest == 0
                            ? Container()
                            : WorkInfoCard(data: snapshot.data!.data()),
                        SkillsCard(data: snapshot.data!.data()),
                        ExperienceCard(data: snapshot.data!.data()),
                        LicencesCard(data: snapshot.data!.data()),
                        EducationCard(data: snapshot.data!.data()),
                        TrainingsCard(data: snapshot.data!.data()),
                        PersonalInfoCard(data: snapshot.data!.data()),
                        AccountInfoCard(data: snapshot.data!.data()),
                        DependentsCard(data: snapshot.data!.data()),

//------------------Emergency Contact----------------------------
                        Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 15, vertical: 10),
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(
                                    color: isdarkmode.value == false
                                        ? Colors.grey.withOpacity(0.2)
                                        : Colors.white,
                                    width: 1)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 15, vertical: 10),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Emergency Contact',
                                      style: TextStyle(
                                        color: kPrimaryColor,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                    IconButton(
                                        icon: Icon(Icons.edit_outlined,
                                            color: isdarkmode.value == false
                                                ? const Color(0xff34354A)
                                                : Colors.grey[500]),
                                        onPressed: () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      Dependent(
                                                          dependent: snapshot
                                                              .data!
                                                              .data())));
                                        }),
                                  ],
                                ),
                                //------------Body----------
                                dependent(snapshot.data!.data())
                              ],
                            ),
                          ),
                        ),
                        KinCard(data: snapshot.data!.data()),
                        guest != 0
                            ? Container()
                            : Container(
                                alignment: Alignment.centerLeft,
                                child: TextButton.icon(
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      barrierDismissible:
                                          false, // user must tap button for close dialog!
                                      builder: (BuildContext context) {
                                        return CupertinoAlertDialog(
                                          title: Text('Quit'),
                                          content: const Text(
                                              'Are you sure you want to LOGOUT?'),
                                          actions: <Widget>[
                                            FlatButton(
                                              child: const Text('No'),
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                              },
                                            ),
                                            FlatButton(
                                              child: const Text('Yes'),
                                              onPressed: () {
                                                AuthService().signOut(context);
                                              },
                                            )
                                          ],
                                        );
                                      },
                                    );
                                  },
                                  icon: Icon(Icons.logout,
                                      color: isdarkmode.value == false
                                          ? const Color(0xff34354A)
                                          : Colors.grey[500]),
                                  label: Text('Log Out',
                                      style: TextStyle(
                                          color: isdarkmode.value == false
                                              ? const Color(0xff34354A)
                                              : Colors.grey[500])),
                                ),
                              ),
                      ],
                    ),
                  );
                }),
      ),
    );
  }

  Widget dependent(snapshot) {
    return Container(
        padding: const EdgeInsets.only(bottom: 5, left: 5, right: 5),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: const EdgeInsets.only(top: 3, bottom: 3, left: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      flex: 4,
                      child: Text(
                        "Name: ",
                        style: TextStyle(
                            color: Color(0XFF535353),
                            fontWeight: FontWeight.w500,
                            fontSize: 14),
                      ),
                    ),
                    Expanded(
                      flex: 7,
                      child: Container(
                        margin: const EdgeInsets.only(left: 10),
                        child: Text(
                          snapshot["depName"] ?? "Name",
                          style: TextStyle(
                              color: snapshot["depName"] == null
                                  ? Colors.grey[500]
                                  : Colors.grey[700],
                              fontWeight: FontWeight.w400,
                              fontSize: 15),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 3, bottom: 3, left: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      flex: 4,
                      child: Text(
                        "Relation: ",
                        style: TextStyle(
                            color: Color(0XFF535353),
                            fontWeight: FontWeight.w500,
                            fontSize: 14),
                      ),
                    ),
                    Expanded(
                      flex: 7,
                      child: Container(
                        margin: const EdgeInsets.only(left: 10),
                        child: Text(
                          snapshot["relation"] ?? "Relation",
                          style: TextStyle(
                              color: snapshot["relation"] == null
                                  ? Colors.grey[500]
                                  : Colors.grey[700],
                              fontWeight: FontWeight.w400,
                              fontSize: 15),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 3, bottom: 3, left: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      flex: 4,
                      child: Text(
                        "Phone: ",
                        style: TextStyle(
                            color: Color(0XFF535353),
                            fontWeight: FontWeight.w500,
                            fontSize: 14),
                      ),
                    ),
                    Expanded(
                      flex: 7,
                      child: Container(
                        margin: const EdgeInsets.only(left: 10),
                        child: Text(
                          snapshot["depPhone"] ?? "Phone",
                          style: TextStyle(
                              color: snapshot["depPhone"] == null
                                  ? Colors.grey[500]
                                  : Colors.grey[700],
                              fontWeight: FontWeight.w400,
                              fontSize: 15),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ]));
  }
}

class UpperPortion extends StatelessWidget {
  final data;
  const UpperPortion({Key? key, this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.30,
      child: Stack(
        children: [
          //--------------backimage-----------------//
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: MediaQuery.of(context).size.height * 0.30,
              decoration: BoxDecoration(
                  image: DecorationImage(
                image: AssetImage(
                  'assets/foggy.png',
                ),
                fit: BoxFit.cover,
              )),
              child: Container(
                // color: Colors.white.withOpacity(0.3),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: 20),
                      ProfilePic(data: data),
                    ],
                  ),
                ),
              ),
            ),
          ),

          //--------------backimage-end-----------------//

          //--------------mainWhite-Back-of-CenterCard---------------//
          Positioned(
            top: MediaQuery.of(context).size.height * 0.25,
            left: 0,
            right: 0,
            child: Container(
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
                color: Theme.of(context).scaffoldBackgroundColor,
              ),
            ),
          ),
          //-------------mainWhite--end-Back-of-CenterCard----------//
        ],
      ),
    );
  }
}

//====================================================//

class ProfilePic extends StatefulWidget {
  final data;
  ProfilePic({Key? key, this.data}) : super(key: key);

  @override
  State<ProfilePic> createState() => _ProfilePicState();
}

class _ProfilePicState extends State<ProfilePic> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(children: [
        Expanded(
            flex: 3,
            child: Stack(children: [
              Container(
                height: 80,
                child: Container(
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: widget.data['imagePath'] == null ||
                                widget.data['imagePath'] == ""
                            ? DecorationImage(
                                image: NetworkImage(
                                    'https://via.placeholder.com/150'))
                            : DecorationImage(
                                image: NetworkImage(
                                    widget.data["imagePath"]), // picked file
                              ))),
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    gradient: LinearGradient(
                        tileMode: TileMode.clamp,
                        begin: Alignment(0.5, 0.3),
                        end: Alignment(-1.0, 1.0),
                        colors: [darkRed, Color(0x4DFFFFFF), Colors.white])),
                padding: EdgeInsets.all(4),
              ),
              Positioned(
                  bottom: 7,
                  right: 10,
                  child: widget.data['covidCheck'] == false ||
                          widget.data['covidCheck'] == null
                      ? Container()
                      : Container(
                          height: 23,
                          child: Image.asset("assets/vacinated.png")))
            ])),
        Expanded(
          flex: 7,
          child: Container(
            margin: EdgeInsets.only(left: 10),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.data['displayName'] ?? "Name: Nill",
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.white)),
              SizedBox(height: 3),
              Row(
                children: [
                  Text("Employee Id: ",
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white, fontSize: 12)),
                  Text(widget.data['empId'] ?? " Nill",
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white, fontSize: 12)),
                ],
              ),
              SizedBox(height: 3),
              Text(widget.data['email'] ?? "Email: Nill",
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white, fontSize: 12)),
              SizedBox(height: 3),
              Text(widget.data['department'] ?? "Department: Nill",
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white, fontSize: 12)),
              SizedBox(height: 3),
              Text(widget.data['location'] ?? "Location: Nill",
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white, fontSize: 12)),
            ]),
          ),
        ),
      ]),
    );
  }
}
