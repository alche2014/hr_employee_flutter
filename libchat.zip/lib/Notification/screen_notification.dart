import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'dart:async';

class Notifications extends StatefulWidget {
  final uid;
  const Notifications({required Key? key, required this.uid}) : super(key: key);
  @override
  _NotificationsState createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  bool isNetwork = true;
  late String id;
  late String id2;
  late String senderPhoto;
  late String senderPhoto2;
  late String senderName;
  late Stream ? stream;
  late StreamController? streamController;
  @override
  void initState() {
    //check internet connection
    connectivity = Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });

    streamController = StreamController.broadcast();

    stream = null;
    loadData();
    Future.delayed(Duration(milliseconds: 400), () {
      setState(() {
        loadData2();
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    streamController!.close();
    subscription.cancel();
    streamController = null;
  }

  loadData() async {
    stream = await load();
    setState(() {});
  }

  loadData2() async {
    stream = await load2();
    setState(() {});
  }

  Future<Stream> load() async {
    Stream<QuerySnapshot> query = FirebaseFirestore.instance
        .collection("notifications")
        .where("receiver_id", isEqualTo: widget.uid)
        // .orderBy('timeStamp', descending: true)
        .snapshots();
    return query;
  }

  Future<Stream> load2() async {
    Stream<QuerySnapshot> query = FirebaseFirestore.instance
        .collection("notifications")
        .where("receiver_id", isEqualTo: widget.uid)
        .orderBy('timeStamp', descending: true)
        .snapshots();
    return query;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Notifications",
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: isNetwork
            ? StreamBuilder(
                stream: stream,
                builder: (context, AsyncSnapshot snapshot) {
                  if (snapshot.hasError) {
                    return const Center(
                      child: Text("ERROR"),
                    );
                  } else if (snapshot.hasData) {
                    return SingleChildScrollView(
                        child: snapshot.data!.documents.length == 0
                            ? Container(
                                alignment: Alignment.center,
                                height:
                                    MediaQuery.of(context).size.height - 120,
                                child: const Text("No notification"),
                              )
                            : ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: snapshot.data!.documents.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    child: InkWell(
                                      onTap: () {
                                        // snapshot.data.documents[index]
                                        //             .data["title"] ==
                                        //         "Leave Request"
                                        //     ? setState(() {
                                        //         Firestore.instance
                                        //             .collection("employees")
                                        //             .document(snapshot
                                        //                 .data
                                        //                 .documents[index]
                                        //                 .data["employee_id"])
                                        //             .collection("leavesRecord")
                                        //             .document(snapshot
                                        //                 .data
                                        //                 .documents[index]
                                        //                 .data["doc_id"])
                                        //             .get()
                                        //             .then((onValues) {
                                        //           (onValues.data[
                                        //                       'leaveStatus'] ==
                                        //                   "pending")
                                        //               ? Navigator.push(
                                        //                   context,
                                        //                   MaterialPageRoute(
                                        //                       builder: (context) =>
                                        //                           LeaveApprovalScreen(
                                        //                             docId: snapshot
                                        //                                 .data
                                        //                                 .documents[
                                        //                                     index]
                                        //                                 .data["doc_id"],
                                        //                             empId: snapshot
                                        //                                 .data
                                        //                                 .documents[
                                        //                                     index]
                                        //                                 .data["employee_id"],
                                        //                           )))
                                        //               : Fluttertoast.showToast(
                                        //                   msg:
                                        //                       "Notification status expired");
                                        //         });
                                        //       })
                                        //     : snapshot.data.documents[index]
                                        //                 .data["title"] ==
                                        //             "Announcement"
                                        //         ? setState(() {
                                        //             Navigator.push(
                                        //                 context,
                                        //                 MaterialPageRoute(
                                        //                     builder: (context) =>
                                        //                         ShowAnnouncementScreen(
                                        //                           docId: snapshot
                                        //                               .data
                                        //                               .documents[
                                        //                                   index]
                                        //                               .data["doc_id"],
                                        //                           // empId: snapshot.data.documents[index].data
                                        //                           //     ["Employees"],
                                        //                         )));
                                        //           })
                                        //         : setState(() {});
                                      },
                                      child: Column(
                                        children: <Widget>[
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 20, vertical: 8),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                                color: Colors.blue[100]),
                                            child: Text(
                                              timeago.format(snapshot
                                                  .data!
                                                  .documents[index]
                                                  .data["timeStamp"]
                                                  .toDate()),
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(
                                                  fontSize: 17,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                          Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 20,
                                                      vertical: 10),
                                              child: Material(
                                                elevation: 3,
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                // color: MyApp.isdarkmode.value != true
                                                //               ? Colors.white
                                                //               : Theme.of(context).scaffoldBackgroundColor.withOpacity(0.1),
                                                child: InkWell(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  onTap: () {},
                                                  child: Container(
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                            horizontal: 15,
                                                            vertical: 15),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                                    child: Row(
                                                      children: [
                                                        SizedBox(
                                                          height: 50.0,
                                                          width: 50.0,
                                                          child: snapshot
                                                                          .data!
                                                                          .documents[
                                                                              index]
                                                                          .data[
                                                                      "title"] ==
                                                                  "Announcement"
                                                              ? Container(
                                                                  padding:
                                                                      const EdgeInsets
                                                                          .all(
                                                                              6),
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Colors
                                                                        .blue,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                  ),
                                                                  child: const Icon(
                                                                    Icons
                                                                        .campaign_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 40,
                                                                  ))
                                                              : Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Colors
                                                                        .blue,
                                                                    border:
                                                                        Border
                                                                            .all(
                                                                      color:const Color(0xFFE0E0E0),
                                                                      width:
                                                                          3.0,
                                                                    ),
                                                                    borderRadius: const BorderRadius
                                                                        .all(Radius
                                                                            .circular(
                                                                        10.0)),
                                                                  ),
                                                                  height: 100.0,
                                                                  width: 100.0,
                                                                  child:
                                                                      ClipRRect(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    child:
                                                                        const FadeInImage(
                                                                      fit: BoxFit
                                                                          .fill,
                                                                      placeholder:
                                                                          AssetImage(
                                                                        "assets/images/profileImg.png",
                                                                        // height: 30,
                                                                      ),
                                                                      image:
                                                                          AssetImage(
                                                                        "assets/images/profileImg.png",
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                        ),
                                                        //   Container(
                                                        //     padding: EdgeInsets.all(6),
                                                        //     decoration: BoxDecoration(
                                                        //       borderRadius: BorderRadius.circular(10),
                                                        //       color: model.status == "Approved"
                                                        //           ? Colors.green
                                                        //           : model.status == "Rejected"
                                                        //               ? Colors.red
                                                        //               : Colors.blue,
                                                        //     ),
                                                        //     child: Icon(
                                                        //       model.status == "Approved"
                                                        //           ? Icons.done
                                                        //           : model.status == "Rejected"
                                                        //               ? Icons.close
                                                        //               : Icons.campaign_outlined,
                                                        //       color: Colors.white,
                                                        //       size: 40,
                                                        //     ),
                                                        //   ),
                                                        const SizedBox(width: 10),
                                                        Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            SizedBox(
                                                              width: 200.0,
                                                              height: 37.0,
                                                              child: Text(snapshot
                                                                  .data!
                                                                  .documents[
                                                                      index]
                                                                  .data["body"]),
                                                            ),
                                                            const SizedBox(height: 8),
                                                            Text(
                                                              DateFormat.jm()
                                                                  .add_yMd()
                                                                  .format(DateTime.parse(snapshot
                                                                      .data!
                                                                      .documents[
                                                                          index]
                                                                      .data[
                                                                          "timeStamp"]
                                                                      .toDate()
                                                                      .toString()))
                                                                  .toString(),
                                                            ),
                                                          ],
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              )),
                                        ],
                                      ),
                                    ),
                                  );
                                }));
                  } else if (!snapshot.hasData) {
                    return Center(
                      child: Text("No notifications"),
                    );
                  } else {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                })
            : Container(
                alignment: Alignment.center,
                height: MediaQuery.of(context).size.height - 120,
                child: Text("No Internet Connection"),
              ),
      ),
    );
  }

  // String parse(var model) {
  //   DateTime now = DateTime.now();
  //   String formattedDate = new DateFormat('yyyy-MM-dd').format(now);

  //   if (DateTime.parse(formattedDate) == model)
  //     return 'today';
  //   else
  //     return 'Earlier';
  // }

  // int mygroup(DateTime model, DateTime model1) {
  //   DateTime now = DateTime.now();
  //   String formattedDate = new DateFormat('yyyy-MM-dd').format(now);
  //   // print('$model   ' '$model1');
  //   if (model1.isAtSameMomentAs(model))
  //     return 0;
  //   else if (model1.isBefore(model))
  //     return 0;
  //   else
  //     return 1;
  // }

  // int mygroup1(DateTime model, DateTime model1) {
  //   DateTime now = DateTime.now();
  //   String formattedDate = new DateFormat('yyyy-MM-dd').format(now);
  //   // print('n$model   ' 'n$model1');
  //   if (model.isAtSameMomentAs(DateTime.parse(formattedDate)))
  //     return 0;
  //   else if (model.isBefore(DateTime.parse(formattedDate)))
  //     return 0;
  //   else
  //     return 1;
  // }
}
