import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr_app/Log%20Screen/sign_in.dart';
import 'package:hr_app/chat_module/providers/auth.dart';
import 'package:hr_app/chat_module/providers/chat.dart';
import 'package:hr_app/constants.dart';
import 'package:hr_app/mainApp/main_home_profile/main_home_profile.dart';
import 'package:hr_app/services/authenticate.dart';
import 'package:hr_app/services/helper.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'models/user.dart';
import 'theme.dart';
// ValueNotifier<bool> isdarkmode = ValueNotifier(false); 
void main() async{
    WidgetsFlutterBinding.ensureInitialized();

 runApp(const MyApps());
  
}
class MyApps extends StatefulWidget {
  const MyApps({ Key? key }) : super(key: key);

  @override
  _MyAppsState createState() => _MyAppsState();
}

class _MyAppsState extends State<MyApps> {
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: lightTheme(context),
      darkTheme: darkThemeData(context),
      home: Text("jhdgfsfghhkj"),
    );
  }
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  MyAppState createState() => MyAppState();
}

class MyAppState extends State<MyApp> with WidgetsBindingObserver {
  
  // static late User currentUser;

  // Set default `_initialized` and `_error` state to false
  bool _initialized = false;
    @override
  void initState() {
  super.initState();
   // initializeFlutterFire();
  SystemChrome.setEnabledSystemUIMode(
  SystemUiMode.immersiveSticky,
  );
  }

  bool _error = false;
  
  // Define an async function to initialize FlutterFire
  void initializeFlutterFire() async {
    try {
      // Wait for Firebase to initialize and set `_initialized` state to true
      await Firebase.initializeApp();
      setState(() {
        _initialized = true;
      });
    } catch (e) {
      // Set `_error` state to true if Firebase initialization fails
      setState(() {
        _error = true;
      });
    }
  }
  

  @override
  Widget build(BuildContext context) {
    // Show error message if initialization failed
    if (_error) {
      return MultiProvider(
        providers: [
          ChangeNotifierProvider.value(value: Auth()),
          ChangeNotifierProvider.value(value: Chat()),
        ],
        child: Consumer<Auth>(
          builder: (ctx, auth, _) => MaterialApp(

              home: Scaffold(
            body: Container(
              color: Colors.white,
              child: Center(
                  child: Column(
                children:const [
                   Icon(
                    Icons.error_outline,
                    color: Colors.red,
                    size: 25,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Failed to initialise firebase!',
                    style: TextStyle(color: Colors.red, fontSize: 25),
                  ),
                ],
              )),
            ),
            ))  )   ,
      );
    }

    // Show a loader until FlutterFire is initialized
    // if (!_initialized) {
    //   return Container(
    //     color: Colors.white,
    //     child: Center(
    //       child: CircularProgressIndicator.adaptive(),
    //     ),
    //   );
    // }

        return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: lightTheme(context),
      darkTheme: darkThemeData(context),
      home: SignIn(),
    );
  }
}
//   @override
//   void initState() {
//     super.initState();
//     initializeFlutterFire();
//   }
// }

// class OnBoarding extends StatefulWidget {
//   @override
//   State createState() {
//     return OnBoardingState();
//   }
// }

// class OnBoardingState extends State<OnBoarding> {
//   Future hasFinishedOnBoarding() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     // MainHomeProfile(user:null);
//     FirebaseUser firebaseUser;

   
//    firebaseUser = await FirebaseAuth.instance.currentUser();
//       if (firebaseUser != null) {
//         User? user = await FireStoreUtils.getCurrentUser(firebaseUser.uid);
//         if (user != null) {
//           MyAppState.currentUser = user;
//           pushReplacement(context, new  MainHomeProfile());
//         } else {
//           pushReplacement(context, new SignIn());
//         }
//       } else {
//         // pushReplacement(context, new AuthScreen());
//       }
    
//   }

  // @override
//   void initState() {
//     super.initState();
//     hasFinishedOnBoarding();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: CircularProgressIndicator.adaptive(
//           // valueColor: AlwaysStoppedAnimation(Color(COLOR_PRIMARY)),
//         ),
//       ),
//     );
//   }
// }