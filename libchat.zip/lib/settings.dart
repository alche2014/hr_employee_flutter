import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/Notification/screen_notification.dart';
// import 'package:hr_app/Notification/screen_notification.dart';
import 'package:hr_app/screen_Privacy_app.dart';
import 'package:hr_app/screen_about_app.dart';
import 'package:hr_app/services/auth.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;

import 'package:shimmer/shimmer.dart';
import 'mainApp/mainProfile/Announcemets/constants.dart';

class SettingsScreen extends StatefulWidget {
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  bool isNetwork = true;

  late String userId;
  late String value;

  late String compId;
  late String name;
  late ScrollController con;
  late Stream ?stream;
  var employeeList = [];
  var depRights = [];
  var designRights = [];
  var companyRights = [];
  var locationRights = [];
  var shiftRights = [];
  var leaveRights = [];
  bool showRightsManagment = false;
  late bool isAdminRight;
  late bool isAdmin;

  @override
  void initState() {
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });

    super.initState();
    con = ScrollController();
    con.addListener(() {
      if (con.offset >= con.position.maxScrollExtent &&
          !con.position.outOfRange) {
        setState(() {});
      } else if (con.offset <= con.position.minScrollExtent &&
          !con.position.outOfRange) {
        setState(() {});
      } else {
        setState(() {});
      }
    });
    stream = null;
    loadData();
    loadFirebaseUser();
  }

  loadData() async {
    stream = await load();
    setState(() {});
    loadFirebaseUser();
  }

  loadFirebaseUser() async {
   auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;
    userId = firebaseUser!.uid;
    print("Firebase User Id :: ${firebaseUser.uid}");
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  Future<Stream> load() async {
     auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;
    DocumentReference collectionReference =
        FirebaseFirestore.instance.collection('employees').doc(firebaseUser!.uid);
    Stream<DocumentSnapshot> query = collectionReference.snapshots();
    return query;
  }

  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          iconTheme: IconThemeData(),
          toolbarTextStyle: TextStyle(
              // color:
              //     MyApp.isdarkmode.value == false ? Colors.black : Colors.white,
              ),

          title: //MyApp.isdarkmode.value == false
              Text(
            'Settings',
            // style: TextStyle(
            // color: MyApp.isdarkmode.value == false
            //     ? Colors.black
            //     : Colors.white),
          ),
          // : Text(
          //     'Settings',
          //     style: TextStyle(
          //       color: Colors.white,
          //     ),
          //   ),
          backgroundColor: Colors.transparent,
          actions: [
            IconButton(
              onPressed: () {
                Navigator.of(context, rootNavigator: true)
                    .push(MaterialPageRoute(
                        builder: (context) => Notifications(
                              uid: userId,
                              key: null,
                            )));
              },
              icon: Icon(
                Icons.notifications,
              ),
            ),
          ],
        ),
        body: stream == null
            ? _shimmer()
            : StreamBuilder(
                stream: stream,
                builder: (context, AsyncSnapshot snapshot2) {
                  if (snapshot2.hasData) {
                    compId = snapshot2.data["companyId"];
                    name = snapshot2.data["displayName"];

                    print("object---------$compId");

                    return SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.all(5),
                              child: Row(
                                children: [
                                  SizedBox(width: 10),
                                  Container(
                                    width:
                                        MediaQuery.of(context).size.width * 0.5,
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          name,
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            // color: Colors.white
                                          ),
                                        ),
                                        Text(
                                          'Trust your feelings, be a good human being',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey[400],
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 20),
                            //------------------Switch----------------
                            Container(
                              // margin: EdgeInsets.symmetric(horizontal:  20 , vertical: 10),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 15, vertical: 5),

                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border:
                                    Border.all(color: Colors.grey, width: 1),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.dark_mode,
                                        color: kPrimaryColor,
                                      ),
                                      SizedBox(width: 10),
                                      Text(
                                        'Dark mode',
                                        style: TextStyle(
                                            color: Colors.grey[600],
                                            fontSize: 16),
                                      ),
                                    ],
                                  ),
                                  Switch(
                                    value: darkmode,
                                    onChanged: (value) {
                                      setState(() {
                                        // darkmode = value;
                                        // MyApp.isdarkmode.value =
                                        //     MyApp.isdarkmode.value == false ? true : false;
                                      });
                                    },
                                    activeTrackColor:
                                        kPrimaryColor.withOpacity(0.6),
                                    activeColor: kPrimaryColor,
                                    inactiveThumbColor: Colors.grey,
                                    inactiveTrackColor: Colors.grey[200],
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 10),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border:
                                    Border.all(color: Colors.grey, width: 1),
                              ),
                              child: ExpansionTile(
                                childrenPadding: EdgeInsets.symmetric(
                                    horizontal: 60, vertical: 10),
                                title: Row(
                                  children: [
                                    Icon(
                                      Icons.lock,
                                      color: kPrimaryColor,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      'Organization',
                                      style: TextStyle(color: Colors.grey[600]),
                                    ),
                                  ],
                                ),
                                // leading: Icon(
                                //   Icons.lock,
                                //   color: kPrimaryColor,
                                // ),
                                // children: [
                                //   StreamBuilder<DocumentSnapshot>(
                                //       stream: Firestore.instance
                                //           .collection('company')
                                //           .document("$compId")
                                //           .snapshots(),
                                //       builder: (context,
                                //           AsyncSnapshot<DocumentSnapshot>
                                //               snapshot) {
                                //         if (snapshot.hasError) {
                                //           return Center(child: Text("Error"));
                                //         } else if (snapshot.hasData) {
                                //           return Container(
                                //               alignment: Alignment.centerLeft,
                                //               child: InkWell(
                                //                   onTap: () {
                                //                     Navigator.of(context,
                                //                             rootNavigator: true)
                                //                         .push(MaterialPageRoute(
                                //                             builder: (context) =>
                                //                                 CompanyProfile(
                                //                                   data: snapshot
                                //                                       .data,
                                //                                 )));
                                //                   },
                                //                   child: Padding(
                                //                     padding:
                                //                         const EdgeInsets.all(
                                //                             8.0),
                                //                     child: Row(
                                //                       children: [
                                //                         Icon(
                                //                           Icons.circle,
                                //                           size: 15,
                                //                           color: kPrimaryColor,
                                //                         ),
                                //                         SizedBox(width: 5),
                                //                         Text(
                                //                           'Company Profile',
                                //                           style: TextStyle(
                                //                               color:
                                //                                   Colors.grey,
                                //                               fontSize: 16),
                                //                         ),
                                //                       ],
                                //                     ),
                                //                   )));
                                //         }
                                //         return Container(
                                //             alignment: Alignment.centerLeft,
                                //             child: Padding(
                                //               padding:
                                //                   const EdgeInsets.all(8.0),
                                //               child: Row(
                                //                 children: [
                                //                   Icon(
                                //                     Icons.circle,
                                //                     size: 15,
                                //                     color: kPrimaryColor,
                                //                   ),
                                //                   SizedBox(width: 5),
                                //                   Text(
                                //                     'Company Profile',
                                //                     style: TextStyle(
                                //                         color: Colors.grey,
                                //                         fontSize: 16),
                                //                   ),
                                //                 ],
                                //               ),
                                //             ));
                                //       }),
                                //   InkWell(
                                //     onTap: () {
                                //       Navigator.of(context, rootNavigator: true)
                                //           .push(MaterialPageRoute(
                                //               builder: (context) => Departments(
                                //                   compID: compId,
                                //                   name: name,
                                //                   depRights: depRights)));
                                //     },
                                //     child: Padding(
                                //       padding: const EdgeInsets.all(8.0),
                                //       child: Row(
                                //         children: [
                                //           Icon(
                                //             Icons.circle,
                                //             size: 15,
                                //             color: kPrimaryColor,
                                //           ),
                                //           SizedBox(width: 5),
                                //           Text(
                                //             'Department',
                                //             style: TextStyle(
                                //                 color: Colors.grey,
                                //                 fontSize: 16),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //   ),
                                //   InkWell(
                                //     onTap: () {
                                //       Navigator.of(context, rootNavigator: true)
                                //           .push(MaterialPageRoute(
                                //               builder: (context) =>
                                //                   OfficeLocation(
                                //                     compID: compId,
                                //                   )));
                                //     },
                                //     child: Padding(
                                //       padding: const EdgeInsets.all(8.0),
                                //       child: Row(
                                //         children: [
                                //           Icon(
                                //             Icons.circle,
                                //             size: 15,
                                //             color: kPrimaryColor,
                                //           ),
                                //           SizedBox(width: 5),
                                //           Text(
                                //             'Office Locations',
                                //             style: TextStyle(
                                //                 color: Colors.grey,
                                //                 fontSize: 16),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //   ),
                                //   InkWell(
                                //     onTap: () {
                                //       Navigator.of(context, rootNavigator: true)
                                //           .push(MaterialPageRoute(
                                //               builder: (context) =>
                                //                   ShiftSchedule(
                                //                       compID: compId,
                                //                       name: name)));
                                //     },
                                //     child: Padding(
                                //       padding: const EdgeInsets.all(8.0),
                                //       child: Row(
                                //         children: [
                                //           Icon(
                                //             Icons.circle,
                                //             size: 15,
                                //             color: kPrimaryColor,
                                //           ),
                                //           SizedBox(width: 5),
                                //           Text(
                                //             'Shift Schedule',
                                //             style: TextStyle(
                                //                 color: Colors.grey,
                                //                 fontSize: 16),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //   ),
                                //   InkWell(
                                //     onTap: () {
                                //       Navigator.of(context, rootNavigator: true)
                                //           .push(MaterialPageRoute(
                                //               builder: (context) =>
                                //                   LeavePolicies(
                                //                       compID: compId)));
                                //     },
                                //     child: Padding(
                                //       padding: const EdgeInsets.all(8.0),
                                //       child: Row(
                                //         children: [
                                //           Icon(
                                //             Icons.circle,
                                //             size: 15,
                                //             color: kPrimaryColor,
                                //           ),
                                //           SizedBox(width: 5),
                                //           Text(
                                //             'Leave Policy',
                                //             style: TextStyle(
                                //                 color: Colors.grey,
                                //                 fontSize: 16),
                                //           ),
                                //         ],
                                //       ),
                                //     ),
                                //   ),
                                // ],
                            
                            
                            
                            
                              ),
                            ),
                            SizedBox(height: 10),
                            Material(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(10),
                                onTap: () {
                                  Navigator.of(context, rootNavigator: true)
                                      .push(MaterialPageRoute(
                                          builder: (context) => Notifications(
                                                uid: userId,
                                                key: null,
                                              )));
                                },
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 18, vertical: 18),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        width: 1, color: Colors.grey),
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.notifications,
                                            color: kPrimaryColor,
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            'Notifications',
                                            style: TextStyle(
                                                color: Colors.grey[600],
                                                fontSize: 16),
                                          ),
                                        ],
                                      ),
                                      Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.grey,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                            Material(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(10),
                                onTap: () {
                                  Navigator.of(context, rootNavigator: true)
                                      .push(MaterialPageRoute(
                                          builder: (context) => PrivacyApp()));
                                },
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 18, vertical: 18),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        width: 1, color: Colors.grey),
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.lock,
                                            color: kPrimaryColor,
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            'Privacy',
                                            style: TextStyle(
                                                color: Colors.grey[600],
                                                fontSize: 16),
                                          ),
                                        ],
                                      ),
                                      Icon(
                                        Icons.keyboard_arrow_right,
                                        color: Colors.grey,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                            Material(
                              color: Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(10),
                                onTap: () {
                                  Navigator.of(context, rootNavigator: true)
                                      .push(MaterialPageRoute(
                                          builder: (context) => AboutApp()));
                                },
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 18, vertical: 18),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        width: 1, color: Colors.grey),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.error,
                                        color: kPrimaryColor,
                                      ),
                                      SizedBox(width: 10),
                                      Text(
                                        'About',
                                        style: TextStyle(
                                            color: Colors.grey[600],
                                            fontSize: 16),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                        ///    TextButton.icon(
                             // onPressed: () {
                              //   return 
                              //   showDialog(
                              //     context: context,
                              //     barrierDismissible:
                              //         false, // user must tap button for close dialog!
                              //     builder: (BuildContext context) {
                              //       return AlertDialog(
                              //         title: Text('Quit'),
                              //         content: const Text(
                              //             'Are you sure you want to LOGOUT?'),
                              //         actions: <Widget>[
                              //           FlatButton(
                              //             child: const Text('No'),
                              //             onPressed: () {
                              //               Navigator.of(context).pop();
                              //             },
                              //           ),
                              //           FlatButton(
                              //             child: const Text('Yes'),
                              //             onPressed: () {
                              //               AuthService().signOut(context);
                              //             },
                              //           )
                              //         ],
                              //       );
                              //     },
                              //   );
                              // },
                            //   icon: Icon(Icons.logout,
                            //       color: MediaQuery.of(context)
                            //                   .platformBrightness ==
                            //               Brightness.light
                            //           ? Colors.white
                            //           : Colors.black),
                            //   label: Text(
                            //     'Log Out',
                            //     style: TextStyle(
                            //         color: MediaQuery.of(context)
                            //                     .platformBrightness ==
                            //                 Brightness.light
                            //             ? Colors.white
                            //             : Colors.black),
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return _shimmer();
                  }
                }));
  }

  Widget _shimmer() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
      child: Shimmer.fromColors(
        baseColor:  Color(0xFFE0E0E0),
        highlightColor: Color(0xFFF5F5F5),
        child: Column(
          children: [0]
              .map((_) => Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Container(
                    padding: EdgeInsets.all(10.0),
                    decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(4.0)),
                    height: 100,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.only(top: 30, left: 30),
                          width: 48.0,
                          height: 48.0,
                          decoration: BoxDecoration(
                              color: Colors.green,
                              border: Border.all(),
                              borderRadius: BorderRadius.circular(50.0)),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: 4.0),
                                color: Colors.white,
                                width: double.infinity,
                                height: 8.0,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 2.0),
                              ),
                              Container(
                                width: double.infinity,
                                height: 8.0,
                                color: Colors.white,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 2.0),
                              ),
                              Container(
                                width: 40.0,
                                height: 8.0,
                                color: Colors.white,
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  )))
              .toList(),
        ),
      ),
    );
  }
}
