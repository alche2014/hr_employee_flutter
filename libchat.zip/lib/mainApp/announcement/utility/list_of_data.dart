import 'ann_card.dart';

List<AnnCard> annCardData = [
  AnnCard(
      'This super Leogue lorem 2017',
      'Hello guys, we have discussed about post-corona vacation plan and out decision is to go to bali. We have have a very big party after this corona ends!',
      '14:01 20/10/2020'),
  AnnCard(
      'This super Leogue lorem 2017',
      'Hello guys, we have discussed about post-corona vacation plan and out decision is to go to bali. We have have a very big party after this corona ends!',
      '14:01 20/10/2020'),
  AnnCard(
      'This super Leogue lorem 2017',
      'Hello guys, we have discussed about post-corona vacation plan and out decision is to go to bali. We have have a very big party after this corona ends!',
      '14:01 20/10/2020'),
  AnnCard(
      'This super Leogue lorem 2017',
      'Hello guys, we have discussed about post-corona vacation plan and out decision is to go to bali. We have have a very big party after this corona ends!',
      '14:01 20/10/2020'),
];
