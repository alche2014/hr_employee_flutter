import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/background/background.dart';
import 'package:intl/intl.dart';
import '../../colors.dart';
import 'utility/list_of_data.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;


class MainAnnouncement extends StatefulWidget {
  const MainAnnouncement({Key? key}) : super(key: key);

  @override
  _MainAnnouncementState createState() => _MainAnnouncementState();
}

class _MainAnnouncementState extends State<MainAnnouncement> {

   Connectivity ?connectivity;
  StreamSubscription<ConnectivityResult> ? subscription;
  bool isNetwork = true;
  // UserObject user;
  bool logoutUser = false;
  // late FirebaseUser firebaseUser;
  String? uid;
  String? companyId;

  var birthdate;
  bool _isLoggedIn = false;
  Map ?userProfile;
  String ?title;
  String? description;
  Timestamp ?time;
  // final facebookLogin = FacebookLogin();
  var photo;
  @override
  void initState() {
    super.initState();
        streamController = StreamController.broadcast();

      stream = null;
    loadData();
    Future.delayed(Duration(milliseconds: 400), () {
      setState(() {
        loadData2();
      });
    });
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity!.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });
    loadFIrebaseUser();
    setState(() {
      Future.delayed(const Duration(milliseconds: 111), () {
        loadLastAnn();
      });
    });
  }

//load firebase current user data
  loadFIrebaseUser() async {
     auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;
    uid = firebaseUser!.uid;
    print("Firebase User Id :: ${firebaseUser.uid}");
    setState(() {
      FirebaseFirestore.instance
          .collection('employees')
          .doc(firebaseUser.uid)
          .snapshots()
          .listen((onValue) {
        companyId = onValue.data()!["LqttR2u31kEyEcGgvXEI"];
        photo = onValue.data()!["photoURL"];
      });
    });
  }
 loadLastAnn() async {
    auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;
    await load(firebaseUser!.uid);
  }

  load(abc) {
    setState(() {
      Future.delayed(const Duration(milliseconds: 201), () {
          FirebaseFirestore.instance
            .collection('announcements')
            .where("Employees", arrayContains: "$abc")
            .orderBy('timeStamp', descending: true)
            .snapshots()
            .listen((onValue) {
          setState(() {
            title = onValue.docs[0].data()["announcementTitle"];
            description = onValue.docs[0].data()["announcementDes"];
            time = onValue.docs[0].data()["timeStamp"];
            time = onValue.docs[0].data()["Employees"];
          });
        });
      });
    });
  }
  StreamController? streamController;
 Stream ? stream;
loadData() async {
    stream = await load1();
    setState(() {});
  }

  loadData2() async {
    stream = await load2();
    setState(() {});
  }

  Future<Stream> load1() async {
    Stream<QuerySnapshot> query = FirebaseFirestore.instance
                                .collection("employees")
                                .where("companyId", isEqualTo: "LqttR2u31kEyEcGgvXEI")
                                .snapshots();
                                 return query;
    
  }

  Future<Stream> load2() async {
    Stream<QuerySnapshot> query = FirebaseFirestore.instance
                                .collection("employees")
                                .where("companyId", isEqualTo: "LqttR2u31kEyEcGgvXEI")
                               .orderBy("dob", descending: false)
                                .snapshots();
                                 return query;
  }
  // @override
  // void dispose() {
  //   subscription!.cancel();
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {


    
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          const BackgroundCircle(),
          NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              buildMyNewAppBar(context, 'Announcement', true),
            ],
            body:
             Padding(
              padding: const EdgeInsets.only(top: 20),
              child:loadAnnouncements()
              //  ListView.builder(
              //     itemCount: annCardData.length,
              //     itemBuilder: (context, index) => annCardData[index]),
            ),
          ),
        ],
      ),
    );
  }

  Widget loadAnnouncements() {
    return StatefulBuilder(
        builder: (BuildContext context, setState) => InkWell(
              // onTap: () {
              //   loadLastAnn();
              // },
              child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(left: 10, top: 10),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                flex: 10,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                        margin: EdgeInsets.only(
                                            top: 10, left: 10, bottom: 5),
                                        child: Text(
                                      title.toString(),
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18),
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(
                                            left: 10, bottom: 10),
                                        child: Text(
                                          time == null
                                              ? ""
                                              : DateFormat("dd MMM, yyyy")
                                                  .format(time!.toDate()),
                                          style: TextStyle(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14),
                                        )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.only(
                                top: 10, left: 30, right: 20, bottom: 20),
                            child: Text(
                              description == null ? "" : description.toString(),
                              style: TextStyle(
                                  fontWeight: FontWeight.w400, fontSize: 16),
                            )),
                      ],
                    ),
            ));
  }
}


// const BackgroundCircle(),
// appBar: 
