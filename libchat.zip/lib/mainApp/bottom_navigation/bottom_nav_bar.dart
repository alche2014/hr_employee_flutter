import 'package:flutter/material.dart';
import 'package:hr_app/chat_module/screens/chats_screen/all_chats_screen.dart';
import 'package:hr_app/mainApp/Announcement/main_announcement.dart';
import 'package:hr_app/mainApp/forms/form_2.dart';
import 'package:hr_app/mainApp/leave_management/leave_management.dart';
import 'package:hr_app/mainApp/mainProfile/Announcemets/screen_announcement.dart';
import 'package:hr_app/mainApp/mainProfile/my_profile_edit.dart';
import 'package:hr_app/mainApp/main_home_profile/main_home_profile.dart';
import 'package:hr_app/models/user.dart';


int? count;
String? user;

class NavBar extends StatefulWidget {
  NavBar(int a,  final userId,
  {Key? key, 
  }) : super(key: key) {
    //Intializing Globle variable for indexing nav position
    count = a;
    user=userId;

  }
  @override
  _NavBarState createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentindex = count!;

  final tabs = [
    //Assigning Tabs for bottom bar position Icon
    //  Center(child: MainHomeProfile()),
     const Center(child: MainHomeProfile()),
     Center(child: Announcements()),
    //  Center(child: MyProfileEdit(userId:user)),
   const Center(child:  AllChatsScreen()),
    //  Center(child: SettingsScreen()),
     const Center(child: FormTwo()),
    
    
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: tabs[_currentindex],
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: _currentindex,
            type: BottomNavigationBarType.fixed,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.home), label: ""),
              BottomNavigationBarItem(
                  icon: Icon(Icons.person_add_alt_1), label: ""),
              BottomNavigationBarItem(icon: Icon(Icons.person), label: ""),
              BottomNavigationBarItem(
                  icon: Icon(Icons.more_horiz_outlined), label: ""),
            ],
            onTap: (index) {
              setState(() {
                _currentindex = index;
              });
            }));
  }
}
