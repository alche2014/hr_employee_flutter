
import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/mainApp/work_info/utility/build_my_input_decoration.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:month_picker_dialog/month_picker_dialog.dart';

import '../../colors.dart';

// employee can add his/her educational information in this screen

class Education extends StatefulWidget {
  final data, uid,editable;
  Education({ Key?  key, this.data,this.uid,this.editable}) : super(key: key);
  @override
  _EducationState createState() => _EducationState();
}

class _EducationState extends State<Education> {
  late Connectivity connectivity;
  late StreamSubscription<ConnectivityResult> subscription;
  bool isNetwork = true;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late String school;
  late String degree;
  late String userId;

  late String field;
  late String notes;
  late String interest;

  FocusNode _schoolFocus = new FocusNode();
  FocusNode _degreeFocus = new FocusNode();
  FocusNode _fieldFocus = new FocusNode();
  FocusNode _notesFocus = new FocusNode();
  FocusNode _interestFocus = new FocusNode();

  TextEditingController schoolController = TextEditingController();
  TextEditingController degreeController = TextEditingController();
  TextEditingController fieldController = TextEditingController();
  TextEditingController notesController = TextEditingController();
  TextEditingController interestController = TextEditingController();

   DateTime? selectedDate;
  var dateFormat;
   DateTime ? toselectedDate;
  var todateFormat;

  late String _extension;
  late Map<String, String> _paths;
  late FileType _pickType;
   bool _multiPick = true;
   //GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
   final List<UploadTask> _tasks = <UploadTask>[];

  // void openFileExplorer() async {
  //   try {
  //     if (_multiPick) {
  //       _paths = await FilePicker.getMultiFilePath(
  //           type: _pickType,);
  //     }
  //     uploadToFirebase();
  //   } on PlatformException catch (e) {
  //     print("Unsupported operation" + e.toString());
  //   }
  //   if (!mounted) return;
  // }

  uploadToFirebase() {
    if (_multiPick) {
      _paths.forEach((fileName, filePath) => {upload(fileName, filePath)});
    }
  }
    static Reference storage = FirebaseStorage.instance.ref();


  upload(fileName, filePath) async{
    // _extension = fileName.toString().split('.').last;
    // StorageReference storageRef =
    //     FirebaseStorage.instance.ref().child("Documents/$fileName");
    // final StorageUploadTask uploadTask = storageRef.putFile(
    //   File(filePath),
    //   StorageMetadata(
    //     contentType: '$_pickType/$_extension',
    //   ),
    
  //  );
  
    Reference upload = storage.child("images/$fileName");
    UploadTask uploadTask = upload.putFile(filePath);
    var downloadUrl =
        await (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
         setState(() {
      _tasks.add(uploadTask);
    });
    return downloadUrl.toString();

   
  }
    @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
      setState(() { isNetwork = false;});
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {isNetwork = true; });
      }
    });
    userId = widget.uid["uid"];
    schoolController = TextEditingController(
      text: widget.data["school"],
    );
    notesController = TextEditingController(
      text: widget.data["notes"],
    );
    dateFormat = widget.data['expstartDate'];
    todateFormat = widget.data['expLastDate'];
    fieldController = TextEditingController(
      text:
          widget.data['studyField'],
    );
    interestController = TextEditingController(
      text: widget.data["interests"],
    );
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  // String _bytesTransferred(StorageTaskSnapshot snapshot) {
    // return '${snapshot.bytesTransferred}/${snapshot.totalByteCount}';
  //}

  late ScrollController con;

  // @override
  // void initState() {
  //   super.initState();
  //   //check internet connection
  //   connectivity = new Connectivity();
  //   subscription =
  //       connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
  //     print(result.toString());
  //     if (result == ConnectivityResult.none) {
  //       setState(() {
  //         isNetwork = false;
  //       });
  //     } else if (result == ConnectivityResult.mobile ||
  //         result == ConnectivityResult.wifi) {
  //       setState(() {
  //         isNetwork = true;
  //       });
  //     }
  //   });
  //   // userId = widget.data["uid"];
  //   con = ScrollController();
  //   con.addListener(() {
  //     if (con.offset >= con.position.maxScrollExtent &&
  //         !con.position.outOfRange) {
  //       setState(() {});
  //     } else if (con.offset <= con.position.minScrollExtent &&
  //         !con.position.outOfRange) {
  //       setState(() {});
  //     } else {
  //       setState(() {});
  //     }
  //   });
  // }

  // @override
  // void dispose() {
  //   subscription.cancel();
  //   super.dispose();
  // }

  Widget build(BuildContext context) {
    final List<Widget> childrenx = <Widget>[];
    // _tasks.forEach((StorageUploadTask task) {
    //   //   final Widget tile = UploadTaskListTile(
    //   //     task: task,
    //   //     onDismissed: () => setState(() => _tasks.remove(task)),
    //   //     // onDownload: () => downloadFile(task.lastSnapshot.ref),
    //   //   );
    //   //   childrenx.add(tile);
    // });
    double h2 = 0.0 + (childrenx.length * 80);
    double h = 45.0 + h2;
    return Form(
      key: _formKey,
      child: Scaffold(
        body: Stack(
        children: [
          const BackgroundCircle(),
          NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              buildMyNewAppBar(context, 'Add Education', true),
            ],
        body: Container(
          height: MediaQuery.of(context).size.height,
          
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Container(
                //   margin: EdgeInsets.only(left: 27, right: 15, top: 20),
                //   child: Text(
                //     "School*",
                //     style: TextStyle(
                //         color: Colors.grey[500],
                //         fontSize: 11,
                //         fontFamily: "Roboto",
                //         fontWeight: FontWeight.normal),
                //   ),
                // ),
                Container(
                  // height: 40,
                  margin: EdgeInsets.only(left: 15, right: 15, bottom: 10,top: 20),
                  width: MediaQuery.of(context).size.width - 10,
                  child: TextFormField(
                    controller: schoolController,
                    
                    textInputAction: TextInputAction.next,
                    focusNode: _schoolFocus,
                    keyboardType: TextInputType.text,
                    onSaved: (String ? value) => school = value!,
                    onFieldSubmitted: (term) {
                      _schoolFocus.unfocus();
                      FocusScope.of(context).requestFocus(_degreeFocus);
                    },
                    validator: validateSchool,
                    decoration: buildMyInputDecoration(context, 'School'),
                    // decoration: new InputDecoration(
                    //   prefixIcon: Icon(
                    //     Icons.work,
                    //     color: Color(0xFFBF2B38),
                    //   ),
                    //   fillColor: Colors.black,
                    //   hintText: 'School',
                    //   hintStyle: TextStyle(
                    //       color: Color(0xFFA2A2A2),
                    //       fontSize: 14,
                    //       fontFamily: "Roboto",
                    //       fontWeight: FontWeight.normal),
                    // ),
                  ),
                ),
             
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15, bottom: 10),
                  width: MediaQuery.of(context).size.width - 10,
                  child: TextFormField(
                    controller: degreeController,
                    textInputAction: TextInputAction.done,
                    focusNode: _degreeFocus,
                     decoration: buildMyInputDecoration(context, 'Degree'),
                    onSaved: (String ? value) => degree = value!,
                    onFieldSubmitted: (term) {
                      _degreeFocus.unfocus();
                      FocusScope.of(context).requestFocus(_fieldFocus);
                    },
                    validator: validateDegree,
                
                  ),
                ),
              
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15,),
                  width: MediaQuery.of(context).size.width - 10,
                  child: TextFormField(
                     decoration: buildMyInputDecoration(context, 'Field(s) of Study'),
                    controller: fieldController,
                    textInputAction: TextInputAction.next,
                    focusNode: _fieldFocus,
                    keyboardType: TextInputType.text,
                    onSaved: (String ? value) => field = value!,
                    onFieldSubmitted: (term) {
                      _fieldFocus.unfocus();
                      FocusScope.of(context).requestFocus(_notesFocus);
                    },
                    validator: validateField,
                    maxLines: null,
                    // decoration: new InputDecoration(
                    //   prefixIcon: Icon(
                    //     Icons.subtitles,
                    //     color: Color(0xFFBF2B38),
                    //   ),
                    //   fillColor: Colors.black,
                    //   hintText: 'Field(s) of Study',
                    //   hintStyle: TextStyle(
                    //       color: Color(0xFFA2A2A2),
                    //       fontSize: 14,
                    //       fontFamily: "Roboto",
                    //       fontWeight: FontWeight.normal),
                    // ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 27, right: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      // Expanded(
                      //   child: Container(
                      //     child: Text(
                      //       "From*",
                      //       style: TextStyle(
                      //           color: Colors.grey[500],
                      //           fontSize: 11,
                      //           fontFamily: "Roboto",
                      //           fontWeight: FontWeight.normal),
                      //     ),
                      //   ),
                      // ),
                      // Expanded(
                      //   child: Container(
                      //     child: Text("To*",
                      //         style: TextStyle(
                      //             color: Colors.grey[500],
                      //             fontSize: 11,
                      //             fontFamily: "Roboto",
                      //             fontWeight: FontWeight.normal)),
                      //   ),
                      // ),
                    ],
                  ),
                ),
                Row(
                  children: <Widget>[
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: () {
                          showMonthPicker(
                                  context: context,
                                  firstDate: (DateTime.now())
                                      .subtract(new Duration(days: 500000)),
                                  lastDate: toselectedDate,
                                  initialDate: DateTime.now())
                              .then((date) => setState(() {
                                    selectedDate = date;
                                    dateFormat = DateFormat("MMMM yyyy")
                                        .format(selectedDate!);
                                  }));
                                  },
                        child: Container(
                          height: 60,
                                 decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: Colors.grey.shade400,
                  width: 1,
                ),
              ),
                          margin: EdgeInsets.only(left: 15, right: 5, top: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                flex: 2,
                                child: Container(
                                       margin: EdgeInsets.only(left:10),
                                  alignment: Alignment.centerLeft,
                                  child: Icon(
                                    Icons.date_range,
                                    color: Color(0xFFBF2B38),
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 6,
                                child: Container(
                                
                                    child: Text(
                                    
                                  dateFormat == null ? "From" : dateFormat,
                                  style: TextStyle(
                                      color: dateFormat == null
                                          ? Color(0xFFA2A2A2)
                                          : Colors.black,
                                      fontSize: 14,
                                      fontFamily: "Roboto",
                                      fontWeight: FontWeight.normal),
                                )),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: () {
                          showMonthPicker(
                                  context: context,
                                  firstDate: selectedDate,
                                  lastDate: (DateTime.now())
                                      .add(new Duration(days: 500000)),
                                  initialDate: DateTime.now())
                              .then((date) => setState(() {
                                    toselectedDate = date;
                                  todateFormat = DateFormat("MMMM yyyy")
                                        .format(toselectedDate!);
                                  }));
                        },
                        child: Container(
                                 height: 60,
                                 decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: Colors.grey.shade400,
                  width: 1,
                ),
              ),
                          margin: EdgeInsets.only(right: 15, top: 10,),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                flex: 2,
                                child: Container(
                                  margin: EdgeInsets.only(left: 10),
                                  alignment: Alignment.centerLeft,
                                  child: Icon(
                                    Icons.date_range,
                                    color: Color(0xFFBF2B38),
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 6,
                                child: Container(
                                    child: Text(
                                  todateFormat == null ? "To" : todateFormat,
                                  style: TextStyle(
                                      color: todateFormat == null
                                          ? Color(0xFFA2A2A2)
                                          : Colors.black,
                                      fontSize: 14,
                                      fontFamily: "Roboto",
                                      fontWeight: FontWeight.normal),
                                )),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                // Row(children: <Widget>[
                //   Expanded(
                //     child: Container(
                //       margin: EdgeInsets.only(left: 15, right: 10, top: 10),
                //       height: 1,
                //       color: Colors.grey,
                //     ),
                //   ),
                //   Expanded(
                //     child: Container(
                //       margin: EdgeInsets.only(right: 15, top: 10),
                //       height: 1,
                //       color: Colors.grey,
                //     ),
                //   )
                // ]),

              
                   Container(
                //         decoration: BoxDecoration(
                // borderRadius: BorderRadius.circular(6),
                // border: Border.all(
                // color: Colors.grey.shade400,
                // width: 1,),
                //   ),
                  margin: EdgeInsets.only(left: 15, right: 15, bottom: 10,top: 10),
                  width: MediaQuery.of(context).size.width - 10,
                  child: TextFormField(
                  decoration: buildMyInputDecoration(context,"Addition Notes"),
                    controller: notesController,
                    textInputAction: TextInputAction.next,
                    focusNode: _notesFocus,
                    keyboardType: TextInputType.text,
                    onSaved: (String ? value) => notes = value!,
                    onFieldSubmitted: (term) {
                      _notesFocus.unfocus();
                      FocusScope.of(context).requestFocus(_interestFocus);
                    },
                    validator: validateNotes,
                    maxLines: null,
                    // decoration: new InputDecoration(
                    //   prefixIcon: Icon(
                    //     Icons.description,
                    //     color: Color(0xFFBF2B38),
                    //   ),
                    //   fillColor: Colors.black,
                    //   hintText: 'Additional Notes',
                    //   hintStyle: TextStyle(
                    //       color: Color(0xFFA2A2A2),
                    //       fontSize: 14,
                    //       fontFamily: "Roboto",
                    //       fontWeight: FontWeight.normal),
                    // ),
                  ),
                ),
               
                Container(
                     decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                color: Colors.grey.shade300,
                width: 1,),
                  ),
                  margin: EdgeInsets.only(left: 15, right: 15, bottom: 20),
                  width: MediaQuery.of(context).size.width - 10,
                  child: TextFormField(

                    controller: interestController,
                    textInputAction: TextInputAction.next,
                    focusNode: _interestFocus,
                    keyboardType: TextInputType.text,
                    onSaved: (String ? value) => interest = value!,
                    onFieldSubmitted: (term) {
                      _interestFocus.unfocus();
                    },
                    validator: validateInterest,
                    maxLines: null,
                    decoration: buildMyInputDecoration(context,"Interest"),
                    // decoration: new InputDecoration(
                    //   prefixIcon: Icon(
                    //     Icons.info,
                    //     color: Color(0xFFBF2B38),
                    //   ),
                    //   fillColor: Colors.black,
                    //   hintText: 'Interests',
                    //   hintStyle: TextStyle(
                    //       color: Color(0xFFA2A2A2),
                    //       fontSize: 14,
                    //       fontFamily: "Roboto",
                    //       fontWeight: FontWeight.normal),
                    // ),
                  ),
                ),
                // Container(
                //   margin: EdgeInsets.only(left: 27, right: 15, top: 20),
                //   child: Text(
                //     "Attach Documents*",
                //     style: TextStyle(
                //         color: Colors.grey[500],
                //         fontSize: 11,
                //         fontFamily: "Roboto",
                //         fontWeight: FontWeight.normal),
                //   ),
                // ),
                // Container(
                //   margin: EdgeInsets.only(top: 9.0, left: 15, right: 15),
                //   height: h,
                //   child: Column(
                //     children: <Widget>[
                //       Container(
                //         width: MediaQuery.of(context).size.width - 30,
                //         height: 40,
                //         child: InkWell(
                //           highlightColor: Colors.transparent,
                //           splashColor: Colors.transparent,
                //           onTap: () {
                //             openFileExplorer();
                //           },
                //           child: Row(
                //             children: <Widget>[
                //               Expanded(
                //                 flex: 1,
                //                 child: Icon(
                //                   Icons.attach_file,
                //                   color: Color(0xFFBF2B38),
                //                 ),
                //               ),
                //               Expanded(
                //                 flex: 9,
                //                 child: Text(
                //                   "  Attach Documents",
                //                   style: TextStyle(
                //                       color: Color(0xFFA2A2A2),
                //                       fontSize: 14,
                //                       fontFamily: "Roboto",
                //                       fontWeight: FontWeight.normal),
                //                 ),
                //               ),
                //             ],
                //           ),
                //         ),
                //       ),
                //       Container(
                //         height: 1,
                //         color: Colors.grey,
                //         width: MediaQuery.of(context).size.width,
                //         margin: EdgeInsets.only(left: 5, right: 5, top: 4),
                //       ),
                //       Flexible(
                //         fit: FlexFit.loose,
                //         child: Container(
                //           margin: EdgeInsets.only(top: 20),
                //           height: h2,
                //           decoration: BoxDecoration(
                //               // color: Colors.grey[200],
                //               border:
                //                   Border.all(color: Colors.grey[500], width: 1),
                //               borderRadius: BorderRadius.circular(5.0)),
                //           child: ListView(
                //             controller: con,
                //             children: childrenx,
                //           ),
                //         ),
                //       ),
                //     ],
                //   ),
                // ),
                Container(
                  margin: EdgeInsets.only(top: 45),
                ),
                 Container(
                   margin: EdgeInsets.only(left: 15,right: 15),
                   child: Row(
            children: [
              Expanded(
                child: SizedBox(
                    height: 60,
                    child: ElevatedButton(
                      child: const Text('SAVE'), //next button
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        primary: darkRed,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () {
                        if(widget.editable==true){
                           validateAndUpdate();
                        }
                        else{validateAndSave(); }
                      
                      },
                    ),
                ),
              ),
            ],
          ),
                 ),
              ],
            ),
          ),
        ),
      ),
    ],
      ),
    ));
  }

  void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }
   
  validateAndUpdate() {
    final form = _formKey.currentState;
    if (form!.validate()) {
      if (dateFormat == "From" || dateFormat == null) {
        Flushbar(
          messageText: Text(
            "Kindly select date",
            style: TextStyle(
                fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          duration: Duration(seconds: 3),
          isDismissible: true,
          icon: Image.asset(
            "assets/images/cancel.png",
            // scale: 1.0,
            height: 30,
            width: 30,
          ),
          backgroundColor: Color(0xFFBF2B38),
          margin: EdgeInsets.all(8),
          borderRadius: 8,
        )..show(context);
      }
      if (todateFormat == "To" || todateFormat == null) {
        Flushbar(
          messageText: Text(
            "Kindly select date",
            style: TextStyle(
                fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          duration: Duration(seconds: 3),
          isDismissible: true,
          icon: Image.asset(
            "assets/images/cancel.png",
            // scale: 1.0,
            height: 30,
            width: 30,
          ),
          backgroundColor: Color(0xFFBF2B38),
          margin: EdgeInsets.all(8),
          borderRadius: 8,
        )..show(context);
      } else {
        DocumentReference qualifications =
            FirebaseFirestore.instance.collection("employees").doc(userId);
        qualifications.update({
          "education": FieldValue.arrayRemove([widget.data])
        });
        Map<String, dynamic> serializedMessage = {
          "school": schoolController.text[0].toUpperCase() +
              schoolController.text.substring(1).toString(),
          "degree": degreeController.text[0].toUpperCase() +
              degreeController.text.substring(1).toString(),
          "expstartDate":
              dateFormat ?? widget.data["expstartDate"],
          "expLastDate":
              todateFormat ?? widget.data["expLastDate"],
          "notes": notesController.text[0].toUpperCase() +
              notesController.text.substring(1).toString(),
          "studyField": fieldController.text[0].toUpperCase() +
              fieldController.text.substring(1).toString(),
          "interests": interestController.text[0].toUpperCase() +
              interestController.text.substring(1).toString(),
        };

        qualifications.update({
          "education": FieldValue.arrayUnion([serializedMessage])
        });
        Future.delayed(Duration(milliseconds: 1050), () {
          Navigator.of(context).pop();
          Fluttertoast.showToast(msg: "Education is updated successfully");
        });
        Future.delayed(Duration(milliseconds: 1150), () {
          // Navigator.of(context).pop();
        });
      }
      print('form is valid');
    } else {
      print('form is invalid');
    }
  }
    
    
    
    validateAndSave() {
    final form = _formKey.currentState;
    if (form!.validate()) {
      if (dateFormat == "From" || dateFormat == null) {
        Flushbar(
          messageText: Text(
            "Kindly select date",
            style: TextStyle(
                fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          duration: Duration(seconds: 3),
          isDismissible: true,
          icon: Image.asset(
            "assets/images/cancel.png",
            // scale: 1.0,
            height: 30,
            width: 30,
          ),
          backgroundColor: Color(0xFFBF2B38),
          margin: EdgeInsets.all(8),
          borderRadius: 8,
        )..show(context);
      } else if (todateFormat == "To" || todateFormat == null) {
        Flushbar(
          messageText: Text(
            "Kindly select date",
            style: TextStyle(
                fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          duration: Duration(seconds: 3),
          isDismissible: true,
          icon: Image.asset(
            "assets/images/cancel.png",
            // scale: 1.0,
            height: 30,
            width: 30,
          ),
          backgroundColor: Color(0xFFBF2B38),
          margin: EdgeInsets.all(8),
          borderRadius: 8,
        )..show(context);
      } else {
        showLoadingDialog(context);
        DocumentReference chatroomRef =
            FirebaseFirestore.instance.collection("employees").doc(userId);
        Map<String, dynamic> serializedMessage = {
          "school": schoolController.text[0].toUpperCase() +
              schoolController.text.substring(1).toString(),
          "degree": degreeController.text[0].toUpperCase() +
              degreeController.text.substring(1).toString(),
          "expstartDate": dateFormat,
          "expLastDate": todateFormat,
          "notes": notesController.text[0].toUpperCase() +
              notesController.text.substring(1).toString(),
          "studyField": fieldController.text[0].toUpperCase() +
              fieldController.text.substring(1).toString(),
          "interests": interestController.text[0].toUpperCase() +
              interestController.text.substring(1).toString(),
        };

        chatroomRef.update({
          "education": FieldValue.arrayUnion([serializedMessage])
        });
        Future.delayed(Duration(milliseconds: 1050), () {
          Navigator.of(context).pop();
          Fluttertoast.showToast(msg: "Education is added successfully");
        });
        Future.delayed(Duration(milliseconds: 1150), () {
          Navigator.of(context).pop();
        });
      }
      print('form is valid');
    } else {
      print('form is invalid');
    }
  }

  String?  validateSchool(String? value) {
    if (value!.length < 3)
      return "School Name cann't be empty";
    else
      return null;
  }

  String ? validateDegree(String ? value) {
    if (value!.length == 0)
      return "Degree cann't be empty";
    else
      return null;
  }

  String? validateField(String?  value) {
    if (value!.length == 0)
      return "Field cann't be empty";
    else
      return null;
  }

  String? validateInterest(String?  value) {
    if (value!.length == 0)
      return "Interests cann't be empty";
    else
      return null;
  }

  String?  validateNotes(String? value) {
    if (value!.length == 0)
      return "Additional Notes cann't be empty";
    else
      return null;
  }
}
