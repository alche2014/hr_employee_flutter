// ignore_for_file: sized_box_for_whitespace, prefer_const_constructors

import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_offline/flutter_offline.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hr_app/mainApp/check_in_history/main_check_in.dart';
import 'package:hr_app/mainApp/check_in_history/utility/check_in_card.dart';
import 'package:hr_app/mainApp/main_home_profile/utility/content/list_of_data.dart';
import 'package:hr_app/models/user.dart';
import 'package:intl/intl.dart';
import '../../colors.dart';
import 'Utility/cards/teamCard.dart';
// import 'package:stop_watch_timer/stop_watch_timer.dart';

class MainHomeProfile extends StatefulWidget {
  //  final  user;
  const MainHomeProfile({Key? key}) : super(key: key);

  @override
  _MainHomeProfileState createState() => _MainHomeProfileState();
}

class _MainHomeProfileState extends State<MainHomeProfile>  with TickerProviderStateMixin {
 late Connectivity connectivity;
 late StreamSubscription<ConnectivityResult> subscription;
 late bool isNetwork = true;
 late AnimationController controller;
 late String buttonText = "CHECK IN";
 late Position _currentPosition;
 late double currentLat;
 late double currentLng;
 late String userId;
 late String locationId;
 late String shiftId;
 late double officeLat;
 late double officeLng;
 late String companyId;
 late String location;
 late int hours = 00;
 late int minutes = 00;
 late int seconds = 00;
 late Timestamp checkinTime;
 late String docId;
 late Timer timer;
  // ScheduleController controllers;
 late String to;
 late String from;
 late String shiftName;
 late int weekend;
  var weekendDefi;
  double _hr = 0;
  double _minute = 0;
  String lateTime = "0 hrs & 0 mins";

  @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });

    loadFirebaseUser();
    _getCurrentLocation();
    timer =
        Timer.periodic(Duration(seconds: 1), (Timer t) => loadFirebaseUser());
    controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 32400),
    );
  }

  @override
  void dispose() {
    timer.cancel();
    subscription.cancel();
    super.dispose();
  }

//getting current user data
  loadFirebaseUser() async {
      auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;
    userId = firebaseUser!.uid;
    print("Firebase User Id :: ${firebaseUser.uid}");
    FirebaseFirestore.instance
        .collection('attendance')
        .where("empId", isEqualTo: userId)
        .where("checkout", isNull: true)
        .get()
        .then((onValue) {
      if (onValue.docs.isEmpty) {
        setState(() {
          buttonText = "CHECK IN";
        });
      } else if (onValue.docs.length == 1) {
        checkinTime = onValue.docs.first.data()["checkin"];
        docId = onValue.docs.first.data()["docId"];
        lateTime = onValue.docs.first.data()["late"];
        DateTime lastTime = DateTime.now();
        String difference =
            "${lastTime.difference(checkinTime.toDate()).inSeconds}";

        int weekendDef = int.parse(difference);

        double hoursD = weekendDef / 3600;
        double minutesD = (weekendDef % 3600) / 60;
        double secondsD = (weekendDef % 60) / 1;
        hours = hoursD.toInt();
        minutes = minutesD.toInt();
        seconds = secondsD.toInt();
        setState(() {
          buttonText = "CHECK OUT";
        });
      }
    });
    FirebaseFirestore.instance
        .collection('employees')
        .doc("${firebaseUser.uid}")
        .snapshots()
        .listen((onValue) {
      locationId = onValue.data()!["locationId"];
      shiftId = onValue.data()!["shiftId"];
      companyId = onValue.data()!["companyId"];
      print("locationId = $locationId");
      print("shiftId = $shiftId");
    });
    setState(() {
      Future.delayed(Duration(milliseconds: 150), () {
        if(shiftId != null)
        {_getShiftSchedule();}
      });
    });
  }

// getting employee shift so that employee cannot checkin in weekends
  _getShiftSchedule() {
    FirebaseFirestore.instance
        .collection('shiftSchedule')
        .doc("$shiftId")
        .snapshots()
        .listen((onValue) {
      to = onValue.data()!["to"];
      from = onValue.data()!["from"];
      shiftName = onValue.data()!["shiftName"];
      weekend = onValue.data()!["weekend"];
      weekendDefi = onValue.data()!["weekendDef"];
      print(" from = $from , to = $to ");
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.52,
              child: Stack(
                children: [
                  //--------------backimage-----------------//
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 300,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                        image: AssetImage('assets/foggy.jpg'),
                        fit: BoxFit.cover,
                      )),
                      child: Column(
                        // crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Icon(Icons.notifications,
                                      color: MediaQuery.of(context)
                                                  .platformBrightness ==
                                              Brightness.light
                                          ? Colors.white
                                          : Colors.grey)
                                ]),
                          ),
                          CircleAvatar(
                            backgroundImage: AssetImage('assets/ben.jpg'),
                            maxRadius: 40,
                          ),
                          SizedBox(height: 10),
                          Text('Name Here',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          SizedBox(height: 5),
                          Text('Front-End & UI',
                              style: TextStyle(color: Colors.grey)),
                          SizedBox(height: 70),
                        ],
                      ),
                    ),
                  ),
                  //--------------backimage-end-----------------//

                  //--------------mainWhite-Back-of-CenterCard---------------//
                  Positioned(
                    top: MediaQuery.of(context).size.height * 0.36,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        ),
                        color: MediaQuery.of(context).platformBrightness ==
                                Brightness.light
                            ? Colors.white
                            : Color(0xFF1D1D35),
                      ),
                    ),
                  ),
                  //-------------mainWhite--end-Back-of-CenterCard----------//

                  //-------------center-card-----------------//
                  Positioned(
                    top: MediaQuery.of(context).size.height * 0.29,
                    left: 0,
                    right: 0,
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 25),
                      child: ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                        child: Container(
                          height: 150,
                          // margin: EdgeInsets.symmetric(horizontal: 25),
                          decoration: BoxDecoration(
                            border: const Border(
                                bottom: BorderSide(color: darkRed, width: 3)),
                            color: MediaQuery.of(context).platformBrightness ==
                                    Brightness.light
                                ? Colors.white
                                : const Color(0xff34354A),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(height: 5),
                                    const Text('Check In',
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold)),
                                    SizedBox(height: 5),
                                    buttonText == "CHECK OUT"
                                    ? lateTime == "0 hrs and 0 mins"
                          ? Container()
                          : Text("$lateTime late")
                      : Container(),
                                      buttonText == "CHECK OUT"
                                          ? 
                                                Container(margin: EdgeInsets.only(top: 10),
                                                  child: Text("$hours : $minutes : $seconds"))
                                               
                                              
                                            
                                          : Container(
                                              margin: EdgeInsets.only(top: 15),
                                              child: Text(
                                                "Date: ${DateFormat('MMMM dd').format(DateTime.now())}",
                                                style: TextStyle(
                                                    color: Colors.grey,
                                                    fontSize: 16,
                                                    fontFamily: "Roboto",
                                                    fontWeight:
                                                        FontWeight.w600),
                                              ),
                                            ),
                                    //----------------------//
                                    TextButton(
                                        onPressed: () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (context) =>MainCheckIn(uid:userId)));
                                        },
                                        child: Text('View History')),
                                  ],
                                ),
                                Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                          padding: EdgeInsets.all(5),
                                          height: 100,
                                          width: 100,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                color: darkRed, width: 3),
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            color: MediaQuery.of(context)
                                                        .platformBrightness ==
                                                    Brightness.light
                                                ? Colors.grey[100]
                                                : Color(0xff34354A),
                                          ),
                                          // child: ElevatedButton(
                                          //   onPressed: () {
                                          //   },
                                          //   child: Text("$buttonText",
                                          //       style: TextStyle(fontSize: 9)),
                                          //   style: ElevatedButton.styleFrom(
                                          //     shape: CircleBorder(),
                                          //     // padding: EdgeInsets.all(14),
                                          //   ),
                                          // )
                                        child: Container(
                            // margin:
                            //     EdgeInsets.only(top: 30, left: 30, right: 30),
                            // height: 60,
                            child: OfflineBuilder(connectivityBuilder: (
                              BuildContext context,
                              ConnectivityResult connectivity2,
                              Widget child,
                            ) {
                              if (connectivity2 == ConnectivityResult.none) {
                                return RaisedButton(
                                  color: Color(0xFFBF2B38),
                                  onPressed: () {
                                    Flushbar(
                                      messageText: Text(
                                        "No Internet Connection",
                                        style: TextStyle(
                                            fontSize: 15,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      duration: Duration(seconds: 3),
                                      isDismissible: true,
                                      icon: Image.asset(
                                        "assets/images/cancel.png",
                                        scale: 1.4,
                                        // height: 25,
                                        // width: 25,
                                      ),
                                      backgroundColor: Color(0xFFBF2B38),
                                      margin: EdgeInsets.all(8),
                                      borderRadius: 8,
                                    )..show(context);
                                  },
                                  child: Text(
                                    "$buttonText",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                );
                              } else {
                                return child;
                              }
                            }, builder: (BuildContext context) {
                              return ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                              shape: CircleBorder(),
                                              // padding: EdgeInsets.all(14),
                                            ),
                                  onPressed: () {
                                   
                                    if (buttonText == "CHECK OUT") {
                                      if(locationId !=null){
                                      _getOfficeLocation();
                                      setState(() {
                                        Future.delayed(
                                            Duration(milliseconds: 150), () {
                                          location == "ON"
                                              ? _calculations()
                                              : noLocationCheckin();
                                        });
                                      });}else{
                                        noLocationCheckin();
                                      }
                                    } else if (shiftId != null) {
                                      if (weekend == 1) {
                                        if (weekendDefi.contains(
                                                "${DateFormat('EEE').format(DateTime.now())}${DateFormat("M").format(DateTime.now())}") ||
                                            weekendDefi.contains(
                                                "${DateFormat('EEE').format(DateTime.now())}0")) {
                                            Fluttertoast.showToast(
                                              msg:
                                                  "Today is not a working day");
                                        } else {
                                          _getOfficeLocation();
                                          setState(() {
                                            Future.delayed(
                                                Duration(milliseconds: 150),
                                                () {
                                              location == "ON"
                                                  ? _calculations()
                                                  : noLocationCheckin();
                                            });
                                          });
                                        }
                                      }
                                    } else {
                                      if ("${DateFormat('EEEE').format(DateTime.now())}" !=
                                              "Saturday" ||
                                          "${DateFormat('EEEE').format(DateTime.now())}" !=
                                              "Sunday") {
                                                if(locationId!=null)
                                        {_getOfficeLocation();
                                        setState(() {
                                          Future.delayed(
                                              Duration(milliseconds: 150), () {
                                            location == "ON"
                                                ? _calculations()
                                                : noLocationCheckin();
                                          });
                                        });}else{
                                          noLocationCheckin();
                                        }
                                      } else {
                                         Fluttertoast.showToast(
                                            msg: "Today is not a working day");
                                      }
                                    }
                                  },
                                  child: Text("$buttonText",
                                                style: TextStyle(fontSize: 9)),
                                         );
                            }))
                                          )
                                    ])
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                  //------------------card-end-----------------//
                ],
              ),
            ),
            SizedBox(height: 5),
            //--------------------ALL--Widgets------------------//
            headViewList('Announcements', 'orange'),
            Container(
              height: 270,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: annHomeCardData.length,
                  itemBuilder: (context, index) => annHomeCardData[index]),
            ),
            //--------------------------------------//
            headViewList('Birthday', 'lightgreen'),
            Container(
              height: 120,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: birthCardData.length,
                  itemBuilder: (context, index) => birthCardData[index]),
            ),
            //---------------------------------------------//
            headViewList('Leave Management', 'green'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Material(
                elevation: 3,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.all(
                      Radius.circular(20),
                    ),
                    color: MediaQuery.of(context).platformBrightness ==
                            Brightness.light
                        ? Colors.white
                        : Color(0xff34354A),
                  ),
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 240,
                            child: ListView.builder(
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: leaveCardData.length,
                                itemBuilder: (context, index) =>
                                    leaveCardData[index]),
                          ),
                          ElevatedButton(
                              onPressed: () {},
                              child: const Text('Apply Leave',
                                  style: TextStyle(color: Colors.white))),
                          SizedBox(height: 10),
                        ]),
                  ),
                ),
              ),
            ),
            //--------------------------------------------------------//
            headViewList('Team Member', 'green'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: SizedBox(height: 200, child: TeamCard()),
            ),
            //---------------------------------------------------------//
            headViewList('Events', 'blue'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: SizedBox(
                  height: 210,
                  child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: eventCardData.length,
                      itemBuilder: (context, index) => eventCardData[index])),
            ),
            //---------------------------------------------------------//
            headViewList('Upcoming Holidays', 'lightblue'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Material(
                elevation: 3,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(15),
                    ),
                    color: MediaQuery.of(context).platformBrightness ==
                            Brightness.light
                        ? Colors.white
                        : Color(0xff34354A),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 20),
                          SizedBox(
                            height: 240,
                            child: ListView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: holidayCardData.length,
                                itemBuilder: (context, index) =>
                                    holidayCardData[index]),
                          ),
                        ]),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // StreamBuilder<int> stopwatch() {
  //   return StreamBuilder<int>(
  //                                   stream: _stopWatchTimer.rawTime,
  //                                   initialData: 0,
  //                                   builder: (context, snap) {
  //                                     final value = snap.data;
  //                                     final displayTime =
  //                                         StopWatchTimer.getDisplayTime(
  //                                             value!, milliSecond: false);
  //                                     return Column(
  //                                       children: <Widget>[
  //                                         Padding(
  //                                           padding: const EdgeInsets.only(top: 10),
  //                                           child: Text(
  //                                             displayTime,
  //                                             style: TextStyle(
  //                                                 fontSize: 27,
  //                                                 fontWeight:
  //                                                     FontWeight.bold),
  //                                           ),
  //                                         ),
                                          
  //                                       ],
  //                                     );
  //                                   },
  //                                 );
  // }
  //-----------------------UI--ended--------------------------------//

  //-----------------HeadView-Extracted-below----------------------//
  Padding headViewList(String head, String icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: ListTile(
        leading:
            Image(image: AssetImage('assets/custom/$icon.png'), height: 40),
        title: Text('$head', style: TextStyle(fontWeight: FontWeight.bold)),
        trailing: TextButton(
            onPressed: () {},
            child:
                Text('View all', style: TextStyle(color: Color(0xffbf2634)))),
      ),
    );
  }
// office and current location difference calculator
  double calculateDistance(lat1, lon1, lat2, lon2) {
    var p = 0.017453292519943295;
    var c = cos;
    var a = 0.5 -
        c((lat2 - lat1) * p) / 2 +
        c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

//getting current location
  _getCurrentLocation()async  {
   // for getting the position
    final Geolocator geolocator = Geolocator();
    // Position position =
    //       await Geolocator.getCurrentPosition (desiredAccuracy: LocationAccuracy.low)
    //     .then((Position position) {
    //   setState(() {
    //     _currentPosition = position;
    //     currentLat = position.latitude;
    //     currentLng = position.longitude;
    //     print("_currentPosition => $position");
    //   });
    // }).catchError((e) {
    //   print(e);
    // });
  }

  

//geting office location
  _getOfficeLocation() {
    if (locationId != null) {
      FirebaseFirestore.instance
          .collection('locations')
          .doc("$locationId")
          .snapshots()
          .listen((onValue) {
        officeLat = onValue.data()!["lat"];
        officeLng = onValue.data()!["lng"];
        location = onValue.data()!["location"];
        print("LAT = $officeLat , LNG = $officeLng");
      });
      // } else {
      // return Fluttertoast.showToast(msg: "Kindly set office location first");
    }
  }

//calculate difference between current and office location
  _calculations() {
    if (currentLat == null || currentLng == null) {
      Flushbar(
        messageText: Text(
          "Unable to get current location",
          style: TextStyle(
              fontSize: 15, color: Colors.white, fontWeight: FontWeight.w500),
        ),
        duration: Duration(seconds: 3),
        isDismissible: true,
        icon: Image.asset(
          "assets/images/cancel.png",
          scale: 1.4,
          // height: 25,
          // width: 25,
        ),
        backgroundColor: Color(0xFFBF2B38),
        margin: EdgeInsets.all(8),
        borderRadius: 8,
      )..show(context);
    } else {
      List<dynamic> data = [
        {"lat": officeLat, "lng": officeLng},
        {"lat": currentLat, "lng": currentLng}
      ];
      double totalDistance = 0;
      totalDistance = calculateDistance(
          data[0]["lat"], data[0]["lng"], data[1]["lat"], data[1]["lng"]);

      print("totalDistance = $totalDistance");
      double disMeters = totalDistance * 1000;
      print(disMeters);

      if (disMeters < 50) {
        if (buttonText == "CHECK IN") {
          checkin();
        } else if (buttonText == "CHECK OUT") {
          checkout();
        }
      } else {
        Fluttertoast.showToast(
            msg: "Your location is not matched with office location");
      }
    }
  }

//location based checkin in off
  noLocationCheckin() {
    if (buttonText == "CHECK IN") {
      checkin();
    } else if (buttonText == "CHECK OUT") {
      checkout();
    }
  }

//checkin
  checkin() {
    setState(() {
      buttonText = "CHECK OUT";
    });
    var a;
    var b;
    if (shiftId == null) {
      a = 9;
      b = 0;
    } else {
      DateTime date = DateFormat.jm().parse(from);
      print(DateFormat("HH:mm").format(date));
      String ll = DateFormat("HH:mm").format(date);
      List ab = ll.split(":");
      a = int.parse(ab[0]);
      b = int.parse(ab[1]);
    }

    DateTime abc = DateTime.now();
    TimeOfDay yourTime = TimeOfDay(hour: a, minute: b);
    TimeOfDay nowTime = TimeOfDay(hour: abc.hour, minute: abc.minute);

    double _doubleyourTime =
        yourTime.hour.toDouble() + (yourTime.minute.toDouble() / 60);
    double _doubleNowTime =
        nowTime.hour.toDouble() + (nowTime.minute.toDouble() / 60);

    double _timeDiff = _doubleNowTime - _doubleyourTime;

    _minute = ((_timeDiff - _timeDiff.truncate()) * 60) < 0
        ? 0
        : (_timeDiff - _timeDiff.truncate()) * 60;
    _hr = _timeDiff.truncateToDouble() < 0 ? 0 : _timeDiff.truncateToDouble();
            FirebaseFirestore.instance
        .collection('attendance')
        .where("empId", isEqualTo: "$userId")
        .where("date", isEqualTo: "${DateFormat('MMMM dd yyyy').format(DateTime.now())}")
        .get()
        .then((onValue) {
      if (onValue.docs.isNotEmpty) {
        print("id============${onValue.docs[0].id}");
          // "workHours": "$hours : $minutes : $seconds";
  FirebaseFirestore.instance
        .collection('attendance')
        .doc("${onValue.docs[0].id}")
        .snapshots()
        .listen((value) {
          setState(() {});
          hours = value.data()!['workHours'].split(":")[0];
          minutes = value.data()!['workHours'].split(":")[1];
          seconds = value.data()!['workHours'].split(":")[2];
    });
           FirebaseFirestore.instance.runTransaction((Transaction transaction) async {
      DocumentReference reference =  FirebaseFirestore.instance.collection("attendance").doc(onValue.docs[0].id);
      await reference.update({
        "checkout": null
      });
    });}
      else{
            FirebaseFirestore.instance.runTransaction((Transaction transaction) async {
      DocumentReference reference =
          FirebaseFirestore.instance.collection("attendance").doc();
      await reference.set({
        "date" : "${DateFormat('MMMM dd yyyy').format(DateTime.now())}",
        "checkin": DateTime.now(),
        "empId": "$userId",
        "late":
            "${_hr.toStringAsFixed(0)} hrs & ${_minute.toStringAsFixed(0)} mins",
        "companyId": "$companyId",
        "docId": reference.id,
        "checkout": null
      });      
    }).then(
      (onValue) {},
    ).catchError((e) {
        print('======Error====$e==== ');
      });
      }
      });
     }
//checkout
  checkout() {
    return showDialog(
      context: context,
      barrierDismissible: false, // user must tap button for close dialog!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('CHECK OUT'),
          content: const Text('Are you sure you want to want to checkout?'),
          actions: <Widget>[
            FlatButton(
              child: const Text('No'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            OfflineBuilder(connectivityBuilder: (
              BuildContext context,
              ConnectivityResult connectivity2,
              Widget child,
            ) {
              if (connectivity2 == ConnectivityResult.none) {
                return FlatButton(
                  child: const Text('Yes'),
                  onPressed: () {
                    Flushbar(
                      messageText: Text(
                        "No Internet Connection",
                        style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontWeight: FontWeight.w500),
                      ),
                      duration: Duration(seconds: 3),
                      isDismissible: true,
                      icon: Image.asset(
                        "assets/images/cancel.png",
                        scale: 1.4,
                        // height: 25,
                        // width: 25,
                      ),
                      backgroundColor: Color(0xFFBF2B38),
                      margin: EdgeInsets.all(8),
                      borderRadius: 8,
                    ).show(context);
                  },
                );
              } else {
                return child;
              }
            }, builder: (BuildContext context) {
              return TextButton(
                child: const Text('Yes'),
                onPressed: () {
                  setState(() {
                    buttonText = "CHECK IN";
                  });
                  FirebaseFirestore.instance
                      .runTransaction((Transaction transaction) async {
                    DocumentReference reference = FirebaseFirestore.instance
                        .collection("attendance")
                        .doc("$docId");
                    await reference.update({
                      "checkout": DateTime.now(),
                      "workHours": "$hours : $minutes : $seconds"
                    });
                  })
                        .catchError((e) {
                          print('======Error====$e==== ');
                        });
                  Navigator.pop(context);
                },
              );
            })
          ],
        );
      },
    );
  }
}

class CustomTextContainer extends StatelessWidget {
  
  final String ?label;
  final String ?value;
  CustomTextContainer({Key?key,this.label, this.value}): super(key: key);


  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5),
      padding: EdgeInsets.all(20),
      decoration: new BoxDecoration(
        borderRadius: new BorderRadius.circular(10),
        color: Colors.black87,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(
            '$value',
            style: TextStyle(
                color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold),
          ),
          Text(
            '$label',
            style: TextStyle(
              color: Colors.white70,
            ),
          )
        ],
      ),
    );
  }
}

