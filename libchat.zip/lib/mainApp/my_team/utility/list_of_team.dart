// 1st final LeaveCard Data

import 'package:hr_app/mainApp/my_team/utility/team_cards.dart';

List<TeamCard> teamCardData = [
  TeamCard('T1', 'late'),
  TeamCard('T2', 'on Time'),
  TeamCard('T3', ''),
  TeamCard('T4', 'on Time'),
  TeamCard('T4', 'late'),
  TeamCard('T3', 'late'),
  TeamCard('T2', 'on Time'),
  TeamCard('T1', 'late'),
];
