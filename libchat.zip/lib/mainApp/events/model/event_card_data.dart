import 'package:hr_app/mainApp/events/utility/event_card.dart';

List myevents = [
  EventCard(
    text: 'This super leogue Lorem 2017',
    date: DateTime.utc(2021, 05, 20, 12, 14),
    image: 'assets/event_pic.png',
  ),
  EventCard(
    text: 'This super leogue Lorem 2017',
    date: DateTime.utc(2021, 06, 20, 16, 04),
    image: 'assets/event_pic1.png',
  ),
  EventCard(
    text: 'This super leogue Lorem 2017',
    date: DateTime.utc(2021, 07, 20, 12, 04),
    image: 'assets/event_pic.png',
  ),
  EventCard(
    text: 'This super leogue Lorem 2017',
    date: DateTime(2021, 08, 20, 24, 00),
    image: 'assets/event_pic1.png',
  ),
  EventCard(
    text: 'This super leogue Lorem 2017',
    date: DateTime(2021, 05, 20, 16, 04),
    image: 'assets/event_pic.png',
  ),
];
