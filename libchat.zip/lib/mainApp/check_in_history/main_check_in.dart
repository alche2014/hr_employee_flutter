// ignore_for_file: avoid_unnecessary_containers, prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/mainApp/check_in_history/utility/check_in_card.dart';
import 'package:hr_app/mainApp/check_in_history/utility/drop_down.dart';
import 'package:hr_app/mainApp/check_in_history/utility/linear_bar_indicator.dart';

//-----------checkin History/Screen3---------------//


//-------------Final String defined---------------//

String name = 'Member Name';
String date = '02-05-2021 Thu';
String timeIN = 'Checkin: 09:25am';
String timeOUT = 'Checkout: 06:00pm';
String content = 'Total Working Hours: 8hr 20min';
String late = 'Late';
String onT = 'On Time';

class MainCheckIn extends StatefulWidget {
  final uid;
  MainCheckIn({Key? key, this.uid}) : super(key: key);

  @override
  _MainCheckInState createState() => _MainCheckInState();
}

class _MainCheckInState extends State<MainCheckIn> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      // appBar: buildMyAppBar(context, 'Checkin History', true), //custom appbar
      body: Stack(
        children: [
          const BackgroundCircle(),
          NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              buildMyNewAppBar(context, 'Checkin History', true),
            ],
          body: SingleChildScrollView(
            child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
            .collection("attendance")
            .where("empId", isEqualTo: "${widget.uid}")
            .snapshots(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text("ERROR"),
            );
          } else if (snapshot.hasData) {
            return snapshot.data!.docs.isEmpty
                ? Center(
                    child: Container(
                      margin: EdgeInsets.only(bottom: 20, top: 50),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(
                            Icons.calendar_today,
                            color: Color(0xFFBF2B38),
                            size: 100,
                          ),
                          Text(
                            "It's empty here.",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontFamily: "Roboto",
                                fontWeight: FontWeight.w600),
                          ),
                          Text(
                            "No records found.",
                            style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 12,
                                fontFamily: "Roboto",
                                fontWeight: FontWeight.w400),
                          ),
                          
                        ],
                      ),
                    ),
                  )
                :  Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        DropDownOpt(),        //dropdown menu define below
                      ],
                    ),
                    SizedBox(height: 10),
                    LeaveCard(),
                    SingleChildScrollView(
                      child: ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: snapshot.data!.docs.length,
                      itemBuilder: (BuildContext context, int index) {
                        return snapshot.data!.docs[index]['checkout'] !=null ?
                         CheckInCard(snapshot.data!.docs[index]): Container();
                      }
                     
                    
                    ))]);
                
              }else{
                return Center(
              child: CircularProgressIndicator(),
            );
              }}
            ),
          ),
          ),
        ],
      ),
    );
  }
 }
