import 'package:cloud_firestore/cloud_firestore.dart';

class MyAnnouncement {
  MyAnnouncement({ required this.text1,required this.text2,required this.date});
   String text1;
  String text2;
  Timestamp date;
  // bool fulltext;
}
