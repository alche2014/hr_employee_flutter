//.................custom appbar...............

import 'package:flutter/material.dart';

AppBar appBar(
  BuildContext context,
  final String titilee,
  bool leading,
  String myicon,
  bool barcolor,
) {
  return AppBar(
    elevation: 0,
    title: Text(titilee),
    // backgroundColor: Colors.blue,
    backgroundColor: barcolor == false ? Colors.transparent : Color(0xFFC53B4B),
    automaticallyImplyLeading: leading,
    actions: <Widget>[
      if (myicon == 'tune')
        IconButton(
          icon: Icon(Icons.tune),
          onPressed: () {
            // Navigator.of(context).push(
            //     MaterialPageRoute(builder: (context) => Notifications()));
          },
        ),
      if (myicon == 'notification')
        IconButton(
          icon: Icon(
            Icons.notifications,
          ),
          onPressed: () {
            // Navigator.of(context)
            //     .push(MaterialPageRoute(builder: (context) => Notifications()));
          },
        ),
    ],
  );
}
