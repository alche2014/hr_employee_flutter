// ignore: file_names
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hr_app/AppBar/appbar.dart';
import 'package:hr_app/Dailog/loadingDailog.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/mainApp/work_info/utility/build_my_input_decoration.dart';
import 'package:timeago/timeago.dart';

import '../../colors.dart';

class AddAboutScreen extends StatefulWidget {
   const AddAboutScreen({required Key ? key,  required this.title}) : super(key: key);
  final  title;
  @override
  _AddAboutScreenState createState() => _AddAboutScreenState();
}

class _AddAboutScreenState extends State<AddAboutScreen> {
   TextEditingController descriptionController = TextEditingController();
           FocusNode _descriptionFocus = new FocusNode();
           late String userId;
           late String description;
          final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

   
  
  @override
void initState() {
  super.initState();
    userId = widget.title["uid"];

   



    descriptionController = new TextEditingController(
      text: widget.title["aboutYou"] == null
          ? null
          : widget.title["aboutYou"],
    );

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       body: Stack(
        children: [
           const BackgroundCircle(),
          NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              buildMyNewAppBar(context, 'About ', true),
            ],
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(left: 10,right: 10),
            child: Form(
             key: _formKey,
              child: TextFormField(
              controller:descriptionController ,
              focusNode: _descriptionFocus,
              onFieldSubmitted: (term) {
                  _descriptionFocus.unfocus(); },
                  maxLines: 10,
                  decoration: buildMyInputDecoration(context, 'Description'),
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  // validator:validateDescription,
                  onSaved: (String ? value) => description = value!,

                ),
            ),
          ),
             Container(
                 margin: const EdgeInsets.only(top: 20,bottom: 15,),
               child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 60,
                      
                      child: Container(
                             margin: const EdgeInsets.only(left: 15,right: 15,bottom: 15,),

                        child: ElevatedButton(
                          child: const Text('SAVE'), //next button
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            primary: darkRed,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5)),
                          ),
                          onPressed: () {
                            validateAndSave();
                          },
                        ),
                      ),
                    ),
                  ),
                ],
                ),
             )
        ],
      ),
      
    
    ),
    
               
    ]));
  }
  validateAndSave() async {
    final form = _formKey.currentState;
    if (form!.validate()) {
      
      showLoadingDialog(context);
     
      FirebaseFirestore.instance.runTransaction((Transaction transaction) async {
        DocumentReference reference =
            FirebaseFirestore.instance.collection("employees").doc(userId);
        await reference.update({
       
          "aboutYou":
              descriptionController.text == "" ? null : descriptionController.text,
        
          
        });
      }).whenComplete(() {
        Navigator.pop(context);

        Fluttertoast.showToast(msg: "About  info is updated successfully");
      })
        .catchError((e) {
          print('======Error====$e==== ');
        });
      Future.delayed(Duration(milliseconds: 1150), () {
        // Navigator.of(context).pop();
      });
      // }
    } else {
      print('form is invalid');
    }
  }
    void showLoadingDialog(BuildContext context) {
    // flutter defined function
    Navigator.of(context).push(PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) => LoadingDialog()));
  }
}
