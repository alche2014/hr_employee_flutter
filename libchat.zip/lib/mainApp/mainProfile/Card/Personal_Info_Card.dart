// ignore_for_file: file_names

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/mainApp/Personal_Info/contact_info.dart';
import '../../../colors.dart';

class PersonalInfoCard extends StatefulWidget {
   final data;
   PersonalInfoCard({Key ? key, this.data,}) : super(key: key);

  @override
  _PersonalInfoCardState createState() => _PersonalInfoCardState();
}

class _PersonalInfoCardState extends State<PersonalInfoCard> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.withOpacity(0.4), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                const Text('Personal Info',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, color: darkRed)),
                IconButton(
                    onPressed: () {
                   
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ContactInfo(data: widget.data)));
                
                    },
                    icon: const Icon(Icons.edit_outlined, color: Colors.grey)),
                    ]),
                   personalInfo(widget.data),
              // Row(children: const [
              //   Text('Name: '),
              //   Text('User Name', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Email: '),
              //   Text('loremipsum@gmail.com',
              //       style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Phone: '),
              //   Text('0311-1111100', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('City: '),
              //   Text('Lahore, Punjab', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Gender: '),
              //   Text('Male', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Blood Group: '),
              //   Text('A+', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Marital Stats:: '),
              //   Text('Single', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Relation Name: '),
              //   Text('Lorem Ipsum', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Relation: '),
              //   Text('Father', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 15),
              // Row(children: const [
              //   Text('Relation Phone: '),
              //   Text('0311465467886', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 15),
              // Row(children: const [
              //   Text('CNIC: '),
              //   Text('34603-11148761-2', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 15),
              // Row(children: const [
              //   Text('Location: '),
              //   Text('1 floor MM Alam road Vogue\n tower Lahore pakistan',
              //       style: TextStyle(color: Colors.grey)),
              // ]),
              const SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }

  Widget personalInfo(snapshot) {
    return Container(
      // width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.only(top: 10),
      padding: EdgeInsets.only(bottom: 15, left: 8, right: 8),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
             
                Expanded(
                  flex: 3,
                  child: Container(
                    child: Text(
                      "Phone: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["phone"] == null ? "Phone" : snapshot["phone"],
                      style: TextStyle(
                          color: snapshot["phone"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
            
                Expanded(
                  flex: 3,
                  child: Container(
                    child: Text(
                      "Other Email: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["otherEmail"] == null
                          ? "Email"
                          : snapshot["otherEmail"],
                      style: TextStyle(
                          color: snapshot["otherEmail"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          // Container(
          //   margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 1,
          //         child: Icon(
          //           Icons.folder_shared,
          //           color: Color(0xFFBF2B38),
          //           size: 18,
          //         ),
          //       ),
          //       Expanded(
          //         flex: 3,
          //         child: Container(
          //           child: Text(
          //             "CNIC: ",
          //             style: TextStyle(
          //                 color: Colors.grey[700],
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 14),
          //           ),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["cnic"] == null ? "CNIC" : snapshot["cnic"],
          //             style: TextStyle(
          //                 color: snapshot["cnic"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
             
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Bank Name: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    // margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["bankName"] == null
                          ? "Bank Name"
                          : snapshot["bankName"],
                      style: TextStyle(
                          color: snapshot["bankName"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
              
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Bank Number: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    // margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["bankNumber"] == null
                          ? "Bank Number"
                          : snapshot["bankNumber"],
                      style: TextStyle(
                          color: snapshot["bankNumber"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
              
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Blood Group: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    // margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["bloodGroup"] == null
                          ? "Blood Group"
                          : snapshot["bloodGroup"],
                      style: TextStyle(
                          color: snapshot["bloodGroup"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          // Container(
          //   margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 1,
          //         child: Icon(
          //           Icons.nature_people,
          //           color: Color(0xFFBF2B38),
          //           size: 18,
          //         ),
          //       ),
          //       Expanded(
          //         flex: 3,
          //         child: Container(
          //           child: Text(
          //             "Age: ",
          //             style: TextStyle(
          //                 color: Colors.grey[700],
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 14),
          //           ),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["age"] == null ? "Age" : snapshot["age"],
          //             style: TextStyle(
          //                 color: snapshot["age"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          // Container(
          //   margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //       Expanded(
          //         flex: 1,
          //         child: Icon(
          //           Icons.date_range,
          //           color: Color(0xFFBF2B38),
          //           size: 18,
          //         ),
          //       ),
          //       Expanded(
          //         flex: 3,
          //         child: Container(
          //           child: Text(
          //             "DOB: ",
          //             style: TextStyle(
          //                 color: Colors.grey[700],
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 14),
          //           ),
          //         ),
          //       ),
          //       Expanded(
          //         flex: 7,
          //         child: Container(
          //           margin: EdgeInsets.only(left: 10),
          //           child: Text(
          //             snapshot["dob"] == null ? "Dob" : snapshot["dob"],
          //             style: TextStyle(
          //                 color: snapshot["dob"] == null
          //                     ? Colors.grey[500]
          //                     : Colors.black,
          //                 fontWeight: FontWeight.w400,
          //                 fontSize: 15),
          //           ),
          //         ),
          //       )
          //     ],
          //   ),
          // ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
               
                Expanded(
                  flex: 4,
                  child: Container(
                    padding: EdgeInsets.only(right: 8),
                    child: Text(
                      "Marital Status: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["maritalStatus"] == null
                          ? "Marital Status"
                          : snapshot["maritalStatus"],
                      style: TextStyle(
                          color: snapshot["maritalStatus"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
             
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Permanent Address: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    // margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["address"] == null
                          ? "Address"
                          : snapshot["address"],
                      style: TextStyle(
                          color: snapshot["address"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
           
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Address Per CNIC: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    // margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["cnicAddress"] == null
                          ? "Address Per CNIC"
                          : snapshot["cnicAddress"],
                      style: TextStyle(
                          color: snapshot["cnicAddress"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
          
                Expanded(
                  flex: 4,
                  child: Container(
                    padding: EdgeInsets.only(right: 5),
                    child: Text(
                      "Emergency Contact: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    // margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["emergencyPhone"] == null
                          ? "Emergency Contact"
                          : snapshot["emergencyPhone"],
                      style: TextStyle(
                          color: snapshot["emergencyPhone"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
    // });
  }

    }

class MyTextField extends StatelessWidget {
  const MyTextField({
    Key? key,
    required this.hint,
  }) : super(key: key);
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: TextField(
        enabled: false,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          filled: true,
          fillColor: Theme.of(context).scaffoldBackgroundColor,
          hintText: hint,
          hintStyle: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }
}
