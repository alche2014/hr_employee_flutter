// ignore_for_file: file_names

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/mainApp/mainProfile/add_about.dart';
import 'package:hr_app/models/listofdata.dart';

import '../../../colors.dart';

class AboutCard extends StatefulWidget {
  final data;
   const AboutCard({Key? key ,this.data}) : super(key: key);

  @override
  _AboutCardState createState() => _AboutCardState();
}

class _AboutCardState extends State<AboutCard> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.withOpacity(0.4), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('About',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, color: darkRed)),
                IconButton(
                    onPressed: () {

                       Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => 
                            AddAboutScreen(title:widget.data, key: null,)));
                      
                    },
                    icon: const Icon(Icons.edit_outlined, color: Colors.grey)),
              ]),
              Container(
                margin: EdgeInsets.only(left: 10),
                child: Text(
                  widget.data!["aboutYou"] == null
                      ? "Not Added Yet"
                      :   widget.data["aboutYou"],
                  style: TextStyle(
                      color:   widget.data["aboutYou"] == null
                          ? Colors.grey[500]
                          : Colors.black,
                      fontWeight: FontWeight.w400,
                      fontSize: 15),
                ),
              ),
              // Text(bodyText),
               const SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }
}
