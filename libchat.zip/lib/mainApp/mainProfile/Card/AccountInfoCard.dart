// ignore_for_file: file_names
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/mainApp/Personal_Info/bank_Info.dart';

import '../../../colors.dart';

class AccountInfoCard extends StatelessWidget {
 final data;
   AccountInfoCard({Key ? key, this.data,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.withOpacity(0.4), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Account Info',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, color: darkRed)),
                IconButton(
                    onPressed: () {
                         Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AccountInfoCard(data:data)));
                    },
                    icon: const Icon(Icons.edit_outlined, color: Colors.grey)),
              ]),
              AccountInfo(data),
              // Row(children: const [
              //   Text('Bank Name: '),
              //   Text('Alfla Bank', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 6),
              // //
              // Row(children: const [
              //   Text('Account No: '),
              //   Text('1348941324981', style: TextStyle(color: Colors.grey)),
              // ]),
              // const SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }

    Widget AccountInfo(snapshot) {
    return Container(
      // width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.only(top: 10),
      padding: EdgeInsets.only(bottom: 15, left: 8, right: 8),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
       
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
             
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Bank Name: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["bnkName"] == null
                          ? "Bank Name"
                          : snapshot["bnkName"],
                      style: TextStyle(
                          color: snapshot["bnkName"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 6, bottom: 6, left: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
              
                Expanded(
                  flex: 4,
                  child: Container(
                    child: Text(
                      "Bank Number: ",
                      style: TextStyle(
                          color: Colors.grey[700],
                          fontWeight: FontWeight.w400,
                          fontSize: 14),
                    ),
                  ),
                ),
                Expanded(
                  flex: 7,
                  child: Container(
                    margin: EdgeInsets.only(left: 10),
                    child: Text(
                      snapshot["bankNo"] == null
                          ? "Bank Number"
                          : snapshot["bankNo"],
                      style: TextStyle(
                          color: snapshot["bankNo"] == null
                              ? Colors.grey[500]
                              : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 15),
                    ),
                  ),
                )
              ],
            ),
          )]));
       
      
    // });
  }


}

class MyTextField extends StatelessWidget {
  const MyTextField({
    Key? key,
    required this.hint,
  }) : super(key: key);
  final String hint;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: TextField(
        enabled: false,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          filled: true,
          fillColor: Theme.of(context).scaffoldBackgroundColor,
          hintText: hint,
          hintStyle: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }
}
