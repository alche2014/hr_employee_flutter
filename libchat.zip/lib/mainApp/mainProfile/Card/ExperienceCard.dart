// ignore_for_file: file_names

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:hr_app/mainApp/experiences/add_experiences.dart';
import 'package:hr_app/mainApp/experiences/main_experiences.dart';

import '../../../colors.dart';

class ExperienceCard extends StatelessWidget {
   final  data;
   ExperienceCard({Key ? key, this.data,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var courseDocument = data;
    var workexp = courseDocument['workExperience'];
    // var edu = courseDocument['education'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.withOpacity(0.4), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('experience',
                    style:
                        TextStyle(fontWeight: FontWeight.bold, color: darkRed)),
                Expanded(
                flex: 2,
                child: InkWell(
                  onTap: () {
                     Navigator.push(context, MaterialPageRoute(builder: 
                    (context)=> MainExperiences( workexp: data,))); },
                  child: Container(
                    width: 60,
                    height: 40,
                    padding: EdgeInsets.only(top: 5, right: 10, bottom: 5),
                    alignment: Alignment.topRight,
                    child: Icon(
                     Icons.edit_outlined,
                    color: Colors.grey,
                    ),
                  ),
                ),
              ),
              
                // IconButton(
                //     onPressed: () {
                //       Navigator.push(context, MaterialPageRoute(builder: 
                //       (context)=> AddExperience( data: data,)));
                //     },
                //     icon: const Icon(Icons.edit_outlined, color: Colors.grey)),
              ]),
           workexp == null
                      ? Center(
                          child: Text(
                            "No experience added yet",
                            style: TextStyle(
                                color: Colors.grey[700],
                                fontWeight: FontWeight.w400,
                                fontSize: 13),
                          ),
                        )
                      : workexp != null && workexp.length == 0
                          ? Center(
                              child: Text(
                              "No experience added yet",
                              style: TextStyle(
                                  color: Colors.grey[700],
                                  fontWeight: FontWeight.w400,
                                  fontSize: 13),
                            ))
                          :   
                          
                          
                                Container(
                                child: ListView.builder(
                                padding:EdgeInsets.zero,
                                // separatorBuilder: (context, index) => Divider(
                                // color: Colors.grey, ),
                               itemCount: workexp != null ||  workexp.length <=3 ? workexp.length : 3,
                               shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (BuildContext context, int index) {
                              return Container(
                                margin: EdgeInsets.only(bottom: 10),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container( child: Container(
                                      // margin:
                                      //     EdgeInsets.only(left: 10),
                                      child: Text(
                                        workexp == null
                                            ? "Title"
                                            : workexp[index]
                                                ['title'],
                                        style: TextStyle(fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                          top: 6, bottom: 6),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          // Expanded(
                                          //   flex: 1,
                                          //   child: Icon(
                                          //     Icons.title,
                                          //     color: Color(0xFFBF2B38),
                                          //     size: 18,
                                          //   ),
                                          // ),
                                     
                                          Container(
                                            // margin:
                                            //     EdgeInsets.only(left: 4),
                                            child: Text(
                                              workexp == null
                                                  ? "Company Name"
                                                  : workexp[index]
                                                      ['companyName'] + " - "+ "" +
                                                      workexp[index]
                                                      ['empStatus'] ,
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontWeight:
                                                      FontWeight.w400,
                                                  fontSize: 15),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                       bottom: 6),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                        
                                          Expanded(
                                            flex: 8,
                                            child: Container(
                                              // margin:
                                              //     EdgeInsets.only(left: 4),
                                              child: Text(
                                                workexp == null
                                                    ? "Years"
                                                    : (workexp[index]
                                                            ['expstartDate'] +
                                                        " - " +
                                                        workexp[index]
                                                            ['expLastDate']),
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.w400,
                                                    fontSize: 15),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    
                                  ],
                                ),
                            
                              );
                            
                              }),
                          ),


              
                              
               SizedBox(height: 15),
            ],
          ),
        ),
      ),
    );
  }
}
