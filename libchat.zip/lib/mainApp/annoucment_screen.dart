
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

   /* ShowAnnoucementScreen appears when users press on notifation dialog 
   then dialog navigate to this screen and show th information  which 
 notifation dialog conatins. */

class ShowAnnouncementScreen extends StatefulWidget {
  final docId;
  ShowAnnouncementScreen({Key? key, this.docId}) : super(key: key);
  @override
  _ShowAnnouncementScreenState createState() => _ShowAnnouncementScreenState();
}

class _ShowAnnouncementScreenState extends State<ShowAnnouncementScreen> {
  String? title;
  String ? description;
  Timestamp ? time;
  List employees = [];
  Connectivity? connectivity;
  StreamSubscription<ConnectivityResult> ?subscription;
  bool isNetwork = true;

  @override
  void initState() {
    super.initState();
    //check internet connection
    connectivity = new Connectivity();
    subscription =
        connectivity!.onConnectivityChanged.listen((ConnectivityResult result) {
      print(result.toString());
      if (result == ConnectivityResult.none) {
        setState(() {
          isNetwork = false;
        });
      } else if (result == ConnectivityResult.mobile ||
          result == ConnectivityResult.wifi) {
        setState(() {
          isNetwork = true;
        });
      }
    });

    setState(() {
      loadAnnouncementInfo();
    });
    Future.delayed(Duration(milliseconds: 500), () {
      setState(() {});
    });
  }

  @override
  void dispose() {
    subscription!.cancel();
    super.dispose();
  }

  loadAnnouncementInfo() {
    FirebaseFirestore.instance
        .collection("announcements")
        .doc("${widget.docId}")
        .snapshots()
        .listen((onData) {
      title = onData.data()!["announcementTitle"];
      description = onData.data()!["announcementDes"];
      time = onData.data()!["timeStamp"];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFBF2B38),
        title: Text(
          "Announcement",
          style: TextStyle(
              color: Colors.white,
              fontFamily: "Hind",
              fontSize: 20,
              fontWeight: FontWeight.w500),
        ),
        leading: InkWell(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.close,
            color: Colors.white,
          ),
        ),
        // centerTitle: true,
      ),
      body: SingleChildScrollView(
              child: Container(
                margin: EdgeInsets.only(top: 20, left: 10, right: 10),
                width: MediaQuery.of(context).size.width,
                child: Container(
                  child: Card(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(left: 10, top: 10),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                  flex: 2,
                                  child: Container(
                                      height: 50,
                                      width: 50,
                                      margin: EdgeInsets.only(
                                          top: 10,
                                          left: 5,
                                          right: 5,
                                          bottom: 10),
                                      decoration: new BoxDecoration(
                                        color: Color(0xFFBF2B38),
                                        border: Border.all(
                                          // color: Colors.grey[200],
                                          width: 1.0,
                                        ),
                                        borderRadius: new BorderRadius.all(
                                            const Radius.circular(80.0)),
                                      ),
                                      // color: Color(0xFFBF2B38),
                                      child: Icon(
                                        Icons.mic,
                                        color: Colors.white,
                                      ))),
                              Expanded(
                                flex: 8,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                        margin: EdgeInsets.only(
                                            top: 10, left: 10, bottom: 5),
                                        child: Text(
                                          title == null ? "" : title.toString(),
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18),
                                        )),
                                    Container(
                                        margin: EdgeInsets.only(
                                            left: 10, bottom: 10),
                                        child: Text(
                                          time == null
                                              ? ""
                                              : DateFormat("dd MMM, yyyy")
                                                  .format(time!.toDate()),
                                          style: TextStyle(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14),
                                        )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.only(
                                top: 10, left: 30, right: 20, bottom: 20),
                            child: Text(
                              description == null ? "" : description.toString(),
                              style: TextStyle(
                                  fontWeight: FontWeight.w400, fontSize: 16),
                            )),
                      ],
                    ),
                  ),
                ),
              ),
            ),
    );
  }
}
