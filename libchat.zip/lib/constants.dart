const FINISHED_ON_BOARDING = 'finishedOnBoarding';
const COLOR_PRIMARY = 0xFF00BF6D;
const FACEBOOK_BUTTON_COLOR = 0xFF415893;
const USERS = 'employees';
