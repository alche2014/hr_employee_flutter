import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'mainApp/mainProfile/Announcemets/constants.dart';

class PrivacyApp extends StatefulWidget {
  @override
  _PrivacyAppState createState() => _PrivacyAppState();
}

class _PrivacyAppState extends State<PrivacyApp> {
  final _key = UniqueKey();

  late WebViewController controller;

  bool loading = true;

  bool isLoading = true;

  void initState() {
    super.initState();
    // Enable hybrid composition.
    // WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Privacy'),
        backgroundColor: kPrimaryColor,
      ),
      body: Stack(
        children: [
          WebView(
            key: _key,
            initialUrl: "https://www.alchemative.com/privacy-policy/",
            javascriptMode: JavascriptMode.unrestricted,
            onPageFinished: (finish) {
              setState(() {
                isLoading = false;
              });
            },
            onWebViewCreated: (WebViewController webViewController) {
              // controller = webViewController;
            },
          ),
          isLoading
              ? Center(
                  child: LoadingAnimation(),
                )
              : Stack(),
        ],
      ),
    );
  }
}

class LoadingAnimation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SpinKitCircle(
      itemBuilder: (_, int index) {
        return DecoratedBox(
          decoration: BoxDecoration(
            color: index.isEven ? Colors.black : Colors.white,
          ),
        );
      },
      size: 30.0,
    );
  }
}
