
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/Log%20Screen/sign_in.dart';
import 'package:rxdart/rxdart.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;


import 'helper.dart';

class AuthService {
 late  String ? email, password;

 late  String? name;
 late String ?imageUrl;
  // Dependencies
   late final FirebaseAuth _auth = FirebaseAuth.instance;
 late  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Shared State for Widgets
 late final Stream<FirebaseAuth> user; // firebase user
  late final  Stream<Map<String, dynamic>> profile; // custom user data in Firestore
  PublishSubject loading = PublishSubject();

  // constructor
 //check user exist in db or not
  Future<bool> userExist(FirebaseAuth user) async {
    DocumentReference ref = _db.collection('employees').doc(user.currentUser!.uid);
    DocumentSnapshot snapShot = await ref.get();

    if (snapShot.data == null) {
      return true;
    } else {
      return false;
    }
  }

//check user is loggedin or not
  Future<bool> isLogin() async {
   final   firebaseUser = auth.FirebaseAuth.instance.currentUser;
    if (user != null) {
      return true;
    } else {
      return false;
    }
  }

  // Future<bool> company() async {
  //   final FirebaseUser user = await _auth.currentUser();
  //   DocumentReference ref = _db.collection('employees').document(user.uid);
  //   DocumentSnapshot snapShot = await ref.get();
  //   if (snapShot.data.containsKey("companyId") == true) {
  //     print("comp = ${snapShot.data.containsKey("companyId")}");
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

// //checking that user email contains any private domain or public domain
//   Future<bool> personalDomain(FirebaseUser user) async {
//     List publicDomains = [
//       "gmail.com",
//       "outlook.com",
//       "icloud.com",
//       "yahoo.com",
//       "gmx.com",
//       "aol.com",
//       "protonmail.com",
//       "tutantoo.com",
//       "lycos.com"
//     ];
//     String userEmail = user.email;
//     var domainPart = userEmail.split('@');
//     print(publicDomains.contains(domainPart[1]));

//     if (publicDomains.contains(domainPart[1])) {
//       return true;
//     } else {
//       return false;
//     }
//   }

//check comapny domain exists or not
  Future<bool> domainExist(FirebaseAuth user) async {
    List domainList = [];
    String? userEmail = user.currentUser!.email;
    var domainPart = userEmail!.split('@');
    print(domainPart[1]);

    await FirebaseFirestore.instance
        .collection("company")
        .get()
        .then((onValue) {
      final List<DocumentSnapshot> documents = onValue.docs;
      for (var doc in documents) {
        domainList.addAll(doc["domain"]);
      }
      // ignore: avoid_print
      print("domainList = $domainList");
    });

    if (domainList.contains(domainPart[1])) {
      return true;
    } else {
      return false;
    }
  }

//logout function
  void signOut(BuildContext context) async {
    // FirebaseUser user = await _auth.currentUser();
    await _auth.signOut();
// await user.delete();
pushAndRemoveUntil(context, SignIn(), false);
    Navigator.of(context)
        .pushNamedAndRemoveUntil('/login', (Route<dynamic> route) => false);
  }

}

final AuthService authService = AuthService();
