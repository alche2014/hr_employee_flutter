import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:hr_app/models/user.dart';
import 'package:hr_app/models/user.dart';
import 'package:hr_app/services/helper.dart';
import 'package:hr_app/models/user.dart' as users;

import '../constants.dart';

class FireStoreUtils {
    
    
     
  // static Firestore firestore =Firestore.instance;
  
  // static Reference storage = FirebaseStorage.instance.ref();

  // static Future getCurrentUser(String uid) async {
  //   DocumentSnapshot userDocument =
  //       await FirebaseFirestore.instance.collection(USERS).doc(uid).get();
  //   if (userDocument.exists) {
  //     return User.fromJson(userDocument.data);
  //   } else {
  //     return null ;
  //   }
  // }

    static Future getCurrentUser(String uid) async {
    DocumentSnapshot<Map<String, dynamic>> userDocument =
        await FirebaseFirestore.instance.collection(USERS).doc(uid).get();
    if (userDocument.data() != null && userDocument.exists) {
      // return users.UsersData.fromJson(userDocument.data()!);
    } else {
      return null;
    }
  }
  /// login with email and password with firebase
  /// @param email user email
  /// @param password user password
  static Future<dynamic> loginWithEmailAndPassword(
      String email, String password) async {
        
    try {
      final result = await FirebaseAuth.instance.signInWithEmailAndPassword(
              email: email, password: password);

      // Firestore firestore =Firestore.instance;

       auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;
      // auth.AuthCredential result = await auth.AuthCredential.
      //     .signInWithEmailAndPassword(email: email, password: password);
      //   AuthResult result = await _firebaseAuth.signInWithEmailAndPassword(
      //     email: email, password: password);
      DocumentSnapshot documentSnapshot =
          await FirebaseFirestore.instance.collection(USERS).doc(firebaseUser!.uid).get();
             auth.User? user = await FireStoreUtils.getCurrentUser(firebaseUser.uid);

      if (documentSnapshot.exists) {
      return result.user;}
    } on auth.FirebaseAuthException catch (exception, s) {
      // ignore: avoid_print
      print(exception.toString() + '$s');
      switch ((exception).code) {
        case 'invalid-email':
          return 'Email address is malformed.';
        case 'wrong-password':
          return 'Wrong password.';
        case 'user-not-found':
          return 'No user corresponding to the given email address.';
        case 'user-disabled':
          return 'This user has been disabled.';
        case 'too-many-requests':
          return 'Too many attempts to sign in as this user.';
      }
      return 'Unexpected firebase error, Please try again.';
    } catch (e, s) {
      print(e.toString() + '$s');
      return 'Login failed, Please try again.';
    }
  }

    
  /// save a new user document in the USERS table in firebase firestore
  /// returns an error message on failure or null on success
  // static Future<String?> firebaseCreateNewUser(User user) async {
  //       Firestore firestore =Firestore.instance;

  //     await firestore
  //         .collection(USERS)
  //         .document(user.userID)
  //         .setData(user.toJson())
  //         .then((value) => null, onError: (e) => e);
  //  }
   
   static firebaseSignUpWithEmailAndPassword(
    String emailAddress,
    String password,
    // File? image,
    String name,
  ) async {
    try {
      final result = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: emailAddress, password: password);
      String profilePicUrl = '';
      // if (image != null) {
      //   await updateProgress('Uploading image, Please wait...');
      //   profilePicUrl =
      //       await uploadUserImageToFireStorage(image, result.user.uid ?? '');
      // }
     UsersData  user = users.UsersData(
          email: emailAddress,
          name: name,
          userID: result.user!.uid,
          // profilePictureURL: profilePicUrl
          );
            auth.User? firebaseUser = auth.FirebaseAuth.instance.currentUser;

  auth.User? user1 = await FireStoreUtils.getCurrentUser(firebaseUser!.uid);

        // user = users.UsersData(
        //   email: emailAddress,
        //   name: name,
        //   userID: result.user?.uid ?? '',
        //   profilePictureURL: profilePicUrl);
      // String? errorMessage = await firebaseCreateNewUser(user);
      // ignore: unnecessary_null_comparison
      if (result.user!.uid != null) {
        return user1;
      } else {
        return 'Couldn\'t sign up for firebase, Please try again.';
      }
    } on auth.FirebaseAuthException catch (error) {
      print(error.toString() + '${error.message}');
      String message = 'Couldn\'t sign up';
      switch (error.code) {
        case 'email-already-in-use':
          message = 'Email already in use, Please pick another email!';
          break;
        case 'invalid-email':
          message = 'Enter valid e-mail';
          break;
        case 'operation-not-allowed':
          message = 'Email/password accounts are not enabled';
          break;
        case 'weak-password':
          message = 'Password must be more than 5 characters';
          break;
        case 'too-many-requests':
          message = 'Too many requests, Please try again later.';
          break;
      }
      return message;
    } catch (e) {
      return 'Couldn\'t sign up';
    }
  }}