import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hr_app/background/background.dart';
import 'package:hr_app/colors.dart';
import 'package:hr_app/main.dart';
import 'package:hr_app/mainApp/bottom_navigation/bottom_nav_bar.dart';
import 'package:hr_app/models/user.dart';
import 'package:hr_app/services/auth.dart';
import 'package:hr_app/services/authenticate.dart';
import 'package:hr_app/services/helper.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:hr_app/models/user.dart' as users;



File? _image;

class SignUpScreen extends StatefulWidget {
  @override
  State createState() => _SignUpState();
}

class _SignUpState extends State<SignUpScreen> {
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _key = new GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  late String name, email, password, confirmPassword;

  @override
  Widget build(BuildContext context) {
  

    return Scaffold(
    
      body: Stack(
        children: [
        BackgroundCircle(),
          SingleChildScrollView(
            child: SizedBox(
        height: MediaQuery.of(context).size.height * 1,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          
                child: new Form(
                  key: _key,
                  autovalidateMode: _validate,
                  child: formUI(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }




  Widget formUI() {
    return Column(
      children: <Widget>[
       
          const SizedBox(height: 50),
                ClipRRect(
                  borderRadius: BorderRadius.circular(100),
                  child: CircleAvatar(
                    backgroundColor: Colors.transparent,
                    radius: 70,
                    child: Image.asset("assets/Logo.png"),
                  ),
                ),
                const SizedBox(height: 50),
        TextFormField(
                              validator: validateName,
                    onSaved: (val) => name = val!,
                    textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: "Name",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: const BorderSide(
                                color: Colors.transparent,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: Colors.grey.withOpacity(0.4),
                              ),
                            ),
                          ),
                       ),
                       const SizedBox(height: 20),
                           TextFormField(
                              validator: validateEmail,
                    onSaved: (val) => email = val!,
                    textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: "Email",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: const BorderSide(
                                color: Colors.transparent,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: Colors.grey.withOpacity(0.4),
                              ),
                            ),
                          ),
                       ),
                       const SizedBox(height: 20),
                           TextFormField(
                             controller: _passwordController,
                                             obscureText: true,

                              validator: validatePassword,
                    onSaved: (val) => password = val!,
                    textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: "Password",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: const BorderSide(
                                color: Colors.transparent,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: Colors.grey.withOpacity(0.4),
                              ),
                            ),
                          ),
                       ),
                       const SizedBox(height: 20),
                           TextFormField(
                            onFieldSubmitted: (_) => _signUp(),
                obscureText: true,
                validator: (val) =>
                    validateConfirmPassword(_passwordController.text, val),
                    textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: "Confirm Password",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: const BorderSide(
                                color: Colors.transparent,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: Colors.grey.withOpacity(0.4),
                              ),
                            ),
                          ),
                       ),
 
        Padding(
          padding: const EdgeInsets.only(top: 50.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minWidth: double.infinity),
            child: ElevatedButton(
                        child: const Text('SIGN UP',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          primary: kPrimaryRed,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                        ),
                        onPressed: () {
                          _signUp();
                        },
                      ),
                    
          ),
        ),
      ],
    );
  }

  _signUp() async {
    if (_key.currentState?.validate() ?? false) {
      _key.currentState!.save();
      await _signUpWithEmailAndPassword();
    } else {
      setState(() {
        _validate = AutovalidateMode.onUserInteraction;
      });
    }
  }

  _signUpWithEmailAndPassword() async {
    await showProgress(context, 'Creating new account, Please wait...', false);
    dynamic result = await FireStoreUtils.firebaseSignUpWithEmailAndPassword(
      email.trim(),
      password.trim(),
      // _image,
      name.trim(),
    );
    
    if (result != null) {
      // MyAppState.currentUser = result;
         final firebaseUser = auth.FirebaseAuth.instance.currentUser;
        // final user= await FirebaseAuth.instance.currentUser;

            bool _result = await AuthService().userExist(result);
await hideProgress();
            if (_result) {
              bool domainExist = await AuthService().domainExist(result);
              if (domainExist) {
                List domainList = [];
                String? userEmail = firebaseUser!.email;
                var domainPart = userEmail!.split('@');
                await FirebaseFirestore.instance
                    .collection("company")
                    .get()
                    .then((onValue) {
                  final List<DocumentSnapshot> documents = onValue.docs;
                  for (int i = 0; i < documents.length; i++) {
                    domainList = documents[i]["domain"];
                    if (domainList.contains(domainPart[1])) {
                      // ignore: avoid_print
                      print(documents[i].id);
                      print(firebaseUser.uid);
                      FirebaseFirestore.instance
                          .collection("employees")
                          .doc(firebaseUser.uid)
                          .set({
                        'uid': firebaseUser.uid,
                        'email': "${firebaseUser.email}",
                        'photoURL': "${firebaseUser.photoURL}",
                        'displayName': "${firebaseUser.displayName}",
                        "companyId": documents[i].id,
                        'timeStamp': DateTime.now(),
                        'empId': null,
                        "containsId": false
                      });
                      break;
                    }
                  }
                });
             pushAndRemoveUntil(context, NavBar(0,firebaseUser.uid), false);
              } 
              else {
                showAlertDialog(
          context, 'Couldn\'t Authenticate', 'Login failed, Your company doesnot exist');
              }
            } else {
              pushAndRemoveUntil(context, NavBar(0,firebaseUser!.uid), false);
            }


      // pushAndRemoveUntil(context, MainHomeProfile(user: result), false);
  

    } else if (result != null ) {
      await hideProgress();
      showAlertDialog(context, 'Failed', result.name);
    } else {
      await hideProgress();
      showAlertDialog(context, 'Failed', 'Couldn\'t sign up');
    }
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _image = null;
    super.dispose();
  }
}
