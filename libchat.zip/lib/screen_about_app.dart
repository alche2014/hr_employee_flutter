import 'package:flutter/material.dart';
import 'package:hr_app/mainApp/mainProfile/Announcemets/constants.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class AboutApp extends StatefulWidget {
  @override
  State<AboutApp> createState() => _AboutAppState();
}

class _AboutAppState extends State<AboutApp> {
  final _key = UniqueKey();
  late WebViewController controller;
  bool loading = true;
  bool isLoading = true;
  void initState() {
    super.initState();
    // Enable hybrid composition.
    // WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About'),
        backgroundColor: kPrimaryColor,
      ),
      body: Stack(
        children: [
          WebView(
            key: _key,
            initialUrl: "https://www.alchemative.com/about-us/",
            javascriptMode: JavascriptMode.unrestricted,
            onPageFinished: (finish) {
              setState(() {
                isLoading = false;
              });
            },
            onWebViewCreated: (WebViewController webViewController) {
              controller = webViewController;
            },
          ),
          isLoading
              ? Center(
                  child: LoadingAnimation(),
                )
              : Stack(),
        ],
      ),

      // body: Builder(builder: (context) {
      //   return WebView(
      //     initialUrl: 'https://www.alchemative.com/about-us/',
      //     javascriptMode: JavascriptMode.unrestricted,
      //   );
      // }),
    );
  }
}

class LoadingAnimation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SpinKitCircle(
      itemBuilder: (_, int index) {
        return DecoratedBox(
          decoration: BoxDecoration(
            color: index.isEven ? Colors.black : Colors.white,
          ),
        );
      },
      size: 30.0,
    );
  }
}
