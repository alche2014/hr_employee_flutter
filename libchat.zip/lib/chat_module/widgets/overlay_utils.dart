import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import 'package:simple_animations/simple_animations.dart';

import '../consts.dart';
// import 'package:simple_animations/simple_animations.dart';

class OverlayUtils {
  static late Timer _toastTimer;
  static late  OverlayEntry _overlayEntry;

  static void overlay(
      {required BuildContext context,
      required Widget child,
      required Alignment alignment,
      required Duration duration,
       Color?  color}) {
        if (_overlayEntry == null && (!_toastTimer.isActive)) {
    _overlayEntry = createOverlayEntry(context, child, alignment, color!);
    Overlay.of(context)!.insert(_overlayEntry);
        }
  }

  static removeOverlay() {
    if(_overlayEntry != null) {
      _overlayEntry.remove();
      
    }
  }

  static hasOverlay() => _overlayEntry != null;
  

  static OverlayEntry createOverlayEntry(
      BuildContext context, Widget child, Alignment alignment, Color color) {
    return OverlayEntry(            
      builder: (context) => Align(
        alignment: alignment,
        child: 
        ToastMessageAnimation(
          Material(
            color: Colors.transparent,
            child: child,
          ),        
        ),
      ),
    );
  }
}
enum AnimationType { opacity, translateX }


class ToastMessageAnimation extends StatelessWidget {
  final Widget child;
  const ToastMessageAnimation(this.child);
  @override
  Widget build(BuildContext context) {
    FlutterStatusbarcolor.setStatusBarColor(kBlackColor2);
  final tween = MultiTween<AnimationType>()
      ..add(AnimationType.opacity, Tween(begin: 0.0, end: 1.0),
          const Duration(milliseconds: 500),)
      ..add(
        AnimationType.translateX,
        Tween(begin: 30.0, end: 1.0),
        const Duration(milliseconds: 500),
      );

   return PlayAnimation<MultiTweenValues<AnimationType>>(
      // delay: Duration(milliseconds: (500 * delay).round()),
      duration: tween.duration,
      tween: tween,
      child: child,
      builder: (context, child, value) => Opacity(
        opacity: value.get(AnimationType.opacity),
        child: Transform.translate(
            offset: Offset(value.get(AnimationType.translateX), 0), child: child),
      ),
    ); 
  }
}
