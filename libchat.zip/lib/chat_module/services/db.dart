import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hr_app/chat_module/consts.dart';
import 'package:hr_app/chat_module/models/media_model.dart';
import 'package:hr_app/chat_module/models/message.dart';

class DB {
  final CollectionReference _usersCollection =
      FirebaseFirestore.instance.collection(USERS_COLLECTION);
  final CollectionReference _messagesCollection =
      FirebaseFirestore.instance.collection(ALL_MESSAGES_COLLECTION);

  Stream<QuerySnapshot> getContactsStream() {
    return FirebaseFirestore.instance.collection(USERS_COLLECTION).snapshots();
  }

  Stream<DocumentSnapshot> getUserContactsStream(String uid) {
    return _usersCollection.doc(uid).snapshots();
  }

  Future<DocumentSnapshot> getUser(String id) {
    return _usersCollection.doc(id).get();
  }

  void addNewMessage(String groupId, DateTime timeStamp, dynamic data) {
    try {
      _messagesCollection
          .doc(groupId)
          .collection(CHATS_COLLECTION)
          .doc(timeStamp.millisecondsSinceEpoch.toString())
          .set(data);
    } catch (error) {
      print('****************** DB addNewMessage error **********************');
      print(error);
      throw error;
    }
  }

  Future<QuerySnapshot> getChatItemData(String groupId, [int limit = 20]) {
    try {
      return _messagesCollection
          .doc(groupId)
          .collection(CHATS_COLLECTION)
          .orderBy('timeStamp', descending: true)
          .limit(limit)
          .get();
    } catch (error) {
      print(
          '****************** DB getChatItemData error **********************');
      throw error;
    }
  }

  void addMediaUrl(String groupId, String url, Message mediaMsg) {
    try {
      _messagesCollection
          .doc(groupId)
          .collection(MEDIA_COLLECTION)
          .doc(mediaMsg.timeStamp)
          .set(MediaModel.fromMsgToMap(mediaMsg));
    } catch (error) {
      print('****************** DB addMediaUrl error **********************');
      print(error);
      throw error;
    }
  }

  Stream<QuerySnapshot> getMediaCount(String groupId) {
    try {
      return _messagesCollection
          .doc(groupId)
          .collection(MEDIA_COLLECTION)
          .snapshots();
    } catch (error) {
      print('****************** DB getMediaCount error **********************');
      print(error);
      throw error;
    }
  }

  Stream<QuerySnapshot> getChatMediaStream(String groupId) {
    try {
      return _messagesCollection
          .doc(groupId)
          .collection(MEDIA_COLLECTION)
          .snapshots();
    } catch (error) {
      print('****************** DB getChatMedia error **********************');
      print(error);
      throw error;
    }
  }

  void updateContacts(String userId, dynamic contacts) {
    try {
      _usersCollection
          .doc(userId)
          .set({'contacts': contacts},  SetOptions(merge: true)); 
    } catch (error) {
      print(
          '****************** DB updateContacts error **********************');
      print(error);
      throw error;   
    }
  }

  Future<DocumentSnapshot> addToPeerContacts(
      String peerId, String newContact) async {
    DocumentReference doc;
    DocumentSnapshot docSnapshot;

   try{
      doc = _usersCollection.doc(peerId);
      docSnapshot = await doc.get();

      var peerContacts = [];

      // docSnapshot.data['contacts'].forEach((elem) => peerContacts.add(elem));
      peerContacts.add(newContact);

      FirebaseFirestore.instance.runTransaction((Transaction transaction){
        return  transaction.get(doc)
        .then((value){
           { if (value.exists) {
              transaction.update(doc, {'contacts': peerContacts});
            //  return docSnapshot;
            //  return Promise.resolve(true);

              
             }  
           }});
      
      // async {
      //  final freshDoc = await
        
        });

      // doc.set({'contacts': peerContacts}, merge: true);
    } catch (error) {
      print(
          '****************** DB addToPeerContacts error **********************');
      print(error);
      throw error;
    }

    return docSnapshot;
  }

  Stream<QuerySnapshot> getSnapshotsAfter(
      String groupChatId, DocumentSnapshot lastSnapshot) {
    try {
      return _messagesCollection
          .doc(groupChatId)
          .collection(CHATS_COLLECTION)
          .startAfterDocument(lastSnapshot)
          .orderBy('timeStamp')
          .snapshots();
    } catch (error) {
      print(
          '****************** DB getSnapshotsAfter error **********************');
      print(error);
      throw error;
    }
  }

  Future<QuerySnapshot> getNewChats(
      String groupChatId, DocumentSnapshot lastSnapshot,
      [int limit = 20]) {
    try {
      return _messagesCollection
          .doc(groupChatId)
          .collection(CHATS_COLLECTION)
          .startAfterDocument(lastSnapshot)
          .limit(20)
          .orderBy('timeStamp', descending: true)
          .get();
    } catch (error) {
      print(
          '****************** DB getSnapshotsAfter error **********************');
      print(error);
      throw error;
    }
  }

  Stream<QuerySnapshot> getSnapshotsWithLimit(String groupChatId,
      [int limit = 10]) {
    try {
      return _messagesCollection
          .doc(groupChatId)
          .collection(CHATS_COLLECTION)
          .limit(limit)
          .orderBy('timeStamp', descending: true)
          .snapshots();
    } catch (error) {
      print(
          '****************** DB getSnapshotsWithLimit error **********************');
      print(error);
      throw error;
    }
  }

  void updateMessageField(dynamic snapshot, String field, dynamic value) {
    // try {
    //   FirebaseFirestore.instance.runTransaction((transaction) async {
    //     // DocumentSnapshot freshDoc = await transaction.get(snapshot.reference);
    //     transaction.update(snapshot.reference, {'$field': value});
    //   });
    // } catch (error) {
    //   print( '****************** DB updateMessageField error **********************');
    //   print(error);
    //   throw error;
    // }
    FirebaseFirestore.instance .runTransaction((Transaction tx)
    { return tx.get(snapshot.reference).then((recipeeSnapshot)
    {if (recipeeSnapshot.exists) {
    return  tx.update(snapshot.reference, <String, dynamic>{ 
    '$field': value, }); 
    } });
     });


  }

  // USER INFO

  void addNewUser(
      String userId, String imageUrl, String username, String email) {
    try {
      _usersCollection.doc(userId).set({
        'id': userId,
        'imageUrl': imageUrl,
        'username': username,
        'email': email,        
        'contacts': [],
      });
    } catch (error) {
      print('****************** DB addNewUser error **********************');
      print(error);
      throw error;
    }
  }

  Future<DocumentSnapshot> getUserDocRef(String userId)  {
    try {
      return _usersCollection.doc(userId).get();
    } catch (error) {
      print('****************** DB getUserDocRef error **********************');
      print(error);
      throw error;
    }
  }

  void updateUserInfo(String userId, Map<String, dynamic> data)  {
    try {
      _usersCollection.doc(userId).set(data,  SetOptions(merge: true));
    } catch (error) {
      print(
          '****************** DB updateUserInfo error **********************');
      print(error);
      throw error;
    }
  }
}
