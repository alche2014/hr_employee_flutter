import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class Storage {
  // FirebaseStorage storage = FirebaseStorage.instance;
   final FirebaseStorage storage = FirebaseStorage.instanceFor(
      app: FirebaseFirestore.instance.app,
      bucket:  'gs://fir-chat-flutter-e88d1.appspot.com');

  Future<String> getUrl(String path, String id) async {
    try {
      String url = '';
      await FirebaseStorage.instance
          .ref()
          .child('$path/$id')
          .getDownloadURL()
          .then((value) => url = value);
      return url;
    } catch (error) {
      print('****************** Storage getUrl error **********************');
      print(error);
      throw error;
    }
  }

  UploadTask getUploadTask(File file, String path) {
    try {
      return storage.ref().child(path).putFile(file);
    } catch (error) {
      // ignore: avoid_print
      print(
          '****************** Storage getUploadTask error **********************');
      // ignore: avoid_print
      print(error);
      rethrow;
    }
  }

  void uploadImage(String path, File file, String id) {
    try {
      storage.ref().child('$path/$id.png');
    } catch (error) {
      print(
          '****************** Storage uploadImage error **********************');
      print(error);
      throw error;
    }
  }  


}
   