import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/chat_module/screens/calls_screen/widgets/call_item.dart';
import 'package:hr_app/chat_module/widgets/body_list.dart';
import 'package:hr_app/chat_module/widgets/tab_title.dart';
class CallsScreen extends StatelessWidget {
  const CallsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {    
    return Column(
      children: [
        TabScreenTitle(
          title: 'Calls',
          
          actionWidget: CupertinoButton(
            padding: const EdgeInsets.all(0),
            onPressed: () {},
            child: Container(
              padding: const EdgeInsets.all(5),
              child: const Icon(Icons.more_vert, color: Colors.white, size: 25),
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          onTap: () {}, height: null,
        ),
        BodyList(
          child: ListView.separated(
            itemCount: 6,
            itemBuilder: (_, i) => const CallItem(onTap: null,),
            separatorBuilder: (_, i) => Divider(
              indent: 72,
              endIndent: 15,
              height: 0,
              color: Colors.grey.withOpacity(0.2),
            ),
          ),
        )
      ],
    );
  }
}
