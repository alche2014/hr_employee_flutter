import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:hr_app/chat_module/consts.dart';
import 'package:hr_app/chat_module/models/user.dart';
import 'package:hr_app/chat_module/screens/chats_screen/chat_media_screen.dart';
import 'package:hr_app/chat_module/services/db.dart';
import 'package:hr_app/chat_module/widgets/back_button.dart';
import 'package:hr_app/chat_module/widgets/media_view.dart';
import 'package:intl/intl.dart';


class ContactDetails extends StatelessWidget {
  final User contact;
  final String groupId;

  const ContactDetails({Key? key, required this.contact, required this.groupId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight + 5),
          child: AppBar(
            centerTitle: true,
            backgroundColor: Colors.black45,
            elevation: 0,
            leading: const CBackButton(),
            title: const Text(
              'Contact Info',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
            ),
            actions: [
              Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.only(right: 5),
                child: CupertinoButton(
                  onPressed: () {
                    // storage.d();
                  },
                  child: Text(
                    'Edit',
                    style: TextStyle(
                        fontSize: 16, color: Theme.of(context).accentColor),
                  ),
                ),
              ),
            ],
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
              topRight: Radius.circular(25),
              topLeft: Radius.circular(25),
            ),
            // color: kBlackColor2,
          ),
          width: size.width,
          child: ListView(
            children: [
              _Image(contact: contact),
              _ContactInfo(contact: contact, key: null,),
              const SizedBox(height: 20),
              _ChatInfo(groupId: groupId, key: null,),
              const SizedBox(height: 20),
               const _Actions(key: null,),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      // ),
    );
  }
}

class _Actions extends StatelessWidget {
  const _Actions({
     Key?  key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.black,
        border: Border(
          top: BorderSide(color: Colors.black26),
          bottom: BorderSide(color: Colors.black12),
        ),
      ),
      child: Column(
        children:const [
          _ActionsTile(title: 'Share Contact', key: null,),
          const Divider(
              height: 0,
              color: Colors.grey,
              indent: 20), // 20 (left padding + icon size)
          _ActionsTile(title: 'Export Chat'),
          Divider(
              height: 0,
               color: Colors.grey,
              indent: 20), // 20 (left padding + icon size)
          const _ActionsTile(title: 'Clear Chat', key: null,),
        ],
      ),
    );
  }
}

class _ActionsTile extends StatelessWidget {
  final String title;
  const _ActionsTile({
     Key?  key,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        // splashColor: Colors.transparent,
        highlightColor: Colors.black45,
        onTap: () {},
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
          width: size.width,
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

class _ContactInfo extends StatelessWidget {
  final User contact;
  const _ContactInfo({
     Key? key,
    required this.contact,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.black,
        border: Border(
          top: BorderSide(color: Colors.black38),
          bottom: BorderSide(color:  Colors.black38),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          _NamedIcons(contact: contact),
          const SizedBox(height: 10),
          _About(contact: contact),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _ChatInfo extends StatelessWidget {
  final String groupId;
  const _ChatInfo({
     Key? key,
    required this.groupId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: kBlackColor,
        border: Border(
          top: BorderSide(color: kBlackColor2),
          bottom: BorderSide(color: kBlackColor2),
        ),
      ),
      child: Column(
        children: [
          _MediaAndLinks(groupId: groupId),
          Divider(
              height: 0,
              color: kBorderColor1,
              indent: 65), // 65 (left padding + icon size)
          const _MediaTile(
              icon: Icons.star,
              iconColor: Color(0XFF800020),
              title: 'Starred Messages',
              end: 'None', onTap: null,),
          Divider(
            height: 0,
            color: kBorderColor1,
            indent: 65,
          ),
          const _MediaTile(
            icon: Icons.search,
            iconColor: Color(0xFFff6d00),
            title: 'Chat Search',
            end: '', onTap: null,
          ),
        ],
      ),
    );
  }
}

class _MediaAndLinks extends StatefulWidget {
  final groupId;
  const _MediaAndLinks({
    Key? key,
    this.groupId,
  }) : super(key: key);

  @override
  __MediaAndLinksState createState() => __MediaAndLinksState();
}

class __MediaAndLinksState extends State<_MediaAndLinks> {
  late DB db;
  late Stream<QuerySnapshot> mediaStream;

  @override
  void initState() {
    super.initState();
    db = DB();
    mediaStream = db.getMediaCount(widget.groupId);
  }

  void navToMedia() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => ChatMediaScreen(widget.groupId),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: navToMedia,
        highlightColor: kBlackColor2,
        // splashColor: Colors.transparent,
        child: Padding(
          padding:
              const EdgeInsets.only(left: 20, right: 10, top: 10, bottom: 10),
          child: Row(
            children: [
              Icon(
                Icons.image,
                size: 35,
                color: Theme.of(context).accentColor,
              ),
              const SizedBox(width: 10),
              Text(
                'Media, Links, and Docs',
                style: TextStyle(
                  fontSize: 17,
                  color: kBaseWhiteColor,
                ),
              ),
              const Spacer(),
              StreamBuilder<QuerySnapshot>(
                stream: mediaStream,
                builder: (ctx, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CupertinoActivityIndicator();
                  } else if (snapshot.data!.docs.isEmpty) {
                    return Text('0', style: kChatItemSubtitleStyle);
                  } else {
                    return Text('${snapshot.data!.docs.length}',
                        style: kChatItemSubtitleStyle);
                  }
                },
              ),
              const SizedBox(width: 5),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.white.withOpacity(0.7),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class _MediaTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String end;
  final  onTap;
  const _MediaTile({
    Key? key,
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.end,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        highlightColor: kBlackColor2,
        // splashColor: Colors.transparent,
        child: Padding(
          padding:
              const EdgeInsets.only(left: 20, right: 10, top: 10, bottom: 10),
          child: Row(
            children: [
              Icon(
                icon,
                size: 35,
                color: iconColor,
              ),
              SizedBox(width: 10),
              Text(
                title,
                style: TextStyle(
                  fontSize: 17,
                  color: kBaseWhiteColor,
                ),
              ),
              Spacer(),
              Text(end, style: kChatItemSubtitleStyle),
              SizedBox(width: 5),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.white.withOpacity(0.7),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class _About extends StatelessWidget {
  final User contact;
  const _About({
    Key ? key,
    required this.contact,
  }) : super(key: key);

  String getAboutChangeDate(DateTime changeDate) {
    if (changeDate == null) return 'Not Available';
    return DateFormat('MMMM dd yyyy').format(changeDate);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            contact.about,
            style: TextStyle(fontSize: 16, color: kBaseWhiteColor),
          ),
          SizedBox(height: 5),
          Text(
            getAboutChangeDate(contact.aboutChangeDate),
            style: kChatItemSubtitleStyle,
          ),
        ],
      ),
    );
  }
}

class _NamedIcons extends StatelessWidget {
  final User contact;
  const _NamedIcons({
    Key? key,
    required this.contact,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: kBorderColor2))),
      padding: const EdgeInsets.only(right: 20, bottom: 10),
      margin: const EdgeInsets.only(
        left: 20,
      ),
      child: Row(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                contact.username,
                style: TextStyle(
                    color: kBaseWhiteColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 5),
              Text(contact.email,
                  style: kChatItemSubtitleStyle),
            ],
          ),
          const Spacer(),
          _Icon(icon: Icons.message, onTap: () => Navigator.of(context).pop()),
          const SizedBox(width: 5),
          const _Icon(icon: Icons.videocam),
          const SizedBox(width: 5),
          const _Icon(icon: Icons.call),
        ],
      ),
    );
  }
}

class _Icon extends StatelessWidget {
  final IconData icon;
  final  onTap;
  const _Icon({
    Key? key,
    required this.icon,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: const EdgeInsets.all(0),
      onPressed: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(shape: BoxShape.circle, color: kBlackColor3),
        child: Icon(
          icon,
          size: 20,
          color: Theme.of(context).accentColor,
        ),
      ),
    );
  }
}

class _Image extends StatelessWidget {
  final User contact;
  const _Image({
    Key? key,
    required this.contact,
  }) : super(key: key);

  void navToImageView(BuildContext context) {
    Navigator.of(context).push(PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) =>
          MediaView(url: contact.imageUrl, type: MediaType.Photo),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: animation,
          child: child,
        );
      },
    ));
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    if (contact.imageUrl == null || contact.imageUrl == '') {
      return Container(
        width: size.width,
        color: kBlackColor,
        height: size.height * 0.3,
        child: Icon(
          Icons.person,
          size: size.height * 0.25,
          color: kBaseWhiteColor,
        ),
      );
    }
    return GestureDetector(
      onTap: () => navToImageView(context),
      child: Container(
        width: size.width,
        height: size.height * 0.3,
        child: Hero(
          tag: contact.imageUrl,
          child: CachedNetworkImage(
            imageUrl: contact.imageUrl,
            fit: BoxFit.cover,
          ),
        ),
      ),
      // ),
    );
  }
}
