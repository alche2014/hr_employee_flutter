import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/chat_module/consts.dart';
import 'package:hr_app/chat_module/models/user.dart';
import 'package:hr_app/chat_module/screens/calls_screen/widgets/call.dart';
import 'package:hr_app/chat_module/screens/chats_screen/widgets/avatar.dart';
import 'package:hr_app/chat_module/screens/contacts_screen/contact_details.dart';
import 'package:hr_app/chat_module/widgets/back_button.dart';
import 'package:hr_app/chat_module/widgets/overlay_utils.dart';
// import 'package:firebase_chat/consts.dart';
// import 'package:firebase_chat/models/user.dart';
// import 'package:firebase_chat/screens/calls_screen/widgets/call.dart';
// import 'package:firebase_chat/screens/chats_screen/widgets/avatar.dart';
// import 'package:firebase_chat/screens/contacts_screen/contact_details.dart';
// import 'package:firebase_chat/widgets/back_button.dart';
// import 'package:firebase_chat/widgets/overlay_utils.dart';

class MyAppBar extends StatefulWidget {
  final User peer;
  final String groupId;
  MyAppBar(this.peer, this.groupId);
  @override
  _MyAppBarState createState() => _MyAppBarState();
}

class _MyAppBarState extends State<MyAppBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;

  late Animation<double>  _animation;

  late Timer _timer;
  bool collapsed = false;
  var stream;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    // steram of peer details
    stream = FirebaseFirestore.instance
        .collection(USERS_COLLECTION)
        .doc(widget.peer.id)
        .snapshots();

    _animation = Tween(begin: 1.0, end: 0.0).animate(_animationController);

    _timer = Timer(const Duration(seconds: 3), () {
      collapse();
    });
  }

  @override
  void dispose() {
    _animationController.removeListener(() {});
    _animationController.dispose();
    _timer.cancel();
    super.dispose();
  }

  void collapse() {
    _animationController.forward();
    Future.delayed(const Duration(milliseconds: 300)).then((value) {
      if (mounted) setState(() => collapsed = true);
    });
  }

  void goToContactDetails() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ContactDetails(contact: widget.peer, groupId: widget.groupId),
      ),
    );
  }

  bool tapped = false;
  void toggle() {
    setState(() {
      tapped = !tapped;
    });
  }
 Future<bool> check() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      return true;
    } else if (connectivityResult == ConnectivityResult.wifi) {
      return true;
    }
    return false;
  }
  late bool noInternet;

  @override
  Widget build(BuildContext context) {
       check().then((intenet) {
         if (intenet != null && intenet) {
           noInternet = intenet;
        // Internet Present Case
         }
      // No-Internet Case
    });
    return AppBar(
      backgroundColor: kPrimaryColor,
      elevation: 0,
      leading: CBackButton(),
      title: CupertinoButton(
        padding: const EdgeInsets.all(0),
        onPressed: goToContactDetails,
        child: Row(
          children: [
            Avatar(imageUrl: widget.peer.imageUrl, radius: kToolbarHeight / 2 - 5, color: null,),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(widget.peer.username, style: kAppBarTitleStyle),
                if (collapsed)
                  StreamBuilder(
                      stream: stream,
                      builder: (ctx, snapshot) {
                        if (!snapshot.hasData) {
                          return const SizedBox(width: 0, height: 0);
                        } else {
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            height: snapshot.data=="isOnline" ? 13 : 0,
                            child: 
                        
                           
                          
                             Text(
                             snapshot.data== "Online"?'Online':"Offline",
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                color: Colors.white.withOpacity(0.7),
                              ),
                            ),
                          );
                          // return Container();
                        }
                      }),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeIn,
                  height: collapsed ? 0 : 13,
                  child: FadeTransition(
                    opacity: _animation,
                    child: Text(
                      'tap for more info',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Colors.white.withOpacity(0.7),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 20, top: 5, bottom: 5),
          child: Wrap(
            children: [
              CupertinoButton(
                onPressed: makeVoiceCall,
                padding: const EdgeInsets.all(0),
                child: Icon(Icons.call, color:kBaseWhiteColor),
                // Avatar(imageUrl: widget.peer.imageUrl, radius: 23, color: kBlackColor3),
              ),
              CupertinoButton(
                onPressed: makeVideoCall,
                padding: const EdgeInsets.all(0),
                child: Icon(Icons.video_call,
                    color: kBaseWhiteColor),
                // Avatar(imageUrl: widget.peer.imageUrl, radius: 23, color: kBlackColor3),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void makeVoiceCall() {
    OverlayUtils.overlay(
      context: context,
      alignment: Alignment.topCenter,
      child: CallingScreen(reciever: widget.peer),
      duration: const Duration(seconds: 5),
    );
  }

  void makeVideoCall() {
    OverlayUtils.overlay(
      context: context,
      alignment: Alignment.topCenter,
      child: CallingScreen(reciever: widget.peer),
      duration: const Duration(seconds: 5),
    );
  }
}
