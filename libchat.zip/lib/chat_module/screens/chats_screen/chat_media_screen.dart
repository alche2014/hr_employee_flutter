import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hr_app/chat_module/consts.dart';
import 'package:hr_app/chat_module/services/db.dart';
import 'package:hr_app/chat_module/widgets/back_button.dart';


class ChatMediaScreen extends StatefulWidget {
  final String groupId;
  // ignore: use_key_in_widget_constructors
  const ChatMediaScreen(this.groupId);
  @override
  _ChatMediaScreenState createState() => _ChatMediaScreenState();
}

class _ChatMediaScreenState extends State<ChatMediaScreen> {
  late DB db;

  @override
  void initState() {
    super.initState();
    db = DB();
  }

  @override
  Widget build(BuildContext context) {    
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight),
          child: AppBar(
            leading: const CBackButton(),
            centerTitle: true,
            title: Text('Chat Media', style: kAppBarTitleStyle),
          ),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: db.getChatMediaStream(widget.groupId),
          builder: (ctx, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CupertinoActivityIndicator());
            } else if (snapshot.data!.docs.length == 0) {
              return Center(
                  child: Text(
                'No media avaialable.',
                style: kChatItemTitleStyle,
              ));
            } else {
              var documents = snapshot.data!.docs;
              return GridView.builder(
                padding: const EdgeInsets.symmetric(vertical: 15),
                itemCount: documents.length,
                itemBuilder: (ctx, i) => SizedBox(
                  width: 150,
                  height: 150,
                  child: Image.network(
                    documents[i]['url'],
                    fit: BoxFit.cover,
                    loadingBuilder: (ctx, child, progress) {
                      return progress != null
                          ? const Center(child: CupertinoActivityIndicator())
                          : child;
                    },
                  ),
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 1,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                ),
              );
            }
          },
        ),
      ),
    );
  }
}
