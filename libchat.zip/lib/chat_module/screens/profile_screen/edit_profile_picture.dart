import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import 'package:hr_app/chat_module/consts.dart';
import 'package:hr_app/chat_module/providers/chat.dart';
import 'package:hr_app/chat_module/screens/profile_screen/widgets/photo_uploader.dart';
import 'package:hr_app/chat_module/services/db.dart';
import 'package:hr_app/chat_module/utils.dart';
import 'package:hr_app/chat_module/utils/utils.dart';
import 'package:hr_app/chat_module/widgets/back_button.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
// import 'package:firebase_chat/consts.dart';
// import 'package:firebase_chat/providers/chat.dart';
// import 'package:firebase_chat/screens/profile_screen/widgets/photo_uploader.dart';
// import 'package:firebase_chat/services/db.dart';
// import 'package:firebase_chat/utils/utils.dart';
// import 'package:firebase_chat/widgets/back_button.dart';

class EditProfilePicture extends StatefulWidget {
  final FirebaseAuth info;
  final String imageUrl;
  EditProfilePicture(this.info, this.imageUrl);
  @override
  _EditProfilePictureState createState() => _EditProfilePictureState();
}

class _EditProfilePictureState extends State<EditProfilePicture> {
  late DB db;
  @override
  void initState() {
    super.initState();
    db = DB();
  }

  Widget _getImage(MediaQueryData mq) {
    if (widget.imageUrl == '') {
      return Icon(Icons.person,
          size: mq.size.height * 0.2, color: kBaseWhiteColor);
    }
    return CachedNetworkImage(
      imageUrl: widget.imageUrl,
      fit: BoxFit.cover,
    );
  }

  Widget _buildSelectedImage(MediaQueryData mq) {
    return SizedBox(
      width: mq.size.width,
      child: PhotoUploader(
        file: _image,
        uid: widget.info.currentUser!.uid,
        getUrl: updateProfilePicture,
      ),
    );
  }

  Widget _buildProfileImage(MediaQueryData mq) {
    // ignore: unnecessary_null_comparison
    return widget.imageUrl == null
        ? SizedBox(
            height: mq.size.height * 0.7 - kToolbarHeight,
            width: mq.size.width,
            child: _getImage(mq),
          )
        : Hero(
            tag: widget.imageUrl,
            child: SizedBox(
              height: mq.size.height * 0.7 - kToolbarHeight,
              width: mq.size.width,
              child: _getImage(mq),
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    // FlutterStatusbarcolor.setStatusBarColor(kBlackColor2);
    // FlutterStatusbarcolor.setNavigationBarWhiteForeground(true);
    return SafeArea(      
      child: Scaffold(
        backgroundColor: kBlackColor,
        appBar: AppBar(
          backgroundColor: Colors.black45,
          elevation: 0,
          centerTitle: true,
          title: Text(
            'Profile Picture',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: kBaseWhiteColor),
          ),
          leading: const CBackButton(),
          actions: [
            CupertinoButton(
              onPressed: () => imageSelected
                  ? setState(() => imageSelected = false)
                  : pickImage(),
              // updateProfilePicture(),
              child: Text(
                imageSelected ? 'Cancel' : 'Update',
                style: TextStyle(
                  color: imageSelected
                      ? Theme.of(context).errorColor
                      // ignore: deprecated_member_use
                      : Theme.of(context).accentColor,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
        body: Column(
          children: [
            const SizedBox(height: 50),
            imageSelected ? _buildSelectedImage(mq) : _buildProfileImage(mq),
            const SizedBox(height: 10),
            if (!imageSelected)
              CupertinoButton(
                onPressed: () {},
                child: Center(
                    child: Text(
                  'Delete Photo',
                  style: TextStyle(
                      fontSize: 22, color: Theme.of(context).errorColor),
                )),
              ),
            if (imageSelected)
              CupertinoButton(
                padding: const EdgeInsets.all(0),
                onPressed: () => pickImage(),
                child: Center(
                    child: Text(
                  'Choose another picture.',
                  style: TextStyle(
                      fontSize: 22, color: Theme.of(context).accentColor),
                )),
              ),
          ],
        ),
      ),
    );
  }

  late File _image;
  bool imageSelected = false;
  final picker = ImagePicker();

  Future<bool> showImageSourceModal() async {
    return await showCupertinoModalPopup(
      context: context,
      builder: (ctx) => CupertinoActionSheet(
        actions: [
          CupertinoButton(
            child:
                Text('Choose Photo', style: TextStyle(color: kBaseWhiteColor)),
            onPressed: () => Navigator.of(context).pop(true),
          ),
          CupertinoButton(
            child: Text('Take Photo', style: TextStyle(color: kBaseWhiteColor)),
            onPressed: () => Navigator.of(context).pop(false),
          ),
        ],
        cancelButton: CupertinoButton(
          child: Text(
            'Cancel',
            style: TextStyle(color: Theme.of(context).errorColor),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
    );
  }

  void pickImage() async {
    var pickedFile = await Utils.pickImage(context);
    setState(() {
      _image = File(pickedFile!.path);
      imageSelected = true;
    });
    }

    void updateProfilePicture(String url) {
      final user = Provider.of<Chat>(context, listen: false).getUser;
      // final info = UserUpdateInfo();
      // info.photoUrl = url;
      // user.updateProfile(info);

      db.updateUserInfo(widget.info.currentUser!.uid, {
        'imageUrl': url,
      });

      Provider.of<Chat>(context, listen: false).setImageUrl(url);
      Navigator.of(context).pop();
    }
  }
