// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:hexcolor/hexcolor.dart';
// import 'package:hr_app/chat_module/models/user.dart' as user1;
// import 'package:hr_app/chat_module/providers/chat.dart';
// import 'package:hr_app/chat_module/screens/profile_screen/edit_profile_picture.dart';
// import 'package:hr_app/chat_module/services/db.dart';
// import 'package:hr_app/chat_module/widgets/tab_title.dart';
// import 'package:hr_app/mainApp/mainProfile/Announcemets/constants.dart';
// import 'package:provider/provider.dart';

// import '../../consts.dart';



// enum EditedField {
//   Username,
//   About,
// }

// class ProfileInfo extends StatefulWidget {
//   @override
//   _ProfileInfoState createState() => _ProfileInfoState();
// }

// class _ProfileInfoState extends State<ProfileInfo>
//     with AutomaticKeepAliveClientMixin {
//   late DB db;
//   late TextEditingController _nameController;
//   late TextEditingController _statusController;
//   late ScrollController _textFieldScrollController;

//   // bool _initLoaded = false;
//   // bool _isLoading = true;
//   late FirebaseAuth user;
//   late user1.User details;

//   @override
//   void initState() {
//     super.initState();
//     db = DB();
//     _textFieldScrollController = ScrollController();
//     Future.delayed(Duration.zero).then((value) {
//       // FirebaseAuth.instance.currentUser.(value) {
//       //   setState(() {
//       //     user = value;
//       //   });
//         db.getUserDocRef(user.currentUser!.uid).then((value) {
//           setState(() {
//             details = user1.User.fromJson(value.data) as User;
//             _statusController = TextEditingController(
//                 text: details.about ?? 'Hi there! I am using eChat.');
//             _nameController =
//                 TextEditingController(text: details.username ?? 'Not Availabe.');
//             // _isLoading = false;
//           });
//         });
    
  
  

//   @override
//   void dispose() {
//     _textFieldScrollController.dispose();
//     _statusController.dispose();
//     _nameController.dispose();
//     super.dispose();
//   }

//   void navToEditImage(
//       BuildContext context, FirebaseAuth user, String imageUrl) {
//     Navigator.of(context).push(PageRouteBuilder(
//       pageBuilder: (context, animation, secondaryAnimation) =>
//           EditProfilePicture(user, imageUrl),
//       transitionsBuilder: (context, animation, secondaryAnimation, child) {
//         return imageUrl == null || imageUrl == ''
//             ? CupertinoPageTransition(
//                 child: child,
//                 primaryRouteAnimation: animation,
//                 secondaryRouteAnimation: secondaryAnimation,
//                 linearTransition: false,
//               )
//             : FadeTransition(opacity: animation, child: child);
//       },
//     ));
//     // Navigator.of(context).push(MaterialPageRoute(
//     //   builder: (context) => EditProfilePicture(user, imageUrl),
//     // ));
//   }

//   void goToStart() {
//     _textFieldScrollController.animateTo(
//         _textFieldScrollController.position.minScrollExtent,
//         duration: Duration(milliseconds: 200),
//         curve: Curves.easeIn);
//   }

//   void updateUsername(String newValue) {
//     goToStart();
//     if (newValue != user.currentUser!.displayName) {
//       _nameController.text = '$newValue';
//       // final info = UserUpdateInfo();
//       // info.displayName = newValue;
//       // user1.User.updateProfile(info);

//       db.updateUserInfo(user.currentUser!.uid, {'username': newValue});
//     }
//   }

//   void updateAbout(String newValue) {
//     goToStart();
//     if (details.about != newValue) {
//       _statusController.text = '$newValue';
//       db.updateUserInfo(user.currentUser!.uid, {
//         'about': newValue,
//         'aboutChangeDate': DateTime.now().toIso8601String(),
//       });
//     }
//   }

//   Widget _buildImageAndName(BuildContext context, FirebaseAuth user) {
//     var imageUrl = Provider.of<Chat>(context).imageUrl;
//     return 
//     Column(
//       children: [
//         Container(
//           height: 120,
//           width: 120,
         
//           decoration: BoxDecoration(
//             shape: BoxShape.circle,
//             color: kPrimaryColor.withOpacity(0.1),
//           ),
//           child: ClipRRect(
//             borderRadius: BorderRadius.circular(100),
//             child: Hero(
//               tag: (details != null && details.imageUrl != null)
//                   ? details.imageUrl
//                   : 'EMPTY',
//               child: GestureDetector(
//                 onTap: () => navToEditImage(context, user, imageUrl),
//                 child: imageUrl == null
//                     ? Container(
//                         decoration: BoxDecoration(
//                             border: Border.all(color: kPrimaryColor.withOpacity(0.3)),
//                             borderRadius: BorderRadius.circular(80)),
//                         child: const Icon(
//                           Icons.person,
//                           size: 80,
//                           color: Colors.grey,
//                         ),
//                       )
//                     : Image.network(
                      
//                         imageUrl,
//                         loadingBuilder: (ctx, wid, loading) {
//                           return loading == null
//                               ? wid
//                               : const CupertinoActivityIndicator();
//                         },
//                         fit: BoxFit.cover,
                        
                        
//                       ),
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(height: 15),
//         Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             _buildSectionTitle('USERNAME'),
//             SizedBox(height: 5),
//             user == null
//                 ? CupertinoActivityIndicator()
//                 : Container(
//                     alignment: Alignment.centerLeft,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         bottom: BorderSide(color: kBorderColor1),
//                         top: BorderSide(color: kBorderColor1),
//                       ),
//                     ),
//                     // height: 50,
//                     child: CupertinoTextField(
//                       scrollController: _textFieldScrollController,
//                       padding: const EdgeInsets.symmetric(
//                           horizontal: 20, vertical: 15),
//                       cursorColor: Colors.grey,
//                       keyboardAppearance: Brightness.dark,
//                       style: TextStyle(
//                         fontSize: 17,
//                         color: Colors.grey,
//                       ),
//                       decoration: BoxDecoration(
//                         color: kPrimaryColor.withOpacity(0.1),
//                       ),
//                       controller: _nameController,
//                       onSubmitted: (value) => updateUsername(value),
//                     ),
//                   ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildSectionTitle(String title) => Padding(
//         padding: const EdgeInsets.only(left: 15),
//         child: Text(
//           title,
//           style: TextStyle(
//             fontSize: 16,
//             color: Colors.white.withOpacity(0.7),
//           ),
//         ),
//       );

//   Widget _buildEmail(FirebaseAuth user) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildSectionTitle('EMAIL ADDRESS'),
//         SizedBox(height: 5),
//         Container(
//           decoration: BoxDecoration(
//             color:Colors.black26,
//             border: Border(
//               bottom: BorderSide(color: kBorderColor2),
//               top: BorderSide(color: kBorderColor2),
//             ),
//           ),
//           alignment: Alignment.centerLeft,
//           child: Padding(
//             padding: const EdgeInsets.only(left: 15, top: 15, bottom: 15),
//             child: Text(
//               user.currentUser!.email.toString(),
//               style: const TextStyle(
//                 fontSize: 17,
//                 color: Colors.grey,
//               ),
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   Widget _buildAbout(FirebaseUser user) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildSectionTitle('ABOUT'),
//         SizedBox(height: 5),
//         Container(
//           decoration: BoxDecoration(
//             color: kPrimaryColor.withOpacity(0.1),
//             border: Border(
//               bottom: BorderSide(color: kBorderColor2),
//               top: BorderSide(color: kBorderColor2),
//             ),
//           ),
//           alignment: Alignment.centerLeft,
//           child: Padding(
//             padding: const EdgeInsets.only(top: 15, bottom: 15),
//             child: CupertinoTextField(
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               cursorColor: Theme.of(context).accentColor,
//               keyboardAppearance: Brightness.dark,
//               style: TextStyle(
//                 fontSize: 17,
//                 fontWeight: FontWeight.w400,
//                 color: Colors.grey,
//               ),
//               decoration: BoxDecoration(
//                 color: kPrimaryColor.withOpacity(0.0),
//               ),
//               controller: _statusController,
//               onSubmitted: (value) => updateAbout(value),
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   void _handleLogout() {
//     Provider.of<Chat>(context, listen: false).clearChatsAndContacts();
//     Provider.of<Auth>(context, listen: false).signOut();
//     Navigator.of(context).pop();
//   }

//   void showConfirmDialog(BuildContext context) {
//     showCupertinoDialog(
//       context: context,
//       builder: (context) => CupertinoAlertDialog(
//         // title: Padding(
//         //   padding: const EdgeInsets.only(bottom: 20),
//         //   child: Text('Logout?'),
//         // ),
//         content: Text(
//           'Log out of ${details.username}?',
//           style: TextStyle(
//               fontSize: 16,
//               fontWeight: FontWeight.w600,
//               color: Colors.grey),
//         ),
//         actions: [
//           CupertinoButton(
//             child: Text('cancel', style: TextStyle(color: Colors.grey)),
//             onPressed: () {
//               Navigator.of(context).pop();
//             },
//             padding: const EdgeInsets.all(0),
//           ),
//           CupertinoButton(
//             child: Text('Log Out',
//                 style: TextStyle(color: Theme.of(context).errorColor)),
//             onPressed: _handleLogout,
//             // color: Theme.of(context).accentColor,
//             padding: const EdgeInsets.all(0),
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     super.build(context);
//     final user = Provider.of<Chat>(context).getUser;
//     final mq = MediaQuery.of(context);
//     return GestureDetector(
//       onTap: () {
//         FocusScope.of(context).requestFocus(FocusNode());
//       },
//       child: Container(
//         color: kBaseWhiteColor,
//         child: Column(
//           children: [
//             Container(
//               // height: mq.size.height * 0.12,
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   TabScreenTitle(
//                     title: 'Edit Profile',
//                     actionWidget: CupertinoButton(
//                       padding: const EdgeInsets.all(0),
//                       onPressed: () {
//                         showConfirmDialog(context);
//                       },
//                       child: const Text(
//                         'Log Out',
//                         style: TextStyle(
//                             fontSize: 17, color: Colors.white),
//                       ),
//                     ), height: null, onTap: null,
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 15),
//             Expanded(
//               child: ClipRRect(
                
//                 borderRadius: const BorderRadius.only(
//                   topRight: Radius.circular(25),
//                   topLeft: Radius.circular(25),
//                 ),
//                 child: ListView(
//                   children: [
//                     _buildImageAndName(context, user),
//                     const SizedBox(height: 30),
//                     user == null
//                         ? const CupertinoActivityIndicator()
//                         : _buildEmail(user),
//                     const SizedBox(height: 30),
//                     user == null
//                         ? const CupertinoActivityIndicator()
//                         : _buildAbout(user),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
    
//   @override
//   bool get; wantKeepAlive => true;
// }

//   @override
//   // TODO: implement wantKeepAlive
//   bool get wantKeepAlive => throw UnimplementedError();
